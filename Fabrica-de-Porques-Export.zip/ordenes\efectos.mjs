// efectos: la pista de efectos de sonido con lo que dice efectos.js del vídeo.
import { join } from "node:path";
import { carpetaVideo, guardaWav, muestras, para } from "../nucleo/base.mjs";
import { cortesDe } from "../nucleo/analisis.mjs";
import { leeEfectos, mezcla, silencios, tieneEfectos } from "../nucleo/efectos.mjs";
import { abre } from "../nucleo/video.mjs";

export const ayuda = `
node fabrica.mjs efectos <video>

Lee <video>/efectos.js (cada efecto: qué sonido, en qué segundo, a qué nivel) y escribe <video>/sonidos/efectos.wav,
que render mezcla con la voz. Dice cada momento con sonido, los huecos de más de 2 s sin efectos y los efectos que
caen en un cambio de escena. Los sonidos que hay y para qué sirve cada uno: sonidos/LEEME.md.
`;

export async function corre({ libres }) {
  const dir = carpetaVideo(libres[0]);
  if (!tieneEfectos(dir)) para("Este vídeo no tiene efectos.js. Si lleva efectos, créalo (guia/sonido.md).");
  const v = await abre(dir), lista = await leeEfectos(dir, v.voz);
  const { pista, puestos } = mezcla(lista, muestras(join(dir, "voz", "voz.wav")));
  guardaWav(join(dir, "sonidos", "efectos.wav"), pista);
  let max = 0;
  for (const x of pista) max = Math.max(max, Math.abs(x));
  for (const e of puestos) if (e.que) console.log(`${e.t.toFixed(2).padStart(6)} s  ${e.sonido.padEnd(12)} ${e.que}`);
  console.log(`${puestos.length} efectos · pico ${(20 * Math.log10(max + 1e-9)).toFixed(1)} dB → ${join(dir, "sonidos", "efectos.wav")}`);
  const h = silencios(pista, 2);
  if (h.length) console.log(`Más de 2 s sin efectos: ${h.map(([a, b]) => `${a.toFixed(1)}-${b.toFixed(1)} s`).join(", ")}. Si ahí se mueve algo, le falta su sonido.`);
  for (const e of puestos) for (const c of cortesDe(v)) if (Math.abs(e.t - c) < 0.08) console.log(`  aviso: «${e.sonido}» en ${e.t.toFixed(2)} s cae en el cambio de ${c.toFixed(2)} s.`);
}
