// Los pinceles: lo que no depende del estilo (tiempo, cámara, azar, formas, capas, colores).
//   import * as p from "#pincel";
// Lo que sí depende del estilo (cómo se rellena una pieza, su sombra, los rótulos) está en el estilo del vídeo:
//   import { estilo as e } from "#estilo";
// Qué hay y cómo se usa: guia/dibujo.md, y guia/catalogo.jpg para verlo.
export * from "./tiempo.js";
export * from "./espacio.js";
export * from "./azar.js";
export * from "./formas.js";
export * from "./lienzo.js";
export * from "./toma.js";
export * from "./color.js";
export const W = 1080, H = 1920;
