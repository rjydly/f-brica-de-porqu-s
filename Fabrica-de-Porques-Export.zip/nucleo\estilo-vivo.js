// El estilo del vídeo que se está dibujando. El motor lo rellena antes de cargar las escenas (con el estilo de
// guion.json, o el de fabrica.config.json), así que en una escena basta con:
//   import { estilo as e } from "#estilo";
//   e.fondo(c); e.objeto(c, (c) => e.caja(c, 400, 800, 280, 420, 40, "principal"));
// Lo que tiene cada estilo: estilos/comun.js. Cómo se ve cada uno: guia/estilos.jpg.
import { existsSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { GlobalFonts } from "@napi-rs/canvas";
import { CASA, para } from "./base.mjs";

export const estilo = {};

// Las letras de letra/ se registran con el nombre de su archivo: "nunito-900", "fredoka-700"...
let letras = false;
export function registraLetras() {
  if (letras) return;
  for (const f of readdirSync(join(CASA, "letra"))) {
    const m = /^(.+?)-latin-(\d+)-normal\.(woff2|ttf|otf)$/.exec(f) || /^(.+)\.(woff2|ttf|otf)$/.exec(f);
    if (m) GlobalFonts.registerFromPath(join(CASA, "letra", f), m[2] && /^\d+$/.test(m[2]) ? `${m[1]}-${m[2]}` : m[1]);
  }
  letras = true;
}

export const estilosQueHay = () => readdirSync(join(CASA, "estilos"), { withFileTypes: true })
  .filter((d) => d.isDirectory() && existsSync(join(CASA, "estilos", d.name, "estilo.js"))).map((d) => d.name);

export async function cargaEstilo(nombre) {
  registraLetras();
  const ruta = join(CASA, "estilos", nombre, "estilo.js");
  if (!existsSync(ruta)) para(`No hay ningún estilo «${nombre}». Hay: ${estilosQueHay().join(", ")}.`);
  const m = await import(pathToFileURL(ruta).href);
  for (const k of Object.keys(estilo)) delete estilo[k];
  Object.assign(estilo, m.default);
  return estilo;
}
