// Abre un vídeo para dibujarlo: su guion, su voz, su estilo y sus escenas.
//
// Una escena es un archivo de video/escenas/ que exporta:
//   empieza   cuándo entra: una palabra ("sodio", "sol#2" la segunda vez, "pero@6" la de la frase 6), unos
//             segundos, o una función (voz) => segundos.
//             La primera escena empieza en 0. Cada una dura hasta que empieza la siguiente.
//   paso      cómo se entra desde la anterior: "corte" (lo normal: otro sitio), "sigue" (el mismo sitio y la misma
//             cámara: no se nota), "funde" (fundido de 0,35 s) o "barrido" (la nueva entra tapando de lado, 0,3 s).
//   pinta(c, t)   dibuja el fotograma del segundo t DEL VÍDEO (no de la escena) en el lienzo c, de 1080 × 1920.
// Las escenas se ordenan por cuándo empiezan, no por su nombre de archivo.
//
// Una alternativa es otra versión de una escena del gancho, en video/alternativas/, con el número de la escena a la
// que sustituye (alternativas/01-tunel.js en lugar de escenas/01-fiesta.js): abre(dir, { alternativa: "01-tunel" }).
import { existsSync, readdirSync } from "node:fs";
import { basename, join } from "node:path";
import { pathToFileURL } from "node:url";
import { config, json, para } from "./base.mjs";
import { cargaEstilo } from "./estilo-vivo.js";
import { rellenaVoz, voz } from "./voz-viva.js";

export const ANTES = 2 / 60; // la imagen nueva llega dos fotogramas antes que su palabra
export const PASOS = { corte: 0, sigue: 0, funde: 0.35, barrido: 0.3 };

export async function abre(dir, { alternativa = null } = {}) {
  const guion = json.lee(join(dir, "guion.json"));
  const lineaVoz = join(dir, "voz", "linea.json");
  if (!existsSync(lineaVoz)) para(`Este vídeo aún no tiene voz. Primero: node fabrica.mjs voz ${basename(dir)}`);
  rellenaVoz(json.lee(lineaVoz));
  const nombreEstilo = guion.estilo || config().estilo;
  await cargaEstilo(nombreEstilo);

  const carpeta = join(dir, "video", "escenas");
  if (!existsSync(carpeta)) para(`Este vídeo aún no tiene escenas: crea ${carpeta} con un archivo por escena.`);
  let rutas = readdirSync(carpeta).filter((f) => /\.m?js$/.test(f)).sort().map((f) => join(carpeta, f));
  if (alternativa) {
    const alt = [".js", ".mjs"].map((x) => join(dir, "video", "alternativas", alternativa + x)).find(existsSync);
    if (!alt) para(`No hay ninguna alternativa «${alternativa}» en video/alternativas/.`);
    const num = /^(\d+)-/.exec(alternativa)?.[1];
    if (!num) para(`La alternativa «${alternativa}» tiene que empezar por el número de la escena a la que sustituye (01-...).`);
    rutas = rutas.filter((r) => !basename(r).startsWith(num + "-")).concat(alt);
  }

  const escenas = [];
  for (const ruta of rutas) {
    const archivo = basename(ruta), id = archivo.replace(/\.m?js$/, "");
    let m;
    try { m = await import(pathToFileURL(ruta).href); }
    catch (err) { para(`La escena ${archivo} no carga:\n${err.stack || err}`); }
    if (typeof m.pinta !== "function") para(`La escena ${archivo} no exporta pinta(c, t).`);
    const paso = m.paso || "corte";
    if (!(paso in PASOS)) para(`La escena ${archivo}: paso «${paso}» no existe (${Object.keys(PASOS).join(", ")}).`);
    let empieza;
    try { empieza = cuando(m.empieza ?? 0); }
    catch (err) { para(`La escena ${archivo}: ${err.message}`); }
    escenas.push({ id, archivo, empieza, paso, pinta: m.pinta, pedido: m.empieza, modulo: m });
  }
  if (!escenas.length) para(`No hay escenas en ${carpeta}.`);
  escenas.sort((a, b) => a.empieza - b.empieza);
  escenas[0].empieza = 0;
  for (let i = 1; i < escenas.length; i++) {
    if (escenas[i].empieza - escenas[i - 1].empieza < 0.25)
      para(`Las escenas ${escenas[i - 1].id} y ${escenas[i].id} empiezan casi a la vez (${escenas[i - 1].empieza.toFixed(2)} y ${escenas[i].empieza.toFixed(2)} s).`);
  }
  escenas.forEach((s, i) => (s.acaba = escenas[i + 1]?.empieza ?? voz.dura));
  return { dir, nombre: basename(dir), guion, voz, estilo: nombreEstilo, escenas, dura: voz.dura, alternativa };
}

function cuando(x) {
  if (typeof x === "number") return x;
  if (typeof x === "function") return x(voz);
  if (typeof x === "string") {
    const m = /^(.+)@(\d+)$/.exec(x); // "pero@6": esa palabra dentro de la frase 6
    return Math.max(0, (m ? voz.frase(Number(m[2])).en(m[1]) : voz.en(x)) - ANTES);
  }
  throw new Error(`«empieza» tiene que ser una palabra, unos segundos o una función (es ${typeof x}).`);
}

// La escena que toca en el segundo t (su índice).
export function escenaEn(v, t) {
  let i = 0;
  while (i + 1 < v.escenas.length && t >= v.escenas[i + 1].empieza) i++;
  return i;
}
