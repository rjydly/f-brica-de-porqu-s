// Tinta: cómic de noche. Fondo carbón cálido, cada cosa con su contorno claro (como dibujada con tiza líquida sobre
// papel negro), colores vivos y planos con su sombra propia, y una sombra negra recortada debajo.
import { creaEstilo, debajo } from "../comun.js";

export default creaEstilo({
  nombre: "tinta",
  descripcion: "Cómic de noche: fondo carbón, contorno claro, colores vivos y planos.",
  color: {
    fondo: "#18171b", fondo2: "#24232a", suelo: "#201f25",
    tinta: "#f3ead8",
    principal: "#4a8fe8", principalSombra: "#3066b8",
    secundario: "#f2694b", secundarioSombra: "#c44a30",
    acento: "#f7c548", acentoSombra: "#d39d22",
    neutro: "#4fc58c", neutroSombra: "#35996a",
    metal: "#aeb4bf", metalSombra: "#848b98",
    piel: "#f0b28c", pielSombra: "#cf8c66",
    claro: "#fffaf0", claroSombra: "#e4dccd",
    oscuro: "#18171b",
    invisible: "#a37bff",
    mal: "#ff5a45", bien: "#3fcf7f",
    sombraObjeto: "rgba(0,0,0,0.55)",
  },
  letras: { fuerte: "nunito-900", media: "nunito-800", normal: "nunito-700" },
  grosor: 8,
  borde: true,
  pieza(c, camino, [color, sombra], { plano = false, sinBorde = false, grosor } = {}, e) {
    c.save();
    if (!sinBorde) { camino(c); c.lineJoin = "round"; c.lineCap = "round"; c.lineWidth = 2 * (grosor ?? e.grosor); c.strokeStyle = e.color.tinta; c.stroke(); }
    camino(c); c.fillStyle = color; c.fill();
    if (!plano) { c.save(); camino(c); c.clip(); c.fillStyle = sombra; c.fill(); c.translate(-20, -20); camino(c); c.fillStyle = color; c.fill(); c.restore(); }
    c.restore();
  },
  sombra(g, capa, e) { debajo(g, capa, e.color.sombraObjeto, 14, 16); },
  subtitulos: {
    tam: 76, linea: 86, letra: "nunito-900", letraDicha: "nunito-800",
    color: "#fffaf0", dicho: "#8f8a80", contorno: "#18171b", grosorContorno: 14,
    resalte: "rotulador", colorResalte: "#f7c548", textoResalte: "#18171b",
  },
});
