// Azar con semilla: la misma semilla da siempre la misma serie, en cualquier fotograma y en cualquier hilo.
// Nunca Math.random en un vídeo: el render dibuja trozos a la vez y cada fotograma tiene que salir igual.

export function azar(semilla = 1) {
  // sfc32, sembrado a partir de un número o de un texto
  let h = 2166136261 >>> 0;
  for (const ch of String(semilla)) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
  let a = h, b = h ^ 0x9e3779b9, c = h ^ 0x85ebca6b, d = 1;
  const sig = () => {
    a >>>= 0; b >>>= 0; c >>>= 0; d >>>= 0;
    const t = (a + b + d) >>> 0;
    d = (d + 1) >>> 0; a = b ^ (b >>> 9); b = (c + (c << 3)) >>> 0; c = (c << 21) | (c >>> 11); c = (c + t) >>> 0;
    return t / 4294967296;
  };
  for (let i = 0; i < 12; i++) sig();
  const r = () => sig();
  r.entre = (x, y) => x + (y - x) * sig();
  r.entero = (x, y) => Math.floor(x + (y - x + 1) * sig());
  r.uno = (lista) => lista[Math.floor(sig() * lista.length)];
  r.signo = () => (sig() < 0.5 ? -1 : 1);
  return r;
}

// Ruido suave de una dimensión (para que algo tiemble o respire sin saltos): valor entre -1 y 1.
export function ondula(x, semilla = 0) {
  const i = Math.floor(x), f = x - i, u = f * f * (3 - 2 * f);
  const h = (n) => { const s = Math.sin((n + semilla * 101.3) * 127.1) * 43758.5453; return (s - Math.floor(s)) * 2 - 1; };
  return h(i) + (h(i + 1) - h(i)) * u;
}
