// tendencias: lo que funciona ahora en el nicho del creador (YouTube, búsquedas, Reddit y Google Trends), para sacar ideas.
// Sin nicho, el de la Fábrica: porqués, curiosidades y ciencia.
// Sin claves: lee las páginas y feeds públicos. Deja un informe en tendencias/AAAA-MM-DD.md (y su .json).
import { join } from "node:path";
import { writeFileSync, mkdirSync } from "node:fs";
import { CASA, config, guardaConfig, json, para } from "../nucleo/base.mjs";

export const ayuda = `
node fabrica.mjs tendencias --nicho "recetas fáciles"   lo que funciona esta semana en tu nicho (se queda guardado)
node fabrica.mjs tendencias                       el último nicho que diste (o, si nunca diste uno, curiosidades y ciencia)
node fabrica.mjs tendencias --nicho ciencia       vuelve al nicho de la Fábrica: porqués, curiosidades y ciencia
node fabrica.mjs tendencias --periodo mes         lo del último mes (hoy · semana · mes)
node fabrica.mjs tendencias --idioma en           en inglés (temas, búsquedas y Reddit en inglés)
node fabrica.mjs tendencias --temas "volcanes,agujeros negros"   tus propias búsquedas en vez de las que salen del nicho
node fabrica.mjs tendencias --cortos              solo vídeos de menos de 4 minutos (shorts y reels subidos a YouTube)

Deja el informe en tendencias/<fecha>.md: los vídeos que más vistas sacan por día, las palabras que se repiten en
sus títulos, lo que la gente busca, lo que se comenta en Reddit y lo del nicho que sube en Google Trends.
Con --nicho, las búsquedas salen del nicho y de lo que YouTube autocompleta para él; Reddit se busca por el nicho.
Son pistas para ideas: la idea se comprueba luego en su fuente, como siempre.
`;

const NAVEGADOR = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36";

const SERIE = {
  es: {
    temas: ["por qué", "qué pasaría si", "curiosidades", "datos curiosos", "cómo funciona", "ciencia explicada",
      "física explicada", "el espacio", "agujeros negros", "el cuerpo humano", "el cerebro", "animales increíbles",
      "inventos", "paradojas", "experimentos"],
    reddit: ["explainlikeimfive", "todayilearned", "askscience", "Damnthatsinteresting", "space", "interestingasfuck"],
    geo: ["ES", "MX", "AR", "CO"], hl: "es", gl: "ES",
  },
  en: {
    temas: ["why does", "what if", "fun facts", "did you know", "how it works", "science explained", "physics explained",
      "space facts", "black holes", "human body facts", "brain facts", "amazing animals", "inventions", "paradox",
      "science experiments"],
    reddit: ["explainlikeimfive", "todayilearned", "askscience", "Damnthatsinteresting", "space", "interestingasfuck"],
    geo: ["US", "GB"], hl: "en", gl: "US",
  },
};

// Ángulos que se añaden al nicho del creador para buscar en YouTube (con lo que YouTube autocompleta para él).
const ANGULOS = {
  es: ["", "curiosidades", "por qué"],
  en: ["", "facts", "why"],
};

// Sin nicho: palabras que, si salen en el nombre de una tendencia de Google, la hacen de ciencia o curiosidades.
const NICHO = /(^|[^\p{L}])(ciencia\p{L}*|científic\p{L}*|nasa|spacex|artemis|espacio|espacial|planeta\p{L}*|asteroide\p{L}*|cometa\p{L}*|meteor\p{L}*|eclipse|luna|marte|júpiter|saturno|aurora\p{L}*|estrella\p{L}*|galaxia\p{L}*|agujero negro|telescopio|satélite\p{L}*|cohete\p{L}*|terremoto\p{L}*|sismo\p{L}*|volcán|volcan\p{L}*|erupción|huracán|tornado\p{L}*|tsunami|tormenta\p{L}*|físic\p{L}*|químic\p{L}*|biolog\p{L}*|cerebro|adn|virus|bacteria\p{L}*|dinosaurio\p{L}*|fósil\p{L}*|animal\p{L}*|especie\p{L}*|océano\p{L}*|tiburón|ballena\p{L}*|récord|invento\p{L}*|robot\p{L}*|nobel|science|scientists?|space|planets?|asteroids?|comet|meteor\p{L}*|moon|mars|jupiter|aurora|stars?|galaxy|black hole|telescope|satellites?|rockets?|earthquake|volcano|eruption|hurricane|tornado|tsunami|storm|physics|chemistry|biology|brain|dna|dinosaurs?|fossils?|animals?|species|ocean|shark|whale|record|inventions?|robots?)($|[^\p{L}])/iu;

const VACIAS = new Set(("de la el en y a los las que un una por para con no tu te es lo se del al como mas más sin su tus " +
  "mi me si o qué que cómo como esto este esta todo nadie nunca the a to of and in you your is for how on with this that why " +
  "what it are be i my do can from not shorts short video vídeo parte part estos estas esto tener cada antes después " +
  "hacer años minutos grandes verdad cuando porque solo siempre así hasta sobre will just about they them").split(" "));

const PERIODOS = { hoy: "EgQIAhAB", semana: "EgQIAxAB", mes: "EgQIBBAB" };
const PERIODOS_CORTOS = { hoy: "EgYIAhABGAE", semana: "EgYIAxABGAE", mes: "EgYIBBABGAE" };
const DIAS = { hoy: 1, semana: 7, mes: 30 };

async function trae(url, cabeceras = {}) {
  const r = await fetch(url, { headers: { "User-Agent": NAVEGADOR, ...cabeceras }, signal: AbortSignal.timeout(20000) });
  if (!r.ok) throw new Error(`${r.status} en ${new URL(url).host}`);
  return r.text();
}

// «14,068 vistas», «1.2 M de visualizaciones», «3.4K views» → número.
function numero(texto = "") {
  const t = texto.replace(/\s/g, " ").toLowerCase();
  const m = /([\d.,]+)\s*(k|m|mil|m de|mill|b)?/.exec(t);
  if (!m) return 0;
  let n, s = m[1];
  if (m[2]) n = parseFloat(s.replace(",", "."));
  else n = parseInt(s.replace(/[.,]/g, ""), 10);
  const mult = { k: 1e3, mil: 1e3, m: 1e6, "m de": 1e6, mill: 1e6, b: 1e9 }[m[2]] || 1;
  return Math.round(n * mult);
}

// «hace 3 días», «2 weeks ago», «hace 5 horas» → días (como mínimo, medio día).
function dias(texto = "") {
  const t = texto.toLowerCase(), m = /(\d+)/.exec(t);
  const n = m ? Number(m[1]) : 1;
  if (/minut|hora|hour|segund|second/.test(t)) return 0.5;
  if (/semana|week/.test(t)) return n * 7;
  if (/mes|month/.test(t)) return n * 30;
  if (/año|year/.test(t)) return n * 365;
  return Math.max(n, 0.5);
}

const textoDe = (x) => x?.simpleText ?? x?.runs?.map((r) => r.text).join("") ?? "";

function buscaTodos(o, clave, fuera = []) {
  if (o && typeof o === "object") {
    if (o[clave]) fuera.push(o[clave]);
    for (const k in o) buscaTodos(o[k], clave, fuera);
  }
  return fuera;
}

async function youtube(tema, { periodo, cortos, hl, gl }) {
  const sp = (cortos ? PERIODOS_CORTOS : PERIODOS)[periodo];
  const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(tema)}&sp=${sp}&hl=${hl}&gl=${gl}`;
  const html = await trae(url, { "Accept-Language": `${hl}-${gl},${hl};q=0.9` });
  const m = html.match(/var ytInitialData = (\{.*?\});<\/script>/s);
  if (!m) throw new Error("YouTube cambió su página");
  return buscaTodos(JSON.parse(m[1]), "videoRenderer").map((v) => {
    const vistas = numero(textoDe(v.viewCountText)), hace = textoDe(v.publishedTimeText);
    return {
      tema, titulo: textoDe(v.title), canal: textoDe(v.ownerText), vistas, hace, duracion: textoDe(v.lengthText),
      porDia: Math.round(vistas / dias(hace)), url: `https://www.youtube.com/watch?v=${v.videoId}`,
    };
  }).filter((v) => v.vistas > 0);
}

async function busquedas(tema, hl, gl) {
  const url = `https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&hl=${hl}&gl=${gl}&q=${encodeURIComponent(tema)}`;
  const [, lista] = JSON.parse(await trae(url));
  return lista.filter((s) => s.toLowerCase() !== tema.toLowerCase());
}

const espera = (ms) => new Promise((r) => setTimeout(r, ms));

// Reddit corta si se le pide rápido: un subreddit cada 6 s, y otro intento si aun así corta o falla.
// sub es un subreddit, o «?<búsqueda>» para buscar en todo Reddit.
async function reddit(sub, periodo) {
  const t = { hoy: "day", semana: "week", mes: "month" }[periodo];
  const url = sub.startsWith("?") ? `https://www.reddit.com/search.rss?q=${encodeURIComponent(sub.slice(1))}&sort=top&t=${t}&limit=10`
    : `https://www.reddit.com/r/${sub}/top/.rss?t=${t}&limit=10`;
  const pide = () => trae(url, { "User-Agent": "fabrica-de-porques/1.0" });
  await espera(6000);
  const xml = await pide().catch(async () => { await espera(15000); return pide(); });
  return [...xml.matchAll(/<entry>.*?<link href="([^"]+)".*?<title>(.*?)<\/title>/gs)]
    .filter(([, enlace]) => enlace.includes("/comments/")) // la búsqueda también devuelve comunidades enteras
    .map(([, enlace, titulo]) => ({ sub, titulo: desescapa(titulo), url: enlace }));
}

async function trends(geo, filtro) {
  const xml = await trae(`https://trends.google.com/trending/rss?geo=${geo}`);
  return [...xml.matchAll(/<item>(.*?)<\/item>/gs)].map(([, it]) => {
    const titulo = desescapa(/<title>(.*?)<\/title>/s.exec(it)?.[1] || "");
    const trafico = /<ht:approx_traffic>(.*?)<\/ht:approx_traffic>/.exec(it)?.[1] || "";
    const noticias = [...it.matchAll(/<ht:news_item_title>(.*?)<\/ht:news_item_title>/gs)].map((x) => desescapa(x[1]));
    return { geo, titulo, trafico, noticias };
  }).filter((x) => filtro.test(x.titulo));
}

const desescapa = (s) => s.replace(/<!\[CDATA\[(.*?)\]\]>/gs, "$1").replace(/&amp;/g, "&").replace(/&quot;/g, '"')
  .replace(/&#39;|&#x27;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").trim();

function palabras(titulos) {
  const cuenta = new Map();
  for (const t of titulos) {
    const vistas = new Set();
    for (const p of t.toLowerCase().normalize("NFC").split(/[^\p{L}\p{N}]+/u)) {
      if (p.length < 4 || VACIAS.has(p) || /^\d+$/.test(p) || vistas.has(p)) continue;
      vistas.add(p);
      cuenta.set(p, (cuenta.get(p) || 0) + 1);
    }
  }
  return [...cuenta].filter(([, n]) => n >= 3).sort((a, b) => b[1] - a[1]).slice(0, 25);
}

// Pide varias cosas a la vez, pero pocas (para no parecer un ataque), y apunta lo que falla sin parar.
async function poco(tareas, n, fallos) {
  const fuera = [];
  for (let i = 0; i < tareas.length; i += n) {
    const lote = await Promise.allSettled(tareas.slice(i, i + n).map(([, f]) => f()));
    lote.forEach((r, j) => r.status === "fulfilled" ? fuera.push(r.value) : fallos.push(`${tareas[i + j][0]}: ${r.reason.message}`));
  }
  return fuera;
}

const mil = (n) => n >= 1e6 ? `${(n / 1e6).toFixed(1)} M` : n >= 1e3 ? `${Math.round(n / 1e3)} mil` : String(n);

// Las palabras con sentido de una lista de búsquedas, como expresión para reconocerlas en un título.
function filtroDe(textos) {
  const pal = new Set(textos.flatMap((t) => t.toLowerCase().split(/[^\p{L}\p{N}]+/u)).filter((p) => p.length >= 4 && !VACIAS.has(p)));
  if (!pal.size) return NICHO;
  const escapa = (p) => p.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(^|[^\\p{L}])(${[...pal].map(escapa).join("|")})`, "iu");
}

export async function corre({ marcas }) {
  const idioma = marcas.idioma || "es";
  const serie = SERIE[idioma] || para(`El idioma es «es» o «en», no «${idioma}».`);
  const periodo = marcas.periodo || "semana";
  if (!PERIODOS[periodo]) para(`El periodo es «hoy», «semana» o «mes», no «${periodo}».`);
  if (marcas.nicho === true) para(`Falta el nicho: --nicho "recetas fáciles".`);
  if (typeof marcas.nicho === "string") guardaConfig({ nicho: /^(ciencia|science)$/i.test(marcas.nicho.trim()) ? "" : marcas.nicho.trim() });
  const nicho = config().nicho || "";
  const cortos = Boolean(marcas.cortos);
  const { hl, gl } = serie, fallos = [];

  let temas = serie.temas, subs = serie.reddit, filtro = NICHO;
  if (nicho) {
    const sugeridas = await busquedas(nicho, hl, gl).catch(() => []);
    temas = [...new Set([...ANGULOS[idioma].map((a) => `${nicho} ${a}`.trim()), ...sugeridas])].slice(0, 12);
    subs = [`?${nicho}`];
    filtro = filtroDe([nicho]);
  }
  if (typeof marcas.temas === "string") temas = marcas.temas.split(",").map((t) => t.trim()).filter(Boolean);
  const nombreNicho = nicho || "curiosidades y ciencia";

  console.log(`Buscando lo que funciona en «${nombreNicho}» (${periodo}, ${temas.length} búsquedas, ${idioma})...`);
  const [yt, sug, red, tre] = await Promise.all([
    poco(temas.map((t) => [`YouTube «${t}»`, () => youtube(t, { periodo, cortos, hl, gl })]), 3, fallos),
    poco(temas.map((t) => [`búsquedas «${t}»`, async () => [t, await busquedas(t, hl, gl)]]), 5, fallos),
    poco(subs.map((s) => [s.startsWith("?") ? `Reddit «${s.slice(1)}»` : `Reddit r/${s}`, () => reddit(s, periodo)]), 1, fallos),
    poco(serie.geo.map((g) => [`Google Trends ${g}`, () => trends(g, filtro)]), 4, fallos),
  ]);

  const unicos = new Map();
  for (const v of yt.flat()) if (!unicos.has(v.url) || unicos.get(v.url).porDia < v.porDia) unicos.set(v.url, v);
  const videos = [...unicos.values()].sort((a, b) => b.porDia - a.porDia);
  const top = videos.slice(0, 40);
  const temasYt = temas.map((t) => {
    const suyos = videos.filter((v) => v.tema === t);
    return { tema: t, videos: suyos.length, porDia: suyos.reduce((s, v) => s + v.porDia, 0) };
  }).sort((a, b) => b.porDia - a.porDia);

  const fecha = new Date().toISOString().slice(0, 10);
  const dir = join(CASA, "tendencias");
  mkdirSync(dir, { recursive: true });
  const nombre = `${fecha}-${periodo}${nicho ? "-" + nicho.toLowerCase().normalize("NFD").replace(/\p{M}/gu, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 30) : ""}${idioma === "es" ? "" : "-" + idioma}${cortos ? "-cortos" : ""}`;

  const md = [
    `# Tendencias · ${nombreNicho} · ${fecha} · ${periodo}${cortos ? " · solo cortos" : ""} · ${idioma}`, "",
    "Pistas de lo que funciona ahora. Cada idea se comprueba en su fuente original antes de hacer un vídeo (METODO.md, paso 1).", "",
    "## Los temas que más se mueven en YouTube", "",
    "| Tema | Vistas al día (suma) | Vídeos |", "|---|---:|---:|",
    ...temasYt.map((t) => `| ${t.tema} | ${mil(t.porDia)} | ${t.videos} |`), "",
    `## Los ${top.length} vídeos que más vistas sacan por día`, "",
    "| Vistas/día | Título | Canal | Vistas | Subido | Dura | Tema |", "|---:|---|---|---:|---|---|---|",
    ...top.map((v) => `| ${mil(v.porDia)} | [${v.titulo.replace(/\|/g, "/")}](${v.url}) | ${v.canal.replace(/\|/g, "/")} | ${mil(v.vistas)} | ${v.hace} | ${v.duracion} | ${v.tema} |`), "",
    "## Palabras que se repiten en los títulos que funcionan", "",
    palabras(videos.slice(0, 120).map((v) => v.titulo)).map(([p, n]) => `${p} (${n})`).join(" · ") || "_(pocas repeticiones)_", "",
    "## Lo que la gente busca (autocompletado de YouTube)", "",
    ...sug.map(([t, l]) => `- **${t}:** ${l.join(" · ") || "_nada_"}`), "",
    "## Lo que se comenta en Reddit", "",
    ...red.flatMap((l) => l.length ? [l[0].sub.startsWith("?") ? `**Reddit: «${l[0].sub.slice(1)}»**` : `**r/${l[0].sub}**`, ...l.slice(0, 8).map((p) => `- [${p.titulo}](${p.url})`), ""] : []),
    `## Lo de «${nombreNicho}» que sube hoy en Google Trends`, "",
    ...(tre.flat().length ? tre.flat().map((x) => `- **${x.titulo}** (${x.geo}, ${x.trafico})${x.noticias[0] ? ` — ${x.noticias[0]}` : ""}`) : ["_Hoy nada del nicho entre las búsquedas que suben._"]), "",
    ...(fallos.length ? ["## No se pudo leer", "", ...fallos.map((f) => `- ${f}`), ""] : []),
  ].join("\n");

  writeFileSync(join(dir, `${nombre}.md`), md);
  json.escribe(join(dir, `${nombre}.json`), { nicho: nombreNicho, fecha, periodo, idioma, cortos, temas: temasYt, videos, busquedas: Object.fromEntries(sug), reddit: red.flat(), trends: tre.flat(), fallos });

  console.log(`\nLo que más se mueve: ${temasYt.slice(0, 5).map((t) => t.tema).join(", ")}.`);
  console.log("Los 5 vídeos que más vistas sacan por día:");
  for (const v of top.slice(0, 5)) console.log(`  ${mil(v.porDia).padStart(8)}/día  ${v.titulo.slice(0, 80)}`);
  if (fallos.length) console.log(`\n(${fallos.length} fuentes no respondieron: están al final del informe.)`);
  console.log(`\nInforme: tendencias/${nombre}.md`);
}
