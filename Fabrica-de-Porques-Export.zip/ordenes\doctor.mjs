// doctor: una línea por cosa, «ok» o lo que falta y cómo se arregla. Lo que falta lo instala Claude.
import { spawnSync } from "node:child_process";
import { existsSync, readdirSync, readFileSync, statfsSync } from "node:fs";
import { join } from "node:path";
import { CASA, config, secretos } from "../nucleo/base.mjs";
import { VOZ_FABRICA } from "./voz.mjs";

export const ayuda = `
node fabrica.mjs doctor

Mira Node, ffmpeg, lo de dibujar (npm install), las letras, la voz local, el disco, el estilo y la voz elegidos.
Sale con error si falta algo imprescindible.
`;

export async function corre() {
  const filas = [], win = process.platform === "win32";
  const ok = (q, t) => filas.push(["ok", q, t]), falta = (q, t) => filas.push(["falta", q, t]), nota = (q, t) => filas.push(["nota", q, t]);

  const mayor = Number(process.versions.node.split(".")[0]);
  mayor >= 20 ? ok("node", process.versions.node) : falta("node", `hace falta Node 20 o más (hay ${process.versions.node}): ${win ? "winget install OpenJS.NodeJS.LTS" : "brew install node"}`);

  const f1 = spawnSync("ffmpeg", ["-version"], { encoding: "utf8" }), f2 = spawnSync("ffprobe", ["-version"], { encoding: "utf8" });
  f1.status === 0 && f2.status === 0 ? ok("ffmpeg", f1.stdout.split("\n")[0].slice(0, 50))
    : falta("ffmpeg", win ? "winget install Gyan.FFmpeg (y abrir una terminal nueva)" : process.platform === "darwin" ? "brew install ffmpeg" : "sudo apt install ffmpeg");

  const lienzo = join(CASA, "node_modules", "@napi-rs", "canvas", "package.json");
  if (!existsSync(lienzo)) falta("dibujo", "npm install (en esta carpeta)");
  else {
    const pide = JSON.parse(readFileSync(join(CASA, "package.json"), "utf8")).dependencies["@napi-rs/canvas"], hay = JSON.parse(readFileSync(lienzo, "utf8")).version;
    hay === pide ? ok("dibujo", `@napi-rs/canvas ${hay}`) : falta("dibujo", `hay ${hay} y hace falta ${pide}: npm install`);
  }

  const letras = existsSync(join(CASA, "letra")) ? readdirSync(join(CASA, "letra")).filter((f) => /\.(woff2|ttf|otf)$/.test(f)) : [];
  letras.length >= 4 ? ok("letras", `${letras.length} archivos`) : falta("letras", "faltan las letras de letra/: vuelve a copiar la carpeta entera");

  const sonidos = existsSync(join(CASA, "sonidos")) ? readdirSync(join(CASA, "sonidos")).filter((f) => /\.(wav|mp3)$/.test(f)) : [];
  sonidos.length ? ok("sonidos", `${sonidos.length} efectos`) : falta("sonidos", "falta la carpeta sonidos/: vuelve a copiar la carpeta entera");

  const c = config();
  const motorVoz = String(c.voz?.motor || "kokoro").toLowerCase();
  if (motorVoz === "kokoro") {
    const hayPuente = existsSync(join(CASA, "node_modules", "@huggingface", "transformers", "package.json"))
      && existsSync(join(CASA, "node_modules", "espeak-ng", "package.json"));
    const voz = c.voz?.kokoro || "em_alex";
    if (!hayPuente) falta("kokoro", "npm install (en esta carpeta): faltan @huggingface/transformers o espeak-ng");
    else if (!hayMotorOnnx()) falta("kokoro", "falta el motor ONNX: node node_modules/onnxruntime-node/script/install");
    else {
      ok("kokoro", `voz local · ${voz}${existsSync(join(CASA, "voces", `${voz}.bin`)) ? "" : " (la voz se baja al hacer la primera)"}`);
      if (!hayModelo()) nota("modelo voz", "se descarga la primera vez que se hace una voz (~90 MB)");
    }
  } else {
    secretos();
    process.env.ELEVENLABS_API_KEY ? ok("clave voz", "puesta") : falta("clave voz", "node fabrica.mjs clave abre la página para pegarla (nunca en el chat)");
  }
  ok("estilo", `${c.estilo}${c.estilo === "casa" ? " (el de Fábrica de Porqués; para cambiarlo: node fabrica.mjs estilo)" : ""}`);
  ok("voz", motorVoz === "kokoro"
    ? `${c.voz?.kokoro || "em_alex"} (Kokoro, en este ordenador; para cambiarla: node fabrica.mjs voz-id)`
    : (c.voz.id ? `${c.voz.id} (ElevenLabs)` : `${VOZ_FABRICA} (la de Fábrica de Porqués; para la tuya: node fabrica.mjs voz-id <id>)`));

  try { const s = statfsSync(CASA), gb = (s.bavail * s.bsize) / 1e9; gb > 3 ? ok("disco", `${gb.toFixed(0)} GB libres`) : falta("disco", `quedan ${gb.toFixed(1)} GB; hacen falta unos 3`); } catch { /* sin dato */ }

  const pref = join(CASA, "preferencias.md");
  existsSync(pref) && readFileSync(pref, "utf8").replace(/^#.*$/gm, "").trim() ? ok("preferencias", "guardadas") : nota("preferencias", "aún no: se preguntan una vez, antes del primer vídeo");

  for (const [e, q, t] of filas) console.log(`${e.padEnd(6)}${q.padEnd(13)}${t}`);
  process.exit(filas.some((f) => f[0] === "falta") ? 1 : 0);
}

// ¿Ya está bajado el modelo de la voz local? (la primera vez tarda; después no hace falta internet)
function hayModelo() {
  const raiz = join(CASA, ".cache");
  if (!existsSync(raiz)) return false;
  try { return readdirSync(raiz, { recursive: true }).some((f) => /\.onnx$/i.test(String(f))); } catch { return false; }
}

// ¿Tiene ONNX Runtime sus binarios? (npm a veces no deja correr su script de instalación y hay que lanzarlo a mano)
function hayMotorOnnx() {
  const raiz = join(CASA, "node_modules", "onnxruntime-node", "bin");
  if (!existsSync(raiz)) return false;
  try { return readdirSync(raiz, { recursive: true }).some((f) => /onnxruntime_binding\.node$/i.test(String(f))); } catch { return false; }
}
