#!/usr/bin/env node
// Fábrica de Porqués: una sola puerta para todas las herramientas.  node fabrica.mjs <orden> [...]   (node fabrica.mjs ayuda)
import { existsSync } from "node:fs";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import { CASA, Parada, opciones } from "./nucleo/base.mjs";

const ORDENES = {
  doctor: "mira que esté todo instalado",
  clave: "abre una página para pegar la clave de ElevenLabs (solo si usas esa voz)",
  "voz-id": "elige la voz de tus vídeos: Kokoro en tu ordenador (gratis) o ElevenLabs",
  estilo: "elige el estilo de las ilustraciones (opcional)",
  nuevo: "crea la carpeta de un vídeo nuevo",
  guion: "pasa un guion.md a guion.json y deja el vídeo listo",
  voz: "hace la voz de un vídeo y el segundo de cada palabra",
  mirar: "enseña cualquier momento del vídeo en una lámina, en segundos",
  repaso: "revisa el vídeo entero: láminas y avisos",
  efectos: "hace la pista de efectos de sonido",
  render: "hace el vídeo (borrador o final)",
  catalogo: "dibuja la lámina de lo que saben dibujar los estilos",
  tendencias: "busca lo que funciona ahora en tu nicho, para sacar ideas",
};

const orden = process.argv[2];
if (!orden || orden === "ayuda" || orden === "--ayuda" || !ORDENES[orden]) {
  if (orden && !ORDENES[orden] && orden !== "ayuda" && orden !== "--ayuda") console.log(`No conozco la orden «${orden}».\n`);
  console.log("node fabrica.mjs <orden> --ayuda   para ver cómo se usa cada una\n");
  for (const [k, v] of Object.entries(ORDENES)) console.log(`  ${k.padEnd(10)} ${v}`);
  process.exit(orden && !ORDENES[orden] && orden !== "ayuda" && orden !== "--ayuda" ? 1 : 0);
}

const ruta = join(CASA, "ordenes", `${orden}.mjs`);
if (!existsSync(ruta)) { console.error(`Falta ordenes/${orden}.mjs`); process.exit(1); }
const m = await import(pathToFileURL(ruta).href);
if (process.argv.includes("--ayuda") || process.argv.includes("--help")) { console.log(m.ayuda.trim()); process.exit(0); }
try {
  await m.corre(opciones());
} catch (err) {
  if (err instanceof Parada) { console.error(`\n✗ ${err.message}\n`); process.exit(1); }
  throw err;
}
