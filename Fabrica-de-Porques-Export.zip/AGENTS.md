# Fábrica de Porqués en OpenCode

Este proyecto trae sus instrucciones en `CLAUDE.md` (valen para Claude Code y OpenCode). `opencode.jsonc` carga ese
archivo al empezar: síguelo al pie de la letra. `METODO.md` y `guia/` mandan igual que allí.

## Equivalencias de herramientas

- Donde `CLAUDE.md` dice `AskUserQuestion`, usa la herramienta **`question`** (preguntas con botones). Nunca pongas
  una lista para que el creador conteste escribiendo si hay una decisión que tomar.
- Donde dice `Bash(...)`, usa la herramienta **`shell`**. Los comandos del proyecto se lanzan desde esta carpeta:
  `node fabrica.mjs <orden>`.
- Donde dice "tu carpeta temporal", usa una carpeta temporal **fuera** del proyecto. Los scripts de prueba nunca van
  aquí.

## Fábrica de Guiones, dentro

El guion no se hace en otra conversación: se hace aquí, con el método de Fábrica de Guiones (dos ganchos con
botones, `guion.md`, `pie.txt`) y se convierte con `node fabrica.mjs guion <video>`. Si el creador ya trae un guion
de la otra carpeta, se importa sin reescribirlo:

```
node fabrica.mjs guion "..\fabrica-de-guiones\guiones\<nombre>\guion.md" --nombre <nombre>
```

Eso crea el vídeo, copia `guion.md`, `pie.txt` e `idea.md`, y deja `guion.json` listo para `node fabrica.mjs voz`.
Si el creador solo quiere el guion, se para ahí y se le entregan `guion.md` y `pie.txt`.

## Lo que no cambia

- **Nunca pidas la clave de ElevenLabs en el chat.** Se pega en la página que abre `node fabrica.mjs clave`.
- No toques `nucleo/`, `ordenes/`, `pinceles/`, `guia/` ni `ejemplo/` al hacer un vídeo. Un estilo nuevo sí va en
  `estilos/`.
- **Un vídeo por conversación.**
- Sin subagentes ni trabajo en paralelo salvo que el creador lo apruebe.
- Nunca publiques ni envíes nada en su nombre.

## Al empezar

Si no hay `preferencias.md`, haz la configuración que describe `CLAUDE.md` ("Configúrame"): `node fabrica.mjs doctor`,
las preguntas con botones, el estilo y la voz. La voz es local (Kokoro): no hay clave que pedir. Después, dile en una
línea que ya puede pedir un vídeo.
