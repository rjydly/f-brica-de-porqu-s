// Medidas del vídeo sin renderizarlo: cuánto cambia la imagen, cómo llega cada cambio de escena y si los subtítulos
// se leen. Sirven para saber dónde mirar; nunca son una nota.
import { createCanvas } from "@napi-rs/canvas";
import { pinta } from "./fotograma.mjs";
import { ZONA } from "./subtitulos.mjs";
import { estilo } from "./estilo-vivo.js";

const PW = 72, PH = 128;
const mini = createCanvas(PW, PH), gm = mini.getContext("2d");

// El fotograma t en pequeño y en grises, sin subtítulos.
export function huella(v, est, t) {
  gm.drawImage(pinta(v, est, Math.max(0, Math.min(v.dura - 1 / 120, t)), { subtitulos: false }), 0, 0, PW, PH);
  const d = gm.getImageData(0, 0, PW, PH).data, out = new Float32Array(PW * PH);
  for (let i = 0; i < out.length; i++) out[i] = 0.3 * d[4 * i] + 0.59 * d[4 * i + 1] + 0.11 * d[4 * i + 2];
  return out;
}

// { area: parte de la pantalla que cambia (0-1), fuerza: cuánto cambia de media (0-255) }
export function cambio(a, b) {
  let n = 0, s = 0;
  for (let i = 0; i < a.length; i++) { const d = Math.abs(a[i] - b[i]); s += d; if (d > 10) n++; }
  return { area: n / a.length, fuerza: s / a.length };
}

const cortesDe = (v) => v.escenas.slice(1).filter((s) => s.paso !== "sigue").map((s) => s.empieza);

// Segundo a segundo, cuánto se mueve: · casi nada, ~ poco, = algo, # mucho, | cambio de escena.
export function pulso(v, est, paso = 0.1) {
  const cortes = cortesDe(v), n = Math.ceil(v.dura), maximo = new Array(n).fill(0);
  let antes = huella(v, est, 0);
  for (let t = paso; t < v.dura; t += paso) {
    const ahora = huella(v, est, t), s = Math.floor(t);
    if (!cortes.some((x) => x > t - paso - 0.4 && x <= t)) maximo[s] = Math.max(maximo[s], cambio(antes, ahora).area);
    antes = ahora;
  }
  const marcas = maximo.map((a, s) => (cortes.some((x) => x >= s && x < s + 1) ? "|" : a < 0.03 ? "·" : a < 0.1 ? "~" : a < 0.25 ? "=" : "#")).join("");
  return { marcas, maximo };
}

// Cómo llega cada cambio de escena:
//   alFinal  lo que aún se mueve en la última décima antes del cambio (más de un 5 % de la pantalla: se verá cortado)
//   salto    del último fotograma de antes al primero de después: un sitio nuevo cambia mucho (más de 25); un salto
//            dentro del mismo sitio cambia poco (15-20) y se ve raro; un "sigue" bien hecho, casi nada (menos de 2)
export function cambios(v, est) {
  return v.escenas.slice(1).map((s, k) => {
    const i = k + 1, t = s.empieza, prev = v.escenas[i - 1];
    return {
      n: i, t, de: prev.id, a: s.id, paso: s.paso, dura: s.acaba - s.empieza, duraAntes: t - prev.empieza,
      alFinal: cambio(huella(v, est, t - 0.12), huella(v, est, t - 0.02)),
      salto: cambio(huella(v, est, t - 0.02), huella(v, est, t + 0.02)),
    };
  });
}

// Tramos en que el fondo detrás de los subtítulos tiene tan poco contraste con su letra que no se leería.
export function subtitulosIlegibles(v, est, paso = 0.25) {
  const claroLetra = luz(estilo.subtitulos.color);
  const y0 = v.guion.subtitulos === "abajo" ? ZONA.abajo : ZONA.arriba, malos = [];
  let desde = null;
  for (let t = 0; t < v.dura; t += paso) {
    pinta(v, est, t, { subtitulos: false });
    const d = est.c.getImageData(ZONA.izquierda, y0, ZONA.ancho, 170).data;
    let s = 0, n = 0;
    for (let i = 0; i < d.length; i += 20) { s += 0.3 * d[i] + 0.59 * d[i + 1] + 0.11 * d[i + 2]; n++; }
    // con letra clara, sobre lo claro (un cielo de día) los subtítulos llevan su velo oscuro debajo (subtitulos.mjs)
    const crudo = s / n / 255, velo = claroLetra >= 0.5 ? 0.5 * Math.max(0, Math.min(1, (crudo - 0.42) / 0.25)) : 0;
    const fondo = crudo * (1 - velo), mal = Math.abs(fondo - claroLetra) < 0.22;
    if (mal && desde === null) desde = t;
    if (!mal && desde !== null) { malos.push([desde, t]); desde = null; }
  }
  if (desde !== null) malos.push([desde, v.dura]);
  return malos.filter(([a, b]) => b - a >= 0.5);
}

function luz(hex) {
  const h = hex.replace("#", "");
  return (0.3 * parseInt(h.slice(0, 2), 16) + 0.59 * parseInt(h.slice(2, 4), 16) + 0.11 * parseInt(h.slice(4, 6), 16)) / 255;
}

export { cortesDe };
