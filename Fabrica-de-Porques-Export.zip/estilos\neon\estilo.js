// Neón: fondo casi negro con una rejilla tenue y cada cosa hecha de tubos de luz de colores. Para tecnología,
// espacio, noche, juegos. Las piezas se rellenan muy poco y brillan por el borde.
import { creaEstilo, debajo } from "../comun.js";
import { alfa, mezclaColor } from "../../pinceles/color.js";

function tubo(c, camino, color, grosor) {
  c.save();
  c.lineJoin = "round"; c.lineCap = "round";
  c.shadowColor = color; c.shadowBlur = grosor * 4;
  c.lineWidth = grosor; c.strokeStyle = color; camino(c); c.stroke();
  c.shadowBlur = 0; c.lineWidth = Math.max(1.5, grosor * 0.35); c.strokeStyle = "rgba(255,255,255,0.85)"; camino(c); c.stroke();
  c.restore();
}

export default creaEstilo({
  nombre: "neon",
  descripcion: "Negro con rejilla tenue y tubos de luz de colores. Tecnología, espacio, noche.",
  color: {
    fondo: "#0a0714", fondo2: "#140f26", suelo: "#100b1f", rejilla: "#1c1636",
    tinta: "#f4f0ff",
    principal: "#22e4ff", principalSombra: "#0aa5c2",
    secundario: "#ff3d8b", secundarioSombra: "#c41f63",
    acento: "#ffe43a", acentoSombra: "#c9b21b",
    neutro: "#7dff5a", neutroSombra: "#4fc433",
    metal: "#b9c2ff", metalSombra: "#8790d6",
    piel: "#ffb38a", pielSombra: "#d98863",
    claro: "#f4f0ff", claroSombra: "#c9c2e6",
    oscuro: "#0a0714",
    invisible: "#b98cff",
    mal: "#ff4d4d", bien: "#5dff9e",
  },
  letras: { fuerte: "space-grotesk-700", media: "space-grotesk-700", normal: "space-grotesk-500" },
  grosor: 6,
  fondo(c, { disco, suelo, rejilla = true } = {}, e) {
    c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
    c.fillStyle = e.color.fondo; c.fillRect(0, 0, c.canvas.width, c.canvas.height);
    if (rejilla) {
      c.strokeStyle = e.color.rejilla; c.lineWidth = 2;
      for (let x = 0; x <= c.canvas.width; x += 90) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, c.canvas.height); c.stroke(); }
      for (let y = 0; y <= c.canvas.height; y += 90) { c.beginPath(); c.moveTo(0, y); c.lineTo(c.canvas.width, y); c.stroke(); }
    }
    c.restore();
    if (suelo !== undefined) { c.fillStyle = e.color.suelo; c.fillRect(-2000, suelo, 6000, 4000); tubo(c, (g) => { g.beginPath(); g.moveTo(-2000, suelo); g.lineTo(4000, suelo); }, e.color.secundario, 5); }
    if (disco) { c.beginPath(); c.arc(disco[0], disco[1], disco[2], 0, Math.PI * 2); c.fillStyle = e.color.fondo2; c.fill(); }
  },
  pieza(c, camino, [color], { plano = false, sinBorde = false, grosor } = {}, e) {
    // el tubo por debajo y al doble, y el relleno opaco encima: solo brilla el borde de fuera
    if (!sinBorde) tubo(c, camino, color, 2 * (grosor ?? e.grosor));
    c.save(); camino(c); c.fillStyle = mezclaColor(e.color.fondo, color, plano ? 0.85 : 0.2); c.fill(); c.restore();
  },
  trazo(c, camino, { papel = "tinta", grosor = 6, opacidad = 1 } = {}, e) {
    c.save(); c.globalAlpha *= opacidad; tubo(c, camino, e.color[papel] || papel, grosor); c.restore();
  },
  // un halo suave alrededor de la cosa entera
  sombra(g, capa, e) { debajo(g, capa, alfa(e.color.principal, 0.35), 0, 0, 22); },
  subtitulos: {
    tam: 74, linea: 86, letra: "space-grotesk-700", letraDicha: "space-grotesk-500",
    color: "#ffffff", dicho: "#9b93b8", contorno: "#0a0714", grosorContorno: 10, brillo: "#22e4ff",
    resalte: "neon", colorResalte: "#ff3d8b",
  },
});
