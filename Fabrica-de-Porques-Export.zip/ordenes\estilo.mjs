// estilo: elige el estilo de las ilustraciones (paso opcional). Sin nombre, dice cuál se usa y cuáles hay.
import { existsSync } from "node:fs";
import { join } from "node:path";
import { CASA, carpetaVideo, config, guardaConfig, json, para } from "../nucleo/base.mjs";
import { cargaEstilo, estilosQueHay } from "../nucleo/estilo-vivo.js";

export const ayuda = `
node fabrica.mjs estilo                    dice el estilo de ahora y los que hay (con guia/estilos.jpg para verlos)
node fabrica.mjs estilo <nombre>           ese estilo para los vídeos nuevos
node fabrica.mjs estilo <nombre> --video X ese estilo solo en ese vídeo (sus escenas se redibujan con él)

Un estilo nuevo, a partir de uno que haya: copia estilos/pegatina a estilos/<nombre> y cambia su estilo.js
(colores, letra, cómo se rellena una pieza). guia/estilos.md lo explica.
`;

export async function corre({ libres, marcas }) {
  const hay = estilosQueHay(), nombre = libres[0];
  if (!nombre) {
    console.log(`Estilo de ahora: ${config().estilo}`);
    for (const n of hay) { const e = await cargaEstilo(n); console.log(`  ${n.padEnd(9)} ${e.descripcion}`); }
    const hoja = join(CASA, "guia", "estilos.jpg");
    if (existsSync(hoja)) console.log(`Cómo se ve cada uno: ${hoja}`);
    return;
  }
  if (!hay.includes(nombre)) para(`No hay ningún estilo «${nombre}». Hay: ${hay.join(", ")}.`);
  if (marcas.video) {
    const dir = carpetaVideo(String(marcas.video)), g = json.lee(join(dir, "guion.json"));
    g.estilo = nombre;
    json.escribe(join(dir, "guion.json"), g);
    console.log(`${dir} se dibuja ahora en «${nombre}».`);
    return;
  }
  guardaConfig({ estilo: nombre });
  console.log(`Los vídeos nuevos se dibujan en «${nombre}».`);
}
