// «como una olla a presión.»
// La olla a presión entera sobre su fuego: la tapa tiembla y la válvula echa vapor. Acaba quieta antes del cambio.
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
import { bolitaVapor, llama, olla } from "../comun.js";

export const empieza = "como@6";
const F = voz.frase(6), T0 = F.en("como"), FIN = voz.frase(7).desde - 0.3;
export const silba = T0 + 0.15;

export function pinta(c, t) {
  e.fondo(c, { disco: [540, 1150, 470] });
  for (let i = 0; i < 6; i++) llama(c, 260 + i * 112, 1560, 140, t, i + 40);
  const tiembla = p.rango(t, T0, T0 + 0.3) * (1 - p.rango(t, FIN - 0.25, FIN));
  olla(c, 540, 1230, 640, t, { tiembla });
  for (let i = 0; i < 9; i++) {
    const t0 = silba + i * 0.12, u = (t - t0) / 0.8;
    if (u <= 0 || u >= 1 || t0 > FIN - 0.7) continue;
    bolitaVapor(c, 540 + p.ondula(i * 3.1, 2) * 40 * u, 900 - 360 * u, 14 + 30 * u, 1 - u * u);
  }
}
