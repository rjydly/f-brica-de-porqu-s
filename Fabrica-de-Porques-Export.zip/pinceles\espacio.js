// El mundo en 3D dibujado en 2D: vectores, una cámara con perspectiva y viajes de cámara sin tirones.
import { recorrido } from "./tiempo.js";

export const v3 = {
  mas: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
  menos: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
  por: (a, k) => [a[0] * k, a[1] * k, a[2] * k],
  punto: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
  cruz: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
  largo: (a) => Math.hypot(a[0], a[1], a[2]),
  unidad: (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; },
  mezcla: (a, b, u) => [a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u, a[2] + (b[2] - a[2]) * u],
};

export const CENTRO = { x: 540, y: 960 };
export const FOCAL = 1450;

// camara(pos, objetivo): devuelve { pos, objetivo, ve(X), tam(radio, z) }.
//   ve(X) → { x, y, z, k } en pantalla (k: cuántos píxeles mide una unidad a esa distancia), o null si queda detrás.
export function camara(pos, objetivo, { focal = FOCAL, giro = 0, centro = CENTRO } = {}) {
  const f = v3.unidad(v3.menos(objetivo, pos));
  let r = v3.unidad(v3.cruz(f, [0, 1, 0]));
  let u = v3.cruz(r, f);
  if (giro) { const c = Math.cos(giro), s = Math.sin(giro); [r, u] = [v3.mas(v3.por(r, c), v3.por(u, s)), v3.mas(v3.por(u, c), v3.por(r, -s))]; }
  return {
    pos, objetivo, focal,
    ve(X) {
      const d = v3.menos(X, pos), z = v3.punto(d, f);
      if (z < 0.04) return null;
      const k = focal / z;
      return { x: centro.x + k * v3.punto(d, r), y: centro.y - k * v3.punto(d, u), z, k };
    },
    tam: (radio, z) => (focal * radio) / z,
  };
}

// viaje([[t, { pos, mira, giro? }], ...]): la cámara pasa por esas paradas sin tirones (cada coordenada en su
// recorrido). Devuelve t → camara. Mira y pos se interpolan por separado.
export function viaje(paradas, opciones = {}) {
  const lista = [...paradas].sort((a, b) => a[0] - b[0]);
  const eje = (que, i) => recorrido(lista.map(([t, p]) => [t, p[que][i]]));
  const P = [0, 1, 2].map((i) => eje("pos", i)), M = [0, 1, 2].map((i) => eje("mira", i));
  const G = recorrido(lista.map(([t, p]) => [t, p.giro || 0]));
  return (t) => camara([P[0](t), P[1](t), P[2](t)], [M[0](t), M[1](t), M[2](t)], { ...opciones, giro: G(t) });
}

// Un punto en órbita: ángulo en radianes (0 = delante, en +z), distancia, altura y centro.
export const orbita = (ang, dist, alto = 0, c = [0, 0, 0]) => [c[0] + Math.sin(ang) * dist, c[1] + alto, c[2] + Math.cos(ang) * dist];

// Dibuja de lo más lejano a lo más cercano: [{ z, pinta() }].
export function porProfundidad(cosas) {
  for (const c of [...cosas].sort((a, b) => b.z - a.z)) c.pinta();
}

// Para cosas planas en 2D: una "cámara" de pantalla con zoom y desplazamiento. encuadre(t) → { x, y, zoom }.
// Se usa con pantalla(c, enc, () => ...) para dibujar como si la cámara se acercara a un punto de la escena.
export function pantalla(c, enc, pinta) {
  c.save();
  c.translate(CENTRO.x, CENTRO.y);
  c.scale(enc.zoom, enc.zoom);
  if (enc.giro) c.rotate(enc.giro);
  c.translate(-enc.x, -enc.y);
  pinta();
  c.restore();
}
