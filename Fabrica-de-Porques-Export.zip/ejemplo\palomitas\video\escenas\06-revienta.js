// «A unos ciento ochenta grados, la presión dentro es nueve veces la del aire, y la cáscara revienta.»
// «El almidón de dentro se hincha como una espuma, hasta cuarenta veces su tamaño.»
// El grano lleno de vapor sobre el fuego: «180 °C» en «ochenta»; el grano se hincha y tiembla cada vez más;
// «presión × 9» en «nueve». En «revienta» la cáscara se raja y estalla en dos mitades que salen volando, y la espuma
// blanca sale y crece hasta ser una palomita enorme. En «cuarenta» la cámara se aleja: al lado, un grano de su
// tamaño de antes, pequeño, y «× 40».
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
import { grano, llama, palomita, porDentro } from "../comun.js";

export const empieza = "a@7";
const F7 = voz.frase(7), F8 = voz.frase(8);
const GRADOS = F7.en("ochenta"), NUEVE = F7.en("nueve");
export const REVIENTA = F7.en("revienta") + 0.12;
const CUARENTA = F8.en("cuarenta"), HINCHA = F8.en("hincha");
const X = 540, Y = 1150, S = 760;

export function pinta(c, t) {
  e.fondo(c, { disco: [540, 1130, 480] });
  const lejos = p.suaviza(p.rango(t, CUARENTA - 0.5, CUARENTA + 0.4));
  const enc = {
    x: p.mezcla(540, 640, lejos), y: p.mezcla(1010, 1080, lejos),
    zoom: p.recorrido([[F7.desde, 0.95], [REVIENTA - 0.3, 1.08], [REVIENTA + 0.9, 0.95], [CUARENTA - 0.5, 0.95], [CUARENTA + 0.4, 0.62]])(t),
  };
  p.pantalla(c, enc, () => {
    if (t < REVIENTA) {
      const sube = p.rango(t, F7.en("presion") - 0.3, REVIENTA);
      porDentro(c, t, { x: X, y: Y, s: S, vapor: 1, llamas: 1, hincha: 1 + 0.1 * p.parte(sube), tiembla: 0.3 + 1.2 * sube, flechas: 0.5 + 0.5 * p.latido(t, NUEVE + 0.2, 0.4) });
      // la raja, justo antes de reventar
      const raja = p.rango(t, REVIENTA - 0.22, REVIENTA - 0.05);
      const pts = [[X - 40, Y - S * 0.55], [X - 10, Y - S * 0.46], [X - 30, Y - S * 0.38], [X + 5, Y - S * 0.3]];
      if (raja > 0) e.trazo(c, (g) => p.linea(g, pts.slice(0, 2 + Math.round(raja * 2)), false), { grosor: 9 });
    } else {
      const dt = t - REVIENTA;
      for (let i = 0; i < 6; i++) llama(c, X - 270 + i * 108, Y + 570, 150, t, i + 20);
      // las dos mitades de la cáscara se van volando y girando
      if (dt < 1.2) for (const lado of [-1, 1]) {
        const x = X + lado * (90 + 900 * dt), y = Y - 200 * dt + 1400 * dt * dt, giro = lado * dt * 4;
        e.objeto(c, (c) => {
          c.save(); c.translate(x, y); c.rotate(giro);
          c.beginPath(); c.rect(lado < 0 ? -S : 0, -S, S, 2 * S); c.clip();
          grano(c, 0, 0, S * 0.98);
          c.restore();
        });
      }
      // la espuma sale y crece: primero hasta llenar el grano y luego, «como una espuma», un poco más
      const abre = p.rebota(p.rango(t, REVIENTA, REVIENTA + 0.45), 1.2);
      const crece = p.mezcla(0.85, 1.25, p.llega(p.rango(t, HINCHA - 0.2, F8.en("espuma") + 0.4)));
      e.objeto(c, (c) => palomita(c, X, Y - 40, S * p.mezcla(0.55, 1.05, abre) * crece, { abre, semilla: 9, rot: 0.15 * abre }));
      // el fogonazo
      const f = p.rango(t, REVIENTA, REVIENTA + 0.4);
      if (f < 1) e.objeto(c, (c) => e.pieza(c, (g) => p.estrella(g, X, Y - 80, 12, 300 + 700 * p.llega(f), 160 + 400 * p.llega(f), 0.2), "acento", { plano: true }), { opacidad: 1 - f, sinSombra: true });
      // al lado, el grano de antes, pequeño
      const ve = p.llega(p.rango(t, CUARENTA - 0.2, CUARENTA + 0.3));
      if (ve > 0) e.objeto(c, (c) => grano(c, X + 760, Y + 300, 200 * ve), { opacidad: ve });
    }
  });
  e.cifra(c, 540, 625, "180 °C", { opacidad: p.visible(t, GRADOS - 0.05, NUEVE - 0.05, 0.15) });
  e.cifra(c, 540, 625, "presión × 9", { opacidad: p.visible(t, NUEVE - 0.05, REVIENTA - 0.1, 0.12) });
  e.cifra(c, 540, 625, "× 40", { opacidad: p.visible(t, CUARENTA, voz.frase(9).desde - 0.2, 0.15), tam: 120 });
}
