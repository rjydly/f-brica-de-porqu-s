// Piezas comunes de todas las órdenes: rutas, argumentos, errores, ffmpeg, audio y la configuración de la carpeta.
import { execFileSync, spawn } from "node:child_process";
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export const CASA = resolve(dirname(fileURLToPath(import.meta.url)), "..");
export const W = 1080, H = 1920;
export const MUESTREO = 48000;

export class Parada extends Error {}

// Corta la orden con un mensaje claro (sin pila: es para quien lo lee, no para depurar).
export function para(mensaje) {
  throw new Parada(mensaje);
}

export function opciones(lista = process.argv.slice(3)) {
  const libres = [], marcas = {};
  for (let i = 0; i < lista.length; i++) {
    const a = lista[i];
    if (!a.startsWith("--")) { libres.push(a); continue; }
    const [k, v] = a.slice(2).split("=");
    if (v !== undefined) marcas[k] = v;
    else if (lista[i + 1] !== undefined && !lista[i + 1].startsWith("--")) marcas[k] = lista[++i];
    else marcas[k] = true;
  }
  return { libres, marcas };
}

export const json = {
  lee: (ruta) => JSON.parse(readFileSync(ruta, "utf8").replace(/^\uFEFF/, "")),
  escribe(ruta, dato) {
    mkdirSync(dirname(ruta), { recursive: true });
    writeFileSync(ruta, JSON.stringify(dato, null, 2) + "\n");
  },
};

export const redondea = (x, d = 3) => Math.round(x * 10 ** d) / 10 ** d;

// La configuración de la carpeta (fabrica.config.json): el estilo por defecto y la voz. Lo de cada vídeo manda sobre esto.
const CONFIG = join(CASA, "fabrica.config.json");
export const BASE_CONFIG = {
  estilo: "casa",
  voz: { id: "", modelo: "eleven_v4", estabilidad: 0.35, parecido: 0.7, expresion: 0, velocidad: 1 },
};
export function config() {
  const c = existsSync(CONFIG) ? json.lee(CONFIG) : {};
  return { ...BASE_CONFIG, ...c, voz: { ...BASE_CONFIG.voz, ...(c.voz || {}) } };
}
export function guardaConfig(cambios) {
  const actual = existsSync(CONFIG) ? json.lee(CONFIG) : {};
  const nueva = { ...actual, ...cambios };
  if (cambios.voz) nueva.voz = { ...(actual.voz || {}), ...cambios.voz };
  json.escribe(CONFIG, nueva);
  return nueva;
}

// Secretos en .env.local. Se leen al entorno; nunca se imprimen.
export function secretos() {
  const f = join(CASA, ".env.local");
  if (!existsSync(f)) return;
  for (const linea of readFileSync(f, "utf8").split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*"?([^"]*)"?\s*$/.exec(linea);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2];
  }
}

// El vídeo: una ruta, o el nombre (o el principio del nombre) de una carpeta de videos/.
export function carpetaVideo(nombre) {
  if (!nombre) para("Falta el vídeo: el nombre de su carpeta en videos/ (por ejemplo 2026-10-23-cielo-azul).");
  const candidatos = [resolve(nombre), join(CASA, "videos", nombre), join(CASA, nombre)];
  for (const c of candidatos) if (existsSync(join(c, "guion.json"))) return c;
  const dir = join(CASA, "videos");
  if (existsSync(dir)) {
    const empieza = readdirSync(dir).filter((x) => x.includes(nombre) && existsSync(join(dir, x, "guion.json")));
    if (empieza.length === 1) return join(dir, empieza[0]);
    if (empieza.length > 1) para(`«${nombre}» puede ser varios vídeos: ${empieza.join(", ")}.`);
  }
  para(`No encuentro el vídeo «${nombre}» (una carpeta con guion.json).`);
}

export function ff(args) {
  try {
    return execFileSync("ffmpeg", ["-hide_banner", "-loglevel", "error", "-y", ...args], { maxBuffer: 1 << 30 });
  } catch (e) {
    para(`ffmpeg no pudo: ${String(e.stderr || e.message).slice(-500)}`);
  }
}

export function segundos(archivo) {
  return Number(execFileSync("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", archivo]).toString().trim());
}

// Cualquier audio a muestras mono en coma flotante.
export function muestras(archivo, sr = MUESTREO) {
  const crudo = execFileSync("ffmpeg", ["-v", "error", "-i", archivo, "-ac", "1", "-ar", String(sr), "-f", "f32le", "-"], { maxBuffer: 1 << 30 });
  return new Float32Array(crudo.buffer.slice(crudo.byteOffset, crudo.byteOffset + crudo.length));
}

// Muestras mono a wav de 16 bits.
export function guardaWav(ruta, datos, sr = MUESTREO) {
  const n = datos.length, b = Buffer.alloc(44 + 2 * n);
  b.write("RIFF", 0); b.writeUInt32LE(36 + 2 * n, 4); b.write("WAVEfmt ", 8);
  b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20); b.writeUInt16LE(1, 22);
  b.writeUInt32LE(sr, 24); b.writeUInt32LE(2 * sr, 28); b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34);
  b.write("data", 36); b.writeUInt32LE(2 * n, 40);
  for (let i = 0; i < n; i++) b.writeInt16LE(Math.round(32767 * Math.max(-1, Math.min(1, datos[i]))), 44 + 2 * i);
  mkdirSync(dirname(ruta), { recursive: true });
  writeFileSync(ruta, b);
}

// Un mp4 al que se le pasan fotogramas RGBA crudos.
export function tubo(salida, fps, { ancho = W, alto = H, rapido = false } = {}) {
  const args = ["-hide_banner", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${ancho}x${alto}`, "-r", String(fps), "-i", "pipe:0",
    "-c:v", "libx264", "-preset", rapido ? "ultrafast" : "slow", "-crf", rapido ? "24" : "17", "-pix_fmt", "yuv420p", "-g", String(2 * fps), "-movflags", "+faststart", salida];
  const p = spawn("ffmpeg", args, { stdio: ["pipe", "ignore", "pipe"] });
  let errores = "";
  p.stderr.on("data", (d) => (errores += d));
  const cerrado = new Promise((ok, mal) => p.on("close", (c) => (c ? mal(new Error("ffmpeg: " + errores.slice(-400))) : ok())));
  return {
    manda: (buf) => (p.stdin.write(buf) ? null : new Promise((r) => p.stdin.once("drain", r))),
    async cierra() { p.stdin.end(); await cerrado; },
  };
}

export const hoy = () => new Date().toISOString().slice(0, 10);

export const sinTildes = (s) => String(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "");
