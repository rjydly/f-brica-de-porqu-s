// Un fotograma: la escena que toca en t, el paso desde la anterior si está entrando, y los subtítulos encima.
import { createCanvas } from "@napi-rs/canvas";
import { W, H } from "./base.mjs";
import { estilo } from "./estilo-vivo.js";
import { escenaEn, PASOS } from "./video.mjs";
import { golpes, pintaSubtitulos } from "./subtitulos.mjs";
import { suaviza } from "../pinceles/tiempo.js";

export function prepara(v) {
  const lienzo = createCanvas(W, H), aux = createCanvas(W, H);
  return { lienzo, c: lienzo.getContext("2d"), aux, golpes: golpes(v.voz.palabras, v.dura), modo: v.guion.subtitulos || "arriba" };
}

function limpia(c) {
  c.setTransform(1, 0, 0, 1, 0, 0);
  c.globalAlpha = 1; c.globalCompositeOperation = "source-over"; c.filter = "none";
  c.shadowBlur = 0; c.shadowColor = "transparent"; c.shadowOffsetX = 0; c.shadowOffsetY = 0;
  c.setLineDash([]); c.lineCap = "butt"; c.lineJoin = "miter"; c.textAlign = "left"; c.textBaseline = "alphabetic";
  c.fillStyle = estilo.color?.fondo || "#000"; c.fillRect(0, 0, W, H);
}

function escena(s, c, t) {
  limpia(c);
  c.save();
  try { s.pinta(c, t); }
  catch (err) { err.message = `escena ${s.id}, segundo ${t.toFixed(3)}: ${err.message}`; throw err; }
  c.restore();
}

export function pinta(v, est, t, { subtitulos = true } = {}) {
  const i = escenaEn(v, t), s = v.escenas[i], dura = PASOS[s.paso];
  escena(s, est.c, t);
  if (dura && i > 0 && t < s.empieza + dura) {
    const u = suaviza((t - s.empieza) / dura), ca = est.aux.getContext("2d");
    escena(v.escenas[i - 1], ca, t);
    est.c.save(); est.c.setTransform(1, 0, 0, 1, 0, 0);
    if (s.paso === "funde") { est.c.globalAlpha = 1 - u; est.c.drawImage(est.aux, 0, 0); }
    else { // barrido: lo de antes se va tapado de izquierda a derecha por lo nuevo
      const x = W * u;
      est.c.drawImage(est.aux, x, 0, W - x, H, x, 0, W - x, H);
      est.c.fillStyle = estilo.color?.acento || "#fff"; est.c.fillRect(x - 14, 0, 28, H);
    }
    est.c.restore();
  }
  if (subtitulos) pintaSubtitulos(est.c, t, est.golpes, est.modo);
  return est.lienzo;
}
