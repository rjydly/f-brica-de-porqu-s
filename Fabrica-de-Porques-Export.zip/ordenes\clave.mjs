// clave: una página en este ordenador para pegar la clave de ElevenLabs. Se guarda en .env.local y la página se
// cierra. La clave nunca pasa por el chat ni sale del ordenador.
import { spawn } from "node:child_process";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { createServer } from "node:http";
import { join } from "node:path";
import { CASA } from "../nucleo/base.mjs";

export const ayuda = `
node fabrica.mjs clave

Abre en el navegador una página local para pegar la clave de ElevenLabs y la guarda en .env.local.
Nunca se pide ni se escribe la clave en el chat.
`;

const ENV = join(CASA, ".env.local");

const pagina = (aviso = "", hecho = false) => `<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fábrica de Porqués · tu clave de voz</title><style>
:root{color-scheme:light dark;--f:#f5f5f7;--t:#1d1d1f;--s:#6e6e73;--c:#fff;--b:#d2d2d7;--a:#0071e3}
@media(prefers-color-scheme:dark){:root{--f:#000;--t:#f5f5f7;--s:#a1a1a6;--c:#1c1c1e;--b:#3a3a3c;--a:#2997ff}}
body{margin:0;background:var(--f);color:var(--t);font:17px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif;display:grid;place-items:center;min-height:100vh}
main{width:min(520px,calc(100% - 32px));background:var(--c);border-radius:22px;padding:36px 32px;box-shadow:0 10px 40px rgba(0,0,0,.08)}
h1{font-size:28px;letter-spacing:-.02em;margin:0 0 8px}p{color:var(--s);margin:0 0 20px}
input{width:100%;box-sizing:border-box;font:16px ui-monospace,Consolas,monospace;padding:14px 16px;border:1px solid var(--b);border-radius:12px;background:transparent;color:var(--t)}
button{margin-top:14px;width:100%;font:600 17px inherit;font-family:inherit;padding:14px;border:0;border-radius:980px;background:var(--a);color:#fff;cursor:pointer}
.aviso{margin-top:14px;color:#e0402a}.ok{color:#1f9d55;font-weight:600}
</style></head><body><main>
${hecho ? `<h1>Guardada</h1><p class="ok">Ya puedes cerrar esta pestaña y volver a Claude Code.</p>` : `<h1>Tu clave de ElevenLabs</h1>
<p>Pégala aquí, no en el chat. Se guarda solo en este ordenador. La encuentras en elevenlabs.io → Developers → API Keys. Empieza por <code>sk_</code>.</p>
<form method="post"><input name="clave" placeholder="sk_..." autocomplete="off" spellcheck="false" autofocus><button>Guardar</button></form>
${aviso ? `<p class="aviso">${aviso}</p>` : ""}`}
</main></body></html>`;

export async function corre() {
  const srv = createServer((req, res) => {
    const responde = (html) => { res.writeHead(200, { "content-type": "text/html; charset=utf-8" }); res.end(html); };
    if (req.method !== "POST") return responde(pagina());
    let cuerpo = "";
    req.on("data", (d) => (cuerpo += d));
    req.on("end", () => {
      const clave = (new URLSearchParams(cuerpo).get("clave") || "").trim();
      if (!/^sk_[A-Za-z0-9]{20,}$/.test(clave)) return responde(pagina("Eso no parece una clave de ElevenLabs: empieza por sk_ y es larga."));
      const resto = existsSync(ENV) ? readFileSync(ENV, "utf8").split(/\r?\n/).filter((l) => l.trim() && !l.startsWith("ELEVENLABS_API_KEY=")) : [];
      writeFileSync(ENV, [...resto, `ELEVENLABS_API_KEY=${clave}`].join("\n") + "\n");
      responde(pagina("", true));
      console.log("clave guardada en .env.local");
      setTimeout(() => process.exit(0), 400);
    });
  });
  srv.listen(0, "127.0.0.1", () => {
    const url = `http://127.0.0.1:${srv.address().port}/`;
    console.log(`página de la clave: ${url}`);
    const [cmd, args] = process.platform === "win32" ? ["cmd", ["/c", "start", "", url]] : process.platform === "darwin" ? ["open", [url]] : ["xdg-open", [url]];
    spawn(cmd, args, { detached: true, stdio: "ignore" }).unref();
  });
  setTimeout(() => { console.log("la página se cerró sin clave (10 minutos)"); process.exit(1); }, 10 * 60 * 1000);
  await new Promise(() => {});
}
