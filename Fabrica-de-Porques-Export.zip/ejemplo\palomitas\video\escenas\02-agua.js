// «Dentro de cada grano hay una gotita de agua.» «Al calentarlo, esa agua se convierte en vapor y quiere salir.»
// El grano de palomitas cortado, enorme. En «gotita» aparece la gota en el centro (rótulo «agua»). En «calentarlo»
// se encienden las llamas; la gota tiembla y en «vapor» se deshace en bolitas que llenan el grano; en «salir», las
// flechas empujan la cáscara desde dentro.
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
import { porDentro } from "../comun.js";

export const empieza = "dentro@3";
const F3 = voz.frase(3), F4 = voz.frase(4);
export const GOTA = F3.en("gotita"), VAPOR = F4.en("vapor"), SALIR = F4.en("quiere"), FUEGO = F4.en("calentarlo");

export function pinta(c, t) {
  e.fondo(c, { disco: [540, 1090, 470] });
  const enc = { x: 540, y: p.recorrido([[F3.desde, 1060], [GOTA, 1060], [GOTA + 0.8, 1080], [FUEGO, 1080], [FUEGO + 0.7, 1150]])(t),
    zoom: p.recorrido([[F3.desde, 1.08], [GOTA, 1.08], [GOTA + 0.8, 1.22], [FUEGO, 1.22], [FUEGO + 0.7, 0.98]])(t) };
  p.pantalla(c, enc, () => {
    const gota = p.rebota(p.rango(t, GOTA - 0.05, GOTA + 0.25)) * (1 - p.rango(t, VAPOR - 0.1, VAPOR + 0.25));
    porDentro(c, t, {
      gota, vapor: p.rango(t, VAPOR - 0.1, VAPOR + 0.7), flechas: p.llega(p.rango(t, SALIR, SALIR + 0.5)),
      llamas: p.llega(p.rango(t, FUEGO - 0.05, FUEGO + 0.4)), tiembla: 0.4 * p.rango(t, FUEGO, VAPOR),
    });
    e.rotulo(c, 700, 860, "agua", { apunta: [575, 1050], opacidad: p.visible(t, F3.en("agua") - 0.05, FUEGO + 0.1, 0.15) });
  });
}
