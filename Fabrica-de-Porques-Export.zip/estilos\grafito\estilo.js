// Grafito: dibujo de líneas sobre gris carbón, como un boceto técnico bonito. Cada pieza es su contorno de color,
// grueso y redondeado, con un relleno muy apagado del mismo color. Limpio, moderno y muy legible.
import { creaEstilo } from "../comun.js";
import { aclara, mezclaColor } from "../../pinceles/color.js";

export default creaEstilo({
  nombre: "grafito",
  descripcion: "Líneas de color sobre gris carbón, como un boceto técnico. Limpio y moderno.",
  color: {
    fondo: "#1f2023", fondo2: "#2a2b2f", suelo: "#26272b",
    tinta: "#f2f2f2",
    principal: "#5aa9ff", principalSombra: "#5aa9ff",
    secundario: "#ff7a5c", secundarioSombra: "#ff7a5c",
    acento: "#ffd166", acentoSombra: "#ffd166",
    neutro: "#5ee0a0", neutroSombra: "#5ee0a0",
    metal: "#c9cdd4", metalSombra: "#c9cdd4",
    piel: "#ffc09a", pielSombra: "#ffc09a",
    claro: "#f2f2f2", claroSombra: "#f2f2f2",
    oscuro: "#1f2023",
    invisible: "#c3a0ff",
    mal: "#ff6b6b", bien: "#5ee0a0",
  },
  letras: { fuerte: "space-grotesk-700", media: "space-grotesk-700", normal: "space-grotesk-500" },
  grosor: 7,
  pieza(c, camino, [color], { plano = false, sinBorde = false, grosor } = {}, e) {
    c.save();
    const borde = aclara(color, 0.1), w = grosor ?? e.grosor;
    if (!sinBorde) { camino(c); c.lineJoin = "round"; c.lineCap = "round"; c.lineWidth = 2 * w; c.strokeStyle = borde; c.stroke(); }
    camino(c); c.fillStyle = mezclaColor(e.color.fondo, color, plano ? 0.9 : 0.22); c.fill();
    c.restore();
  },
  subtitulos: {
    tam: 72, linea: 84, letra: "space-grotesk-700", letraDicha: "space-grotesk-500",
    color: "#ffffff", dicho: "#8b8d93", contorno: "#1f2023", grosorContorno: 10,
    resalte: "subraya", colorResalte: "#ffd166",
  },
});
