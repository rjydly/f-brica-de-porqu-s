// Un trozo del render en su propio hilo: dibuja sus fotogramas y los manda a su propio mp4.
import { parentPort, workerData } from "node:worker_threads";
import { tubo } from "./base.mjs";
import { pinta, prepara } from "./fotograma.mjs";
import { abre } from "./video.mjs";

const { dir, desde, hasta, fps, salida, rapido, alternativa } = workerData;
const v = await abre(dir, { alternativa }), est = prepara(v), mp4 = tubo(salida, fps, { rapido });
for (let f = desde; f < hasta; f++) {
  const lienzo = pinta(v, est, f / fps);
  const espera = mp4.manda(Buffer.from(lienzo.data()));
  if (espera) await espera;
  if ((f - desde) % 20 === 0) parentPort.postMessage({ hechos: f - desde });
}
await mp4.cierra();
parentPort.postMessage({ hechos: hasta - desde, listo: true });
