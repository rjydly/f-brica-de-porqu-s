# El sonido

Un efecto existe porque algo de la imagen hace ese ruido, en ese fotograma, y dura lo que dura eso. Bien puestos, el
vídeo se siente vivo; mal puestos o con huecos largos, se siente raro. Claude no puede oír: por eso se usan solo los
sonidos de `sonidos/` (qué es cada uno, en `sonidos/LEEME.md`), que suenan como grabaciones reales y ya están
aprobados de oído, y se colocan por lo que se ve, con estas reglas.

## Qué sonido para qué

| Lo que se ve | Sonido |
|---|---|
| la cámara se mueve deprisa; algo pasa cerca o entra | `zas` (o `zas-largo` si el movimiento es largo), siempre bajo: -16 a -19 |
| algo se lanza o se aprieta y acaba de golpe | `impulso` (lo más fuerte, al final del movimiento) |
| algo explota o revienta | `boom`, más sordo con `grave: 1400` (si su escena se corta antes, con `apaga`) |
| algo de piedra o de cáscara se rompe | `crac` |
| algo choca o se posa con fuerza | `golpe`; el choque más grande, `golpe-grave` |
| algo aparece, se marca o se para en su sitio | `clic` (o `pop` si es blando o redondo) |
| un número que corre; algo que traquetea | `tic`, uno cada pocos pasos |
| algo sube o se va hacia arriba / baja | `sube` / `baja` |
| la cosa principal late | siempre el mismo, `latido`: es su sello |
| algo vuelve atrás en el tiempo o se absorbe | el sonido al revés (`alReves: true`) |
| metal, madera, cristal, papel, agua | `metal`, `madera`, `cristal`, `papel`, `gota` |
| algo bota o rebota | `muelle` |
| acierto / error | `bien` / `error` |
| un aparato que avisa o mide; un mensaje que llega | `pitido` / `aviso` |
| algo brilla, magia, idea | `chispa` |
| algo blando se aplasta; algo se desliza | `aplasta` / `desliza` |
| escribir en un teclado; pulsar Intro | `tecleo`, `tecla` / `enter` |
| algo bonito se completa | `campana` |

## Las reglas

- **Que suene agradable:** pocos sonidos y bien elegidos. Un sonido grande (`boom`, `impulso`, `golpe-grave`) como
  mucho uno o dos por vídeo, en el momento más fuerte; el resto, `zas`, `clic`, `tic`, `pop` y golpes pequeños.
  Un golpe se puede doblar con otro pequeño (el `pop` y el `crac` al reventar), pero nunca dos grandes juntos. Lo que no hace ruido de verdad (un color
  que cambia, una cifra que se queda quieta, un fuego dibujado que crece) no lleva sonido, o lleva un `zas` muy bajo.
- **Solo los de `sonidos/`.** Nunca se fabrica un sonido por síntesis.
- **Sin huecos:** nunca más de unos 2 s sin ningún efecto. Si hay un hueco, mira qué se mueve ahí y ponle su sonido.
- **Nada en un corte,** ni en un título: el cambio de escena no suena. El sonido va con lo que se mueve (si algo
  entra justo al cambiar, un poco después, con su movimiento).
- **Cada uno dura lo suyo:** un golpe es corto; un movimiento largo lleva un zas más lento (`tono: 0.7`). Si la escena
  se corta, su sonido se apaga con ella (`apaga`).
- **Siempre por debajo de la voz.** El nivel (`nivel`) se mide contra la voz que suena alrededor: -6/-8 lo fuerte (una
  explosión, el golpe del gancho), -10/-12 lo normal, -14/-17 lo pequeño (tics, golpecitos, un zas de fondo).
- **Muchos choques seguidos:** no uno por cosa. Los que más se ven, nunca dos en menos de 0,1 s, variando un poco el
  `tono` y el `nivel`.
- **Los momentos salen de las escenas,** que los exportan (`botes`, `revienta`, `choques`...), y de `voz.en()`. Nunca
  se copian segundos a mano: si la imagen cambia, el sonido la sigue.

## efectos.js

```js
import { voz } from "#voz";
import { botes } from "./video/escenas/03-sarten.js";

const lista = [];
const suena = (sonido, t, op = {}) => lista.push({ sonido, t, ...op });

suena("zas", 0.05, { desde: "inicio", nivel: -11, que: "la cámara entra en la sartén" });
suena("clic", voz.en("presión") - 0.02, { nivel: -14, que: "aparece la cifra" });
for (const b of botes) suena(b.grande ? "golpe-grave" : "pop", b.t, { nivel: b.grande ? -9 : -15, tono: b.tono });

export default lista;
```

Cada efecto:
- `t`: el segundo en que suena lo más fuerte del sonido. Con `desde: "inicio"`, el segundo en que empieza.
- `nivel`: dB frente a la voz de alrededor.
- `tono`: más de 1, más agudo y corto; menos de 1, más grave y largo.
- `grave`: quita los agudos por encima de esos Hz (más lejos, más sordo).
- `alReves`: al revés.
- `apaga`: el segundo en que se corta del todo.
- `que`: lo que hace (sale en el informe).

`node fabrica.mjs efectos <video>` hace la pista y avisa de huecos y de sonidos en un corte. `render` la mezcla con la
voz y deja todo al volumen de los reels.
