// Casa: el de los vídeos de Un minuto de porqués, y el de Fábrica de Porqués si no se elige otro. Plano y minimalista sobre fondo azul noche liso: colores lisos sin
// degradados ni brillos, el volumen en dos gestos (la cara de luz con la forma de la pieza y una sombra dura
// desplazada abajo a la derecha), sin contornos. Petróleo y mostaza como colores principales, letra Figtree.
import { creaEstilo, debajo } from "../comun.js";

export default creaEstilo({
  nombre: "casa",
  descripcion: "Plano y minimalista sobre azul noche: colores lisos, cara de luz y sombra dura, sin contornos.",
  color: {
    fondo: "#14202b", fondo2: "#1d2d3b", suelo: "#1d2d3b",
    tinta: "#f3ead8",
    principal: "#2a8fb0", principalSombra: "#45aed0",   // en este estilo la «sombra» es la cara de luz
    secundario: "#d96a8f", secundarioSombra: "#e891ae",
    acento: "#f2a541", acentoSombra: "#f7c27a",
    neutro: "#3fa36b", neutroSombra: "#5cbd86",
    metal: "#c9ccd1", metalSombra: "#e3e5e8",
    piel: "#e8a47c", pielSombra: "#f2bf9e",
    claro: "#fffaf0", claroSombra: "#fffaf0",
    oscuro: "#1d2b36",
    invisible: "#a58cff",
    mal: "#e4572e", bien: "#3fa36b",
    sombraObjeto: "#070c11",
    textoCifra: "#1d2b36",
  },
  // al aire libre de día, el cielo claro (despejado) o gris (tormenta, tifón); de noche, el azul noche de siempre
  cielos: {
    despejado: { cielo: "#a8d8ea", cielo2: "#c4e6f1", nubes: ["#fffaf0", "#e9f3f6"], cuantas: 4, alto: 0.8, suelo: "#9cc08a", lluvia: "#4f6f84" },
    nublado: { cielo: "#9fadb7", cielo2: "#b3bec6", nubes: ["#7f8d98", "#c4cdd3", "#6b7984"], cuantas: 9, suelo: "#87939a", lluvia: "#3f4c56" },
    noche: { cielo: "#14202b", cielo2: "#14202b", nubes: ["#1d2d3b", "#22374a", "#1a2833"], cuantas: 9, suelo: "#1d2d3b", lluvia: "#f3ead8" },
  },
  letras: { fuerte: "figtree-800", media: "figtree-700", normal: "figtree-500" },
  grosor: 7,                           // las piezas no llevan contorno: es el grueso de los trazos
  // la pieza entera en su luz y, encima, la misma en su color desplazada hacia la sombra y recortada por la pieza:
  // la luz queda arriba a la izquierda y sigue el contorno
  pieza(c, camino, [color, luz], { plano = false } = {}) {
    c.save();
    camino(c); c.fillStyle = plano ? color : luz; c.fill();
    if (!plano) { c.clip(); c.translate(30, 30); camino(c); c.fillStyle = color; c.fill(); }
    c.restore();
  },
  // la sombra dura: la misma silueta, opaca, 26 px abajo a la derecha
  sombra(g, capa, e) { debajo(g, capa, e.color.sombraObjeto, 26, 26); },
  subtitulos: {
    tam: 74, linea: 82, letra: "figtree-700", letraDicha: "figtree-500",
    color: "#f3ead8", dicho: "#8796a3", contorno: "#14202b", grosorContorno: 12,
    resalte: "pastilla", colorResalte: "#2a8fb0",
  },
});
