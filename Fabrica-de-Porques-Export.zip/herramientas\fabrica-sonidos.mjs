#!/usr/bin/env node
// Fabrica los efectos de sonido de sonidos/ con los efectos de sonido de ElevenLabs (suenan como grabaciones reales).
// node herramientas/fabrica-sonidos.mjs [nombre...] rehace todos, o esos. Usa la clave de .env.local y gasta muy pocos
// créditos. Lo generado con un plan de pago de ElevenLabs se puede usar en vídeos comerciales sin citarlo; con el plan
// gratuito, no. Para añadir uno nuevo, ponlo en SONIDOS con su descripción (en inglés: sale mejor) y su duración.
import { execFileSync, spawnSync } from "node:child_process";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { CASA, para, secretos } from "../nucleo/base.mjs";

// nombre: [segundos, descripción]
const SONIDOS = {
  "zas": [0.6, "A quick soft whoosh of air, something passing close and fast, clean foley, no music"],
  "zas-largo": [1.2, "A slow, long, soft whoosh of air, a camera gliding past, smooth and gentle, clean foley, no music"],
  "impulso": [0.8, "A strong rushing whoosh that accelerates toward the listener and ends in a short punchy thud, clean foley"],
  "boom": [1.5, "A deep explosion with a punchy blast and a short low rumble tail, cinematic but not harsh, no music"],
  "crac": [0.6, "A dry crack of a nut shell or small stone breaking with tiny bits, close foley, no music"],
  "golpe": [0.5, "A single dull firm thud of an object landing on a table, close foley, no reverb"],
  "golpe-grave": [0.8, "A single deep heavy thud of a big object hitting the floor, low and round, close foley"],
  "clic": [0.5, "A single short clean click, like a quality pen click, close and crisp, no reverb"],
  "tic": [0.5, "A single tiny soft tick, like a light wooden tap, very short, close foley"],
  "pop": [0.5, "A single soft bubble pop, round and cute, close foley, no reverb"],
  "sube": [0.6, "A short soft upward whoosh, air rising, gentle, clean foley"],
  "baja": [0.6, "A short soft downward whoosh, air settling and fading out, gentle, clean foley"],
  "latido": [0.5, "A single soft round heartbeat thump, warm and low, close, no reverb"],
  "aplasta": [0.6, "A soft squishy squeeze of something soft being pressed, like a sponge, close foley"],
  "metal": [0.8, "A single metal clank of a steel tool hitting metal, short ring, close foley"],
  "madera": [0.5, "A single knock on a wooden table, short and warm, close foley"],
  "cristal": [0.6, "A small glass object set down on a glass surface, short clear clink, close foley"],
  "papel": [0.8, "A sheet of paper being moved and flipped quickly, close foley"],
  "muelle": [0.8, "A small rubber ball bouncing twice on a wooden floor, close foley"],
  "desliza": [0.8, "An object sliding smoothly across a wooden table, short, close foley"],
  "roce": [0.8, "A soft muffled swish of a thick soft cloth being drawn past, warm and low, no hiss, close foley"],
  "chispa-a": [0.6, "A tiny soft crystal twinkle, a single gentle glass-like ting with a short sparkle, warm, no hiss, no white noise"],
  "chispa-b": [0.5, "A short soft electric spark tick, like static jumping between two fingers, small and dry, low, no hiss"],
  "chispa-c": [0.7, "A gentle short magical shimmer made of two soft high bell tones, sweet and round, no noise, no hiss"],
  "oleada": [1.0, "A soft deep warm swell, like a gentle low whoom rising and fading, round and smooth, no hiss, no music"],
  "pitido": [0.5, "A single short soft electronic beep of a kitchen thermometer"],
  "aviso": [0.8, "A gentle two-note phone notification chime, soft and pleasant"],
  "campana": [1.2, "A small clear bell ding, soft and pleasant, natural decay"],
  "gota": [0.5, "A single water drop falling into a glass of water, close foley"],
  "chispa": [0.8, "A short soft magical sparkle shimmer, light and gentle, not harsh"],
  "bien": [0.8, "A short pleasant two-note success chime, soft and warm"],
  "error": [0.8, "A short soft low two-note error buzz, gentle, not harsh"],
  "tecla": [0.5, "A single keyboard key press, mechanical but soft, close foley"],
  "tecleo": [1.2, "Fast typing on a laptop keyboard, close foley"],
  "enter": [0.5, "A single press of a keyboard enter key, slightly heavier, close foley"],
};

secretos();
const clave = process.env.ELEVENLABS_API_KEY;
if (!clave) para("Falta la clave de ElevenLabs: node fabrica.mjs clave");
const pedidos = process.argv.slice(2).length ? process.argv.slice(2) : Object.keys(SONIDOS);
const tmp = mkdtempSync(join(tmpdir(), "fabrica-sonidos-"));
const ff = (args) => execFileSync("ffmpeg", ["-v", "error", "-y", ...args], { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] });

for (const n of pedidos) {
  if (!SONIDOS[n]) para(`No hay ningún sonido «${n}» en la lista. Hay: ${Object.keys(SONIDOS).join(", ")}.`);
  const [dura, texto] = SONIDOS[n];
  const r = await fetch("https://api.elevenlabs.io/v1/sound-generation?output_format=mp3_44100_128", {
    method: "POST", headers: { "xi-api-key": clave, "content-type": "application/json" },
    body: JSON.stringify({ text: texto, duration_seconds: dura, prompt_influence: 0.6 }),
  });
  if (!r.ok) para(`ElevenLabs no ha hecho «${n}» (${r.status}): ${(await r.text()).slice(0, 200)}`);
  const mp3 = join(tmp, `${n}.mp3`), crudo = join(tmp, `${n}.wav`);
  writeFileSync(mp3, Buffer.from(await r.arrayBuffer()));
  // sin el silencio del principio, en mono y con el pico a -3 dB
  ff(["-i", mp3, "-af", "silenceremove=start_periods=1:start_threshold=-50dB", "-ac", "1", "-ar", "44100", crudo]);
  const informe = spawnSync("ffmpeg", ["-hide_banner", "-i", crudo, "-af", "volumedetect", "-f", "null", "-"], { encoding: "utf8" }).stderr;
  const pico = Number(/max_volume: (-?[\d.]+) dB/.exec(informe)?.[1] ?? 0);
  ff(["-i", crudo, "-af", `volume=${(-3 - pico).toFixed(2)}dB`, join(CASA, "sonidos", `${n}.wav`)]);
  console.log(`${n}.wav`);
}
rmSync(tmp, { recursive: true, force: true });
