// voz: la narración del vídeo en una sola toma, con el segundo de cada palabra. Con la voz local (Kokoro) o con ElevenLabs.
import { createHash } from "node:crypto";
import { existsSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { MUESTREO, carpetaVideo, config, ff, json, muestras, para, redondea, secretos } from "../nucleo/base.mjs";
import { normal } from "../nucleo/voz-viva.js";
import { VOZ as VOZ_KOKORO, toma as tomaKokoro } from "../nucleo/kokoro.mjs";

export const ayuda = `
node fabrica.mjs voz <video> [--otra-vez] [--motor kokoro|elevenlabs]

Lee las frases de guion.json y hace la voz de todo el vídeo de una vez, como habla una persona:
  voz/voz.wav       la voz entera, tal cual: nunca se corta ni se le quitan pausas
  voz/linea.json    cuándo empieza y acaba cada frase y cada palabra
Imprime cada frase con el segundo de sus palabras: con eso se planean las escenas.
Por defecto habla Kokoro en este ordenador (gratis, sin clave, sin internet). Con --motor elevenlabs, ElevenLabs.
Si el texto y los ajustes no han cambiado, no la vuelve a hacer; --otra-vez la hace de nuevo.
La voz que se usa: "voz" de guion.json, si no la de fabrica.config.json (node fabrica.mjs voz-id).
Para las voces locales: node fabrica.mjs voz-id (dice las que hay); para cambiar de motor: node fabrica.mjs voz-id --motor.
`;

export const VOZ_FABRICA = "851ejYcv2BoNPjrkw93G"; // Tony, de la biblioteca de ElevenLabs (español de España, natural)
const COLA = 0.9; // silencio al final para que la última imagen respire

const palabrasDe = (s) => String(s).trim().split(/\s+/).filter((w) => /[\p{L}\p{N}]/u.test(w));

export async function corre({ libres, marcas }) {
  const dir = carpetaVideo(libres[0]);
  const guion = json.lee(join(dir, "guion.json"));
  const frases = (guion.frases || []).filter((f) => String(f.dice || "").trim());
  if (!frases.length) para("guion.json no tiene frases con texto («dice»).");
  const ajustes = { ...config().voz, ...(guion.voz || {}) };
  if (guion.idioma && !guion.voz?.idioma) ajustes.idioma = String(guion.idioma);
  if (marcas.motor) ajustes.motor = String(marcas.motor).toLowerCase();
  if (marcas.voz) ajustes.kokoro = String(marcas.voz);
  const motorVoz = String(ajustes.motor || "kokoro").toLowerCase();
  if (motorVoz === "kokoro") {
    if (!ajustes.kokoro || !/^[a-z]{1,2}_/.test(String(ajustes.kokoro))) ajustes.kokoro = VOZ_KOKORO;
  } else if (!ajustes.id) ajustes.id = VOZ_FABRICA;
  const dichos = frases.map((f) => String(f.pronuncia || f.dice).trim());
  const firma = createHash("sha256").update(JSON.stringify({ motor: motorVoz, ajustes, dichos })).digest("hex").slice(0, 16);
  const ftoma = join(dir, "voz", "toma.json"), wtoma = join(dir, "voz", "toma.wav");

  let toma = existsSync(ftoma) && existsSync(wtoma) ? json.lee(ftoma) : null;
  if (!toma || toma.firma !== firma || marcas["otra-vez"]) {
    toma = motorVoz === "kokoro"
      ? await tomaKokoro(dir, dichos, ajustes, firma, (m) => console.log(m))
      : await pide(dir, ajustes, dichos, firma);
    json.escribe(ftoma, toma);
  }

  // la toma tal cual; solo se quita el silencio de delante (si de verdad es silencio) y se añade una cola
  const audio = muestras(wtoma), oidas = toma.palabras;
  if (!oidas?.length) para("La voz ha salido sin palabras. Vuelve a hacerla: node fabrica.mjs voz <video> --otra-vez");
  let quita = Math.max(0, oidas[0].desde - 0.08);
  for (let i = 0, n = Math.floor(quita * MUESTREO); i < n; i++) if (Math.abs(audio[i]) > 0.006) { quita = 0; break; }
  const dura = redondea(Math.max(oidas[oidas.length - 1].hasta - quita + COLA, audio.length / MUESTREO - quita));
  ff(["-i", wtoma, "-af", `atrim=start=${quita.toFixed(3)},asetpts=PTS-STARTPTS,apad=whole_dur=${dura}`, "-ar", String(MUESTREO), "-ac", "1", join(dir, "voz", "voz.wav")]);

  // frase a frase: las palabras que se leen, con los tiempos de las que se dijeron
  const palabras = [], lista = [];
  let k = 0;
  frases.forEach((f, i) => {
    const dichas = oidas.slice(k, k + palabrasDe(dichos[i]).length);
    k += palabrasDe(dichos[i]).length;
    if (!dichas.length) para(`La frase ${i + 1} no aparece en la voz. Vuelve a pedirla: node fabrica.mjs voz ${libres[0]} --otra-vez`);
    const escritas = palabrasDe(f.dice), tiempos = empareja(escritas, dichas);
    escritas.forEach((w, j) => palabras.push({
      dice: w, desde: redondea(tiempos[j][0] - quita), hasta: redondea(tiempos[j][1] - quita), frase: i + 1,
      resaltada: !!f.resalta && normal(w) === normal(f.resalta),
    }));
    lista.push({ n: i + 1, dice: f.dice, resalta: f.resalta || null, gancho: !!f.gancho, desde: redondea(dichas[0].desde - quita), hasta: redondea(dichas[dichas.length - 1].hasta - quita) });
  });
  json.escribe(join(dir, "voz", "linea.json"), { firma, dura, frases: lista, palabras });

  console.log(`voz: ${join(dir, "voz", "voz.wav")}  ${dura.toFixed(2)} s · ${lista.length} frases · ${palabras.length} palabras`);
  for (const f of lista) {
    const suyas = palabras.filter((w) => w.frase === f.n).map((w) => `${w.dice}@${w.desde.toFixed(2)}`).join(" ");
    console.log(`${String(f.n).padStart(2)} ${f.desde.toFixed(2).padStart(6)}-${f.hasta.toFixed(2).padEnd(6)} ${suyas}`);
  }
  for (const f of frases) if (f.resalta && !palabrasDe(f.dice).some((w) => normal(w) === normal(f.resalta))) console.log(`  aviso: «${f.resalta}» no está en la frase «${f.dice}».`);
  for (let i = 1; i < palabras.length; i++) {
    const hueco = palabras[i].desde - palabras[i - 1].hasta;
    if (hueco > 1.1) console.log(`  aviso: ${hueco.toFixed(1)} s callado entre «${palabras[i - 1].dice}» y «${palabras[i].dice}». Si sobra, cambia la puntuación y pide otra vez la voz (nunca se corta).`);
  }
}

async function pide(dir, a, dichos, firma) {
  secretos();
  const clave = process.env.ELEVENLABS_API_KEY;
  if (!clave) para("Falta la clave de ElevenLabs. Ábrele la página para pegarla: node fabrica.mjs clave (nunca se pide en el chat).");
  const cuerpo = {
    text: dichos.join(" "), model_id: a.modelo,
    voice_settings: { stability: a.estabilidad, similarity_boost: a.parecido, style: a.expresion, speed: a.velocidad, use_speaker_boost: true },
  };
  let r;
  try {
    r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${a.id}/with-timestamps?output_format=mp3_44100_128`, {
      method: "POST", headers: { "xi-api-key": clave, "content-type": "application/json" }, body: JSON.stringify(cuerpo),
    });
  } catch (err) {
    para(`No se pudo llegar a ElevenLabs (${err.cause?.code || err.message}). Si es por certificados en Windows, vuelve a lanzarlo con NODE_OPTIONS=--use-system-ca.`);
  }
  if (r.status === 401) para("ElevenLabs no acepta la clave. Pega otra: node fabrica.mjs clave");
  if (r.status === 404 || r.status === 400 && /voice/i.test(await r.clone().text())) para(`ElevenLabs no encuentra la voz ${a.id}. Elige otra: node fabrica.mjs voz-id <id>`);
  if (!r.ok) para(`ElevenLabs respondió ${r.status}: ${(await r.text()).slice(0, 300)}`);
  const j = await r.json();
  const mp3 = join(dir, "voz", "toma.mp3");
  json.escribe(join(dir, "voz", "toma.json"), { pendiente: true });
  writeFileSync(mp3, Buffer.from(j.audio_base64, "base64"));
  ff(["-i", mp3, "-ar", String(MUESTREO), "-ac", "1", join(dir, "voz", "toma.wav")]);
  rmSync(mp3);
  // de letras a palabras (separadas por espacios, como en el texto que se mandó)
  const al = j.alignment || j.normalized_alignment, oidas = [];
  let w = null;
  al.characters.forEach((ch, i) => {
    if (/\s/.test(ch)) { if (w) oidas.push(w); w = null; return; }
    if (!w) w = { dice: "", desde: al.character_start_times_seconds[i] };
    w.dice += ch; w.hasta = al.character_end_times_seconds[i];
  });
  if (w) oidas.push(w);
  const toma = { firma, ajustes: a, palabras: oidas.filter((x) => /[\p{L}\p{N}]/u.test(x.dice)) };
  json.escribe(join(dir, "voz", "toma.json"), toma);
  return toma;
}

// Empareja lo que se lee con lo que se dijo. Las palabras iguales se quedan con su tiempo; las que se leen distinto
// («IA» dicho «i a», «4.000» dicho «cuatro mil») se reparten, por letras, el tramo de lo dicho en su lugar.
function empareja(escritas, dichas) {
  const A = escritas.map(normal), B = dichas.map((d) => normal(d.dice)), n = A.length, m = B.length;
  if (n === m && A.every((x, i) => x === B[i])) return dichas.map((d) => [d.desde, d.hasta]);
  // la subsecuencia común más larga, para saber qué palabras son las mismas
  const L = Array.from({ length: n + 1 }, () => new Int16Array(m + 1));
  for (let i = 1; i <= n; i++) for (let j = 1; j <= m; j++) L[i][j] = A[i - 1] === B[j - 1] ? L[i - 1][j - 1] + 1 : Math.max(L[i - 1][j], L[i][j - 1]);
  const pares = [];
  for (let i = n, j = m; i > 0 && j > 0;) {
    if (A[i - 1] === B[j - 1]) { pares.unshift([i - 1, j - 1]); i--; j--; }
    else if (L[i - 1][j] >= L[i][j - 1]) i--; else j--;
  }
  pares.push([n, m]);
  const out = [];
  let i0 = 0, j0 = 0;
  for (const [i1, j1] of pares) {
    if (i1 > i0) {
      const a = j1 > j0 ? dichas[j0].desde : (dichas[j0 - 1]?.hasta ?? dichas[0].desde);
      const b = j1 > j0 ? dichas[j1 - 1].hasta : a;
      const pesos = escritas.slice(i0, i1).map((x) => x.length + 2), total = pesos.reduce((s, x) => s + x, 0);
      let t = a;
      for (const p of pesos) { const d = ((b - a) * p) / total; out.push([t, t + d]); t += d; }
    }
    if (i1 < n) out.push([dichas[j1].desde, dichas[j1].hasta]);
    i0 = i1 + 1; j0 = j1 + 1;
  }
  return out;
}
