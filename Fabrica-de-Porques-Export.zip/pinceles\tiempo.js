// El tiempo del movimiento: tramos, curvas de aceleración y recorridos por varios valores.

export const limita = (x, a = 0, b = 1) => (x < a ? a : x > b ? b : x);

// rango(t, a, b): 0 antes de a, 1 después de b, recto en medio. Con a > b va de 1 a 0.
export const rango = (t, a, b) => limita((t - a) / (b - a));

export const mezcla = (a, b, u) => a + (b - a) * u;

// Curvas: reciben u de 0 a 1 y devuelven de 0 a 1.
export const suaviza = (u) => u * u * u * (10 + u * (6 * u - 15));       // arranca y frena sin tirón
export const llega = (u) => 1 - (1 - u) ** 3;                            // rápido y frena largo: lo que entra
export const parte = (u) => u ** 3;                                       // despacio y se va rápido: lo que sale
export const rebota = (u, fuerza = 1.8) => 1 + (fuerza + 1) * (u - 1) ** 3 + fuerza * (u - 1) ** 2; // se pasa un poco y vuelve
export const muelle = (u) => (u >= 1 ? 1 : 1 - Math.cos(u * Math.PI * 2.5) * Math.exp(-6 * u)); // vibra y se queda

// Lo que va de a a b entre dos segundos, suave.
export const entre = (t, t0, t1, a, b, curva = suaviza) => mezcla(a, b, curva(rango(t, t0, t1)));

// Un latido alrededor de t0: sube y baja (ancho, más o menos lo que dura).
export const latido = (t, t0, ancho = 0.25) => Math.exp(-(((t - t0) / ancho) ** 2));

// Aparece en a, se queda y se va en b, con fundidos de f segundos. Devuelve la opacidad.
export const visible = (t, a, b, f = 0.2) => Math.min(rango(t, a, a + f), 1 - rango(t, b - f, b));

// recorrido([[t, valor], ...]): pasa por cada valor en su segundo sin pasarse ni detenerse entre medias (Hermite con
// pendientes de Fritsch–Carlson). Arranca y acaba quieto. Para tamaños, distancias de cámara, posiciones...
export function recorrido(puntos) {
  const p = [...puntos].sort((a, b) => a[0] - b[0]), n = p.length;
  if (n === 1) return () => p[0][1];
  const h = [], s = [];
  for (let i = 0; i < n - 1; i++) { h[i] = p[i + 1][0] - p[i][0]; s[i] = (p[i + 1][1] - p[i][1]) / h[i]; }
  const m = new Array(n).fill(0);
  for (let i = 1; i < n - 1; i++) {
    if (s[i - 1] * s[i] > 0) {
      const w1 = 2 * h[i] + h[i - 1], w2 = h[i] + 2 * h[i - 1];
      m[i] = (w1 + w2) / (w1 / s[i - 1] + w2 / s[i]);
    }
  }
  return (t) => {
    if (t <= p[0][0]) return p[0][1];
    if (t >= p[n - 1][0]) return p[n - 1][1];
    let i = 0;
    while (t > p[i + 1][0]) i++;
    const u = (t - p[i][0]) / h[i], u2 = u * u, u3 = u2 * u;
    return (2 * u3 - 3 * u2 + 1) * p[i][1] + (u3 - 2 * u2 + u) * h[i] * m[i] + (3 * u2 - 2 * u3) * p[i + 1][1] + (u3 - u2) * h[i] * m[i + 1];
  };
}

// Un número que corre de a a b entre t0 y t1, ya redondeado.
export const cuenta = (t, t0, t1, a, b, dec = 0) => Number(entre(t, t0, t1, a, b, llega).toFixed(dec));
