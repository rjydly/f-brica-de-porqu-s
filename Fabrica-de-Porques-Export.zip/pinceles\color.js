// Colores: mezclar, oscurecer, aclarar y poner transparencia a un hex.

const aRgb = (hex) => {
  const h = hex.replace("#", "");
  const n = h.length === 3 ? h.split("").map((x) => x + x).join("") : h;
  return [parseInt(n.slice(0, 2), 16), parseInt(n.slice(2, 4), 16), parseInt(n.slice(4, 6), 16)];
};
const aHex = (r, g, b) => "#" + [r, g, b].map((x) => Math.round(Math.max(0, Math.min(255, x))).toString(16).padStart(2, "0")).join("");

export const rgb = aRgb;
export const mezclaColor = (a, b, u) => { const x = aRgb(a), y = aRgb(b); return aHex(x[0] + (y[0] - x[0]) * u, x[1] + (y[1] - x[1]) * u, x[2] + (y[2] - x[2]) * u); };
export const oscurece = (hex, k = 0.2) => mezclaColor(hex, "#000000", k);
export const aclara = (hex, k = 0.2) => mezclaColor(hex, "#ffffff", k);
export const alfa = (hex, a) => { const [r, g, b] = aRgb(hex); return `rgba(${r},${g},${b},${a})`; };
export const luminancia = (hex) => { const [r, g, b] = aRgb(hex); return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255; };
