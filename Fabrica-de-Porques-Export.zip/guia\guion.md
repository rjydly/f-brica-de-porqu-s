# El guion, escrito para verse

Nadie abre una red social para estudiar: la abre para que algo le sorprenda. Un vídeo se ve hasta el final si cada
frase enseña algo que no esperaba, y se comparte si al acabar entiende algo que antes no entendía. El guion manda
sobre todo lo demás, y se escribe pensando ya en lo que se va a ver.

## Un guion, frase a frase

El de `ejemplo/palomitas/`:

| Frase | Qué hace | Qué se ve |
|---|---|---|
| ¿Por qué el maíz de palomitas explota y el de la mazorca no? | La pregunta que se va a contestar, con el nombre de la cosa. | En el fotograma 0, un grano tiembla en la sartén y revienta en una palomita enorme; la cámara va al grano de mazorca, que solo se tuesta. |
| Los dos son maíz, pero solo uno salta. | La creencia que rompe, demostrada. | Los dos granos juntos; la palomita da un bote con voltereta. |
| Dentro de cada grano hay una gotita de agua. | La primera pieza del mecanismo, pequeña y rara. | El grano cortado, enorme; aparece la gota en el centro. |
| Al calentarlo, esa agua se convierte en vapor y quiere salir. | Causa y efecto. | Se encienden las llamas; la gota se deshace en bolitas de vapor que empujan la cáscara. |
| En el maíz normal, la cáscara tiene poros, y el vapor se escapa poco a poco. | La comparación que explica la diferencia. | El grano de mazorca cortado: el vapor sale a hilitos por sus poros. |
| Pero la del maíz de palomitas es dura y no deja salir nada, como una olla a presión. | El dato clave, con algo de casa. | La cáscara engorda; las flechas chocan y vuelven. Entra la olla a presión silbando. |
| A unos ciento ochenta grados, la presión dentro es nueve veces la del aire, y la cáscara revienta. | Las cifras, y lo que pasa. | «180 °C», «presión × 9»; el grano se hincha, tiembla y estalla. |
| El almidón de dentro se hincha como una espuma, hasta cuarenta veces su tamaño. | El resultado, con una cifra que se ve. | La espuma crece hasta ser una palomita enorme; al lado, el grano de antes, pequeñito. |
| Y salta porque le sale una patita de espuma que empuja contra la sartén. | El segundo «¡anda!» a mitad de vídeo. | A cámara lenta, le sale una pata, se aplasta contra la sartén y lo lanza. |
| Lo que suena no es la cáscara: es el vapor saliendo de golpe. | Otra creencia que cae. | Una cruz roja sobre la raja; luego, el chorro de vapor con sus ondas de sonido. |
| Así que el secreto no está dentro del grano: está en su cáscara. | El giro final: contesta el gancho del todo. | Los dos granos como al principio; se marca la cáscara del de palomitas. |
| Envíaselo a quien siempre quema las palomitas. | El cierre del creador. | En un cuenco lleno, cae una palomita quemada que humea. |

Fíjate en que ninguna frase dice algo que no se pueda ver pasar, y en que las comparaciones son de casa (una olla a
presión, un globo, una esponja).

## El gancho

Es lo más importante del vídeo y lo que más trabajo lleva. Se juzga siempre junto con su imagen: buenas palabras sobre
una imagen quieta, oscura o pequeña no paran a nadie. Tiene que pasar estas pruebas:

1. **La primera frase dice de qué va, como lo diría la gente:** la pregunta que el vídeo contesta ("¿Por qué...?"),
   la sorpresa sin rodeos ("¿Sabías que...?") o lo imposible que se va a enseñar. Con el nombre de la cosa (el maíz,
   el microondas, el aire acondicionado), nunca "esto" o "esta máquina".
2. **Se ve desde el fotograma 0**, en su momento más espectacular, grande y moviéndose. Primero lo imposible; luego, si
   hace falta, se explica.
3. **Abre una pregunta** que pide ver la respuesta, y no la contesta todavía.
4. **Se entiende a la primera,** dicho en voz alta, con palabras de todos los días.
5. **Habla de algo que quien mira conoce, o le habla a él** ("tú", "te"), si el tema lo permite.

Nunca, en el gancho:
- una fecha, un lugar o un "hace X años" delante;
- un "según los expertos" o "al parecer";
- tono de telediario ("Un estudio ha revelado...");
- anunciar en lugar de intrigar ("Te cuento", "En este vídeo", "Atento a esto");
- hablar de quien hace el vídeo;
- "uno de los más...".

Si el creador critica un gancho, se rehacen a la vez las palabras y la imagen.

Ejemplos de cómo mejorar un gancho:

| Antes | Por qué no | Después |
|---|---|---|
| «Ayer pusiste palomitas y no pensaste en lo que pasaba dentro.» | Es una escena: no dice de qué va. | «¿Por qué el maíz de palomitas explota y el de la mazorca no?» |
| «Este aparato calienta la comida sin calentar el plato.» | "Este aparato" no es su nombre. | «¿Por qué el microondas calienta la sopa y no el plato?» |
| «A 180 grados pasa algo increíble.» | Empieza por una cifra y anuncia. | «¿Sabías que una palomita salta porque le crece una pata?» |

## El cuerpo

- **Como se habla:** frases cortas, unidas con "así que", "por eso", "pero". Que lo entienda un niño de diez años.
- **Cada cosa, siempre con el mismo nombre:** si es "el grano", es "el grano" todo el vídeo.
- **Un hilo de curiosidad:** cada frase contesta lo que dejó la anterior y abre la siguiente. La respuesta entera, al
  final.
- **Una sola historia:** todo cuenta lo que abrió el gancho.
- **Cada frase se ve pasar:** algo que cae, se rompe, crece, se llena o se apaga; una causa con su efecto; una
  comparación con algo que quien mira tiene en casa. Si no, se reescribe o se quita.
- **Ni una frase de más.** Dura lo que pide la historia (casi siempre 40-60 s).
- **Los datos, ciertos.** Cada cifra y cada nombre, en `idea.md` con su fuente. Redondea solo hacia lo honesto. Si
  dudas de un dato, quítalo: un dato falso hunde el vídeo y la confianza.

## El giro final y el cierre

- **El giro final** contesta del todo la pregunta del gancho y le da la vuelta a lo que creía quien mira.
- **El cierre** es el del creador (`preferencias.md`), tal cual. Se ve con la cosa del vídeo una última vez.

## guion.json y pie.txt

```json
{
  "titulo": "Las palomitas",
  "idioma": "es",
  "estilo": "papel",
  "subtitulos": "arriba",
  "frases": [
    { "dice": "¿Por qué el maíz de palomitas explota y el de la mazorca no?", "resalta": "explota", "gancho": true },
    { "dice": "Los dos son maíz, pero solo uno salta.", "resalta": "salta", "gancho": true }
  ]
}
```

- `dice`: lo que se dice y sale en el subtítulo.
- `resalta`: la palabra marcada de esa frase (una por frase).
- `gancho: true`: las frases del gancho.
- `pronuncia` (opcional): cómo debe sonar si se lee distinto ("IA" → "i a", "4.000" → "cuatro mil").
- `estilo` (opcional): el estilo de este vídeo; si no está, el de `fabrica.config.json`.
- `voz` (opcional): `{ "id", "modelo", "estabilidad", "parecido", "expresion", "velocidad" }` solo para este vídeo.
- `subtitulos`: `arriba` (lo normal), `abajo` o `no`.

`pie.txt` es el texto del post: dos líneas, la primera engancha. Sin hashtags y sin rayas largas.

El `guion.md` vive en la carpeta del vídeo y es el que se escribe y se corrige. `node fabrica.mjs guion <video>` lo
convierte en `guion.json`: coge las frases de la tabla y marca como gancho las primeras filas (`--gancho 3` si son
tres). No se escribe `guion.json` a mano salvo para un ajuste suelto (`pronuncia`, `voz`).

Si el creador explica su idea (de qué va, qué quiere que se entienda, cómo empieza o cómo acaba), el guion sigue esa
idea: se investiga y se escribe a partir de ella, sin cambiarle el sentido. Si pide cambios en el guion, se hacen
antes de dibujar y se le enseña otra vez entero.

Si el creador trae su propio texto, ese es el guion: no se reescribe ni se le quitan datos; solo se avisa si algo
parece falso.
