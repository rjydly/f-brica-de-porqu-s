# Plan: por qué explotan las palomitas

## Los sitios

- **La sartén** (de lado, caliente): los dos granos, el de palomitas y el de mazorca. Gancho, la patita y el remate.
- **Dentro del grano de palomitas** (cortado, enorme): el agua, el vapor, la presión, el reventón y la espuma.
- **Dentro del grano de mazorca** (cortado): la cáscara con poros por donde se escapa el vapor.
- **La olla a presión**: la comparación, con su frase.
- **El primer plano de la palomita**: lo que suena.
- **El cuenco**: el cierre.

## Frase a frase

| # | Frase (resalta) | Lo que se ve, de la primera palabra a la última | Momento fuerte | Cámara | Paso |
|---|---|---|---|---|---|
| 1 | ¿Por qué el maíz de palomitas explota y el de la mazorca no? (explota) | Fotograma 0: los dos granos en la sartén, que tiembla de calor. El de palomitas revienta a los 0,3 s en una palomita enorme con trozos de cáscara volando. En «mazorca», la cámara va al otro grano: solo se tuesta y echa un hilo de humo. | revienta en 0,3 s; humo en «mazorca» | cerca de la palomita → hacia el grano de mazorca | sigue |
| 2 | Los dos son maíz, pero solo uno salta. (salta) | Se ven los dos juntos. En «salta» la palomita da un bote con voltereta y cae. | «salta» | se aleja para ver los dos | corte en «Dentro» |
| 3 | Dentro de cada grano hay una gotita de agua. (agua) | El grano de palomitas cortado, enorme: cáscara, almidón. En «gotita» aparece la gota azul en el centro y se queda; rótulo «agua». | «gotita» | se acerca a la gota | sigue |
| 4 | Al calentarlo, esa agua se convierte en vapor y quiere salir. (vapor) | Llamas debajo; la gota tiembla y en «vapor» se deshace en bolitas de vapor que llenan el grano; en «salir», flechas que empujan la cáscara desde dentro. | «vapor» | se aleja un poco para ver el grano entero | corte en «En» |
| 5 | En el maíz normal, la cáscara tiene poros, y el vapor se escapa poco a poco. (escapa) | El grano de mazorca cortado, con su cáscara llena de agujeritos; en «poros» se marcan; el vapor sale por ellos a hilitos durante toda la frase. | «escapa» | se acerca a un poro | corte en «Pero» |
| 6 | Pero la del maíz de palomitas es dura y no deja salir nada, como una olla a presión. (olla) | Vuelve el grano de palomitas: su cáscara engorda en «dura»; las flechas chocan y rebotan en «nada». En «como», la olla a presión con la tapa que tiembla y la válvula silbando. | «dura», «olla» | quieta en el grano; la olla entra entera | corte en «como» y en «A» |
| 7 | A unos ciento ochenta grados, la presión dentro es nueve veces la del aire, y la cáscara revienta. (revienta) | El grano otra vez, con el termómetro: la cifra 180 °C en «ochenta»; el grano se hincha y tiembla; «×9» en «nueve»; en «revienta» la cáscara se raja y estalla. | «revienta» | se acerca mientras se hincha | sigue |
| 8 | El almidón de dentro se hincha como una espuma, hasta cuarenta veces su tamaño. (espuma) | La espuma blanca sale y crece hasta ser una palomita que llena la pantalla; «×40» en «cuarenta». | «espuma», «cuarenta» | se aleja con la espuma | corte en «Y» |
| 9 | Y salta porque le sale una patita de espuma que empuja contra la sartén. (patita) | La sartén otra vez, a cámara lenta: al grano le sale una patita hacia abajo en «patita»; en «empuja» se aplasta contra la sartén y lo lanza dando la vuelta. | «empuja» | sube con el salto | corte en «Lo» |
| 10 | Lo que suena no es la cáscara: es el vapor saliendo de golpe. (vapor) | Primer plano de la cáscara rajándose: una cruz roja en «cáscara»; en «vapor», un chorro de vapor sale por la raja con ondas de sonido. | «golpe» | quieta | corte en «Así» |
| 11 | Así que el secreto no está dentro del grano: está en su cáscara. (cáscara) | Los dos granos en la sartén, como al principio. En «cáscara» se marca la cáscara del de palomitas con su rótulo. | «cáscara» | se acerca al grano de palomitas | corte en «Envíaselo» |
| 12 | Envíaselo a quien siempre quema las palomitas. (quema) | Un cuenco lleno de palomitas; en «quema» cae encima una negra que humea. | «quema» | quieta | fin |
