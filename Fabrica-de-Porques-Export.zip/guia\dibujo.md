# Cómo se dibuja

Todo se dibuja con código en un lienzo de 1080 × 1920, fotograma a fotograma. No hay metraje ni plantillas: el mundo
de cada vídeo se construye para él. Cómo se ve (colores, contornos, sombras, letra) lo pone **el estilo**; cómo se
mueve y qué se dibuja lo pones tú. Mira `guia/estilos.jpg`, `guia/catalogo.jpg` y las escenas de `ejemplo/`.

## Cómo está hecho un vídeo

```
video/comun.js                lo que comparten las escenas: la misma cosa, el mismo sitio, dibujos propios
video/escenas/01-grano.js     una escena por archivo; se ordenan por cuándo empiezan
video/escenas/02-...js
video/alternativas/01-...js   la otra versión del gancho, con el número de la escena a la que sustituye
efectos.js                    los efectos de sonido (guia/sonido.md)
```

Una escena exporta:
- `empieza`: cuándo entra. Una palabra (`"presión"`), la misma palabra en una frase concreta (`"pero@6"`: el «pero» de
  la frase 6), la segunda vez que se dice (`"grano#2"`), unos segundos, o una función `(voz) => segundos`. **Una
  palabra sola se busca en toda la voz:** si se repite («en», «pero», «el»), usa siempre `palabra@frase`. La imagen llega dos fotogramas antes que la palabra. La primera escena empieza en 0
  y cada una dura hasta que empieza la siguiente.
- `paso`: cómo se entra desde la anterior. `"corte"` (lo normal: otro sitio), `"sigue"` (el mismo sitio y la misma
  cámara, partido en dos archivos solo por orden), `"funde"` o `"barrido"` (rara vez).
- `pinta(c, t)`: dibuja el fotograma del segundo `t` **del vídeo** (no de la escena) en el lienzo `c`. El motor lo
  limpia antes con el fondo del estilo y pone los subtítulos encima: no los dibujes tú.
- Lo que necesite el sonido, exportado: `export const botes = [...]` con el segundo de cada bote. `efectos.js` lo
  importa y así el sonido sigue a la imagen aunque cambie.

```js
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
import { grano } from "../comun.js";

export const empieza = "presión";
const T = voz.frase(5).en("revienta");   // una palabra buscada dentro de su frase: lo más seguro

export function pinta(c, t) {
  e.fondo(c, { disco: [540, 1050, 430] });
  const hincha = p.entre(t, T - 0.6, T, 1, 1.25, p.parte);       // se hincha despacio y revienta en su palabra
  e.objeto(c, (c) => grano(c, 540, 1050, 300 * hincha));
  e.ondas(c, 540, 1050, t, { r0: 340 });
}
```

**Reglas que no se rompen:**
- **Todo sale de `t`.** Nada se guarda de un fotograma al siguiente: el render dibuja trozos del vídeo a la vez en
  varios hilos, y cualquier fotograma tiene que poder dibujarse solo.
- **El azar, con semilla:** `p.azar(semilla)`. Nunca `Math.random`.
- **Lo pesado, una vez, arriba del archivo:** listas de partículas, imágenes, formas calculadas. Cada fotograma debe
  dibujarse en menos de 0,1 s.
- **Los colores, por su papel y del estilo:** `"principal"`, `"secundario"`, `"acento"`... o `e.color.tinta`. Nunca
  un hex a mano (salvo un tono que el estilo no tenga, como el gris de una rueda). Así el vídeo cambia de estilo con
  una palabra.
- **El tiempo de la voz:** `voz.en("palabra")`, `voz.en("palabra", 2)`, `voz.fin("palabra")`, `voz.frase(n)` (con su
  `desde`, `hasta`, `palabras`, `en()` y `fin()`). Las palabras se buscan sin tildes ni signos: «¿Qué» es `"que"`.

## La pantalla

- **Los subtítulos van arriba,** en la franja de y 330 a 510. Ahí no va nada importante.
- **Instagram tapa** lo que queda por encima de y 270, por debajo de y 1440 y la columna de botones de la derecha
  (x > 950 desde y 1050). Lo importante, dentro.
- **Grande:** la cosa principal ocupa media pantalla o más. Nunca algo pequeño en medio de un fondo vacío.

## Lo que pone el estilo (`import { estilo as e } from "#estilo"`)

| Función | Para qué |
|---|---|
| `e.fondo(c, { disco: [x, y, r], suelo: y })` | el fondo, al empezar cada fotograma; un disco detrás de la cosa o un suelo |
| `e.objeto(c, (c) => { ... }, { opacidad })` | una cosa entera: lo de dentro se dibuja junto y recibe la sombra del estilo; con opacidad aparece o se va entera |
| `e.pieza(c, camino, papel, { plano })` | una pieza rellena con su volumen y su borde; `camino(c)` traza la forma |
| `e.caja(c, x, y, w, h, radio, papel)` · `e.bola(c, x, y, r, papel)` | atajos de pieza |
| `e.trazo(c, camino, { papel, grosor })` | una línea con el pincel del estilo (cables, caminos, contornos) |
| `e.flecha(c, x0, y0, x1, y1, { u })` | lo invisible que empuja o va hacia un sitio; `u` de 0 a 1 la hace crecer |
| `e.ondas(c, x, y, t, { r0, ang, abre })` | lo invisible que sale de algo: sonido, calor, señal |
| `e.rotulo(c, x, y, "texto", { apunta: [x, y] })` | el nombre de una pieza, con su línea hasta ella |
| `e.cifra(c, x, y, "180 °C", { opacidad })` | una cifra grande en su placa |
| `e.letra("fuerte", 80)` | la letra del estilo, para cualquier texto propio |
| `e.cielo(c, { tiempo, t, viento, suelo })` | en lugar de `e.fondo` cuando la escena pasa al aire libre: `"despejado"` (de día), `"nublado"` (tormenta, tifón) o `"noche"`; las nubes corren con `t` y `viento` |
| `e.lluvia(c, t, { tiempo, fuerza, opacidad })` | la lluvia, inclinada por el viento y del color de su cielo |
| `e.color.<papel>` | los colores: `principal`, `secundario`, `acento`, `neutro`, `metal`, `piel`, `claro`, `oscuro`, `tinta`, `invisible`, `mal`, `bien`, `fondo`, `fondo2` |

Cada papel tiene su sombra (`e.color.principalSombra`). Los papeles `invisible` (fuerza, aire, calor, sonido), `mal` y
`bien` son solo para eso.

## Lo que no depende del estilo (`import * as p from "#pincel"`)

- **Tiempo:** `p.rango(t, a, b)` (de 0 a 1 entre a y b) · `p.suaviza(u)` (arranca y frena) · `p.llega(u)` (llega
  rápido y frena: lo que entra) · `p.parte(u)` (arranca despacio y se va rápido: lo que sale) · `p.rebota(u)` (se
  pasa un poco y vuelve) · `p.muelle(u)` · `p.entre(t, t0, t1, a, b, curva)` · `p.latido(t, t0, ancho)` ·
  `p.visible(t, a, b, fundido)` · `p.recorrido([[t, valor], ...])` (pasa por varios valores sin tirones) ·
  `p.cuenta(t, t0, t1, a, b)` (un número que corre).
- **Formas** (solo trazan; se rellenan con `e.pieza`): `p.rectRedondo`, `p.circulo`, `p.ovalo`, `p.poligono`,
  `p.poligonoRedondo`, `p.estrella`, `p.gota`, `p.nube`, `p.corazon`, `p.rayo`, `p.linea` (para `e.trazo`) y
  `p.mano(c, x, y, alto, giro, { dobla, izquierda })`, con cinco dedos.
- **Cámara 3D:** `p.camara(pos, objetivo)` devuelve `cam.ve([x, y, z])` → `{ x, y, z, k }` en pantalla (`k`: píxeles por
  unidad a esa distancia) o `null` si queda detrás. `p.viaje([[t, { pos, mira }], ...])` es una cámara que pasa por
  esas paradas sin tirones. `p.orbita(ángulo, distancia, altura)` da un punto alrededor de algo.
  `p.porProfundidad([{ z, pinta() }])` dibuja de lejos a cerca.
- **Cámara 2D:** para escenas planas, `p.pantalla(c, { x, y, zoom, giro }, () => { ...la escena... })` dibuja como si
  la cámara mirara al punto (x, y) con ese zoom. Animar `x`, `y` y `zoom` con `p.recorrido` es la forma más fácil de
  que la cámara viaje por un sitio.
- **Capas e imágenes:** `p.enCapa(c, pinta, { opacidad })`, `await p.imagen(ruta)` (arriba del archivo) y
- **Tomas de Blender:** `p.toma(carpeta).pinta(c, t)` pone el fotograma del segundo `t` de una toma renderizada en
  Blender (fondo transparente). Cuándo y cómo, en `guia/blender.md`.
  `p.foto(c, img, x, y, w, h, radio)`.
- **Azar:** `const r = p.azar("granos")`, luego `r()`, `r.entre(a, b)`, `r.entero(a, b)`, `r.uno(lista)`.
  `p.ondula(x, semilla)` da un temblor suave sin saltos.
- **Colores:** `p.mezclaColor(a, b, u)`, `p.oscurece(hex, k)`, `p.aclara(hex, k)`, `p.alfa(hex, a)`.

## De día o de noche

El fondo oscuro del estilo es para lo que no tiene sitio (dentro de un grano, un esquema, el espacio) o pasa de noche.
**Lo que pasa al aire libre y de día va con `e.cielo`:** un edificio, una playa, una calle, el campo. Una tormenta o un
tifón de día es `"nublado"`, no de noche.

**Cada cosa con su color de verdad.** El color principal del estilo no sirve para todo: un edificio es de cristal,
hormigón o acero (grises, verdes apagados, ocres), no del color del estilo. Que el principal no se repita en todo.

## La cámara solo se mueve cuando la voz lo pide

Entra a ver lo que se nombra, se aleja para ver el conjunto, gira para enseñar lo de detrás o baja con lo que cae.
Nunca deriva sola, nunca tiembla porque sí y nunca hace zoom sin motivo.

## El tiempo del movimiento

- **Cada movimiento empieza y acaba en una palabra y dura lo que su frase.** Un golpe o una cifra, rápido y en su
  palabra; lo que se construye mientras se explica, toda la explicación.
- **La cosa grande hace algo durante toda la frase,** no solo en su palabra: gira, hierve, cae, crece o se apaga. Una
  imagen que aparece y se queda quieta es una diapositiva.
- **Lo que la voz nombra llega y se queda** al menos medio segundo entero y casi quieto.
- **Antes de un cambio de escena, todo ha acabado** y la imagen reposa un instante.

## Cuando los pinceles no tienen lo que necesitas

Pasará casi siempre: cada tema tiene sus cosas. Se dibujan pieza a pieza:
1. **La forma** con caminos (`beginPath`, `quadraticCurveTo`, `bezierCurveTo`, `p.rectRedondo`) y sus proporciones de
   verdad. Busca una foto para saber cómo es.
2. **Sus piezas,** cada una con `e.pieza` y su papel de color, y todas juntas dentro de `e.objeto`.
3. **Mírala grande** (`node fabrica.mjs mirar <video> <segundo>`) antes de moverla. Si parece un icono o un juguete, le
   faltan piezas: añádelas (los botones, la rosca, el texto real de una pantalla, las patas).

Si algo sale en más de una escena, va en `video/comun.js` una vez. Si sirve para otros vídeos, puede ir a
`pinceles/formas.js`, con su muestra en `ordenes/catalogo.mjs`.

Cuando el tema es una persona, una marca o un sitio real, una foto real (con su licencia, apuntada en `notas.md`)
puesta en la escena es mejor que un muñeco: `const f = await p.imagen("ruta.jpg")` arriba y `p.foto(c, f, ...)`
dentro de `e.objeto`.

## Mirar lo que se dibuja

```
node fabrica.mjs mirar <video> 12.4              un fotograma grande
node fabrica.mjs mirar <video> 9-11.5 --fps 10   un tramo
node fabrica.mjs mirar <video> frase 5           una frase, de su primera palabra a la última
node fabrica.mjs mirar <video> palabra presión   alrededor de una palabra, a 30 fps
node fabrica.mjs mirar <video> cambio 2          un cambio de escena, a 30 fps
node fabrica.mjs mirar <video> escenas           el principio, el medio y el final de cada escena
```

Cada una tarda segundos y deja un `.jpg` en `revisar/`: ábrelo siempre. Qué buscar, en `METODO.md`, paso 7.
