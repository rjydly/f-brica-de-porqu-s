// Papel: el único estilo de fondo claro. Fondo crema liso, cada cosa con su contorno de tinta, colores vivos y planos,
// su sombra propia en la parte de abajo a la derecha y una sombra de papel recortado debajo. Como una ilustración
// editorial o un cómic limpio.
import { creaEstilo, debajo } from "../comun.js";

export default creaEstilo({
  nombre: "papel",
  descripcion: "Fondo crema, contorno de tinta, colores vivos y planos, sombra de papel recortado.",
  color: {
    fondo: "#f4ecdf", fondo2: "#e8dcc6", suelo: "#e3d4ba",
    tinta: "#26221d",                                 // contornos, líneas y texto sobre el fondo
    principal: "#3f7fd9", principalSombra: "#2d5fae", // azul cielo: el color de las cosas
    secundario: "#ee6b4d", secundarioSombra: "#c44e34", // tomate
    acento: "#f5c344", acentoSombra: "#d69f1f",       // sol: calor, energía, lo que se marca
    neutro: "#5cb88a", neutroSombra: "#3f9169",       // menta
    metal: "#b8bec7", metalSombra: "#8e96a2",
    piel: "#f1b48e", pielSombra: "#d58f68",
    claro: "#fffdf7", claroSombra: "#efe6d6",         // pantallas, papeles, etiquetas
    oscuro: "#26221d",                                // texto sobre lo claro
    invisible: "#8f5cf6",                             // fuerza, aire, calor, sonido: solo eso
    mal: "#e2412c", bien: "#2fa866",
    sombraObjeto: "rgba(38,34,29,0.2)",
  },
  letras: { fuerte: "nunito-900", media: "nunito-800", normal: "nunito-700" },
  grosor: 7,
  borde: true,
  // relleno, su sombra propia (la misma forma desplazada abajo a la derecha, recortada) y el contorno de tinta
  pieza(c, camino, [color, sombra], { plano = false, sinBorde = false, grosor } = {}, e) {
    c.save();
    // el contorno va por debajo y al doble: así solo se ve el de fuera, aunque la forma tenga piezas solapadas
    if (!sinBorde) { camino(c); c.lineJoin = "round"; c.lineCap = "round"; c.lineWidth = 2 * (grosor ?? e.grosor); c.strokeStyle = e.color.tinta; c.stroke(); }
    camino(c); c.fillStyle = color; c.fill();
    if (!plano) {
      // la sombra propia: todo en sombra y, encima, el color desplazado hacia la luz
      c.save(); camino(c); c.clip();
      c.fillStyle = sombra; c.fill();
      c.translate(-22, -22); camino(c); c.fillStyle = color; c.fill();
      c.restore();
    }
    c.restore();
  },
  // sombra de papel recortado: la silueta, translúcida y dura, abajo a la derecha
  sombra(g, capa, e) { debajo(g, capa, e.color.sombraObjeto, 16, 18); },
  subtitulos: {
    tam: 76, linea: 86, letra: "nunito-900", letraDicha: "nunito-800",
    color: "#26221d", dicho: "#8a7f70", contorno: "#fffdf7", grosorContorno: 14,
    resalte: "rotulador", colorResalte: "#f5c344",
  },
});
