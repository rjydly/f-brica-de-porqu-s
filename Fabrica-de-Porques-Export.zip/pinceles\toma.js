// Las tomas que vienen de fuera (Blender): una carpeta de fotogramas PNG con fondo transparente, 00000.png, 00001.png…
// Cada fotograma se lee al dibujarlo (el Image del lienzo descodifica los PNG más tarde, y el fotograma tiene que
// dibujarse ya). Cómo se hacen, en guia/blender.md.
import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { inflateSync } from "node:zlib";
import { createCanvas, ImageData } from "@napi-rs/canvas";

// Un PNG de 8 bits (RGB o RGBA, sin entrelazar), como los que guarda Blender.
function leePng(buf) {
  const ancho = buf.readUInt32BE(16), alto = buf.readUInt32BE(20), canales = buf[25] === 6 ? 4 : 3;
  const trozos = [];
  for (let i = 8; i < buf.length;) {
    const largo = buf.readUInt32BE(i), tipo = buf.toString("ascii", i + 4, i + 8);
    if (tipo === "IDAT") trozos.push(buf.subarray(i + 8, i + 8 + largo));
    if (tipo === "IEND") break;
    i += 12 + largo;
  }
  const crudo = inflateSync(Buffer.concat(trozos)), fila = ancho * canales;
  const datos = new Uint8ClampedArray(ancho * alto * 4), linea = new Uint8Array(fila), previa = new Uint8Array(fila);
  for (let y = 0; y < alto; y++) {
    const o = y * (fila + 1), filtro = crudo[o];
    for (let x = 0; x < fila; x++) {
      const v = crudo[o + 1 + x], a = x >= canales ? linea[x - canales] : 0, b = previa[x], cc = x >= canales ? previa[x - canales] : 0;
      let p;
      if (filtro === 0) p = v;
      else if (filtro === 1) p = v + a;
      else if (filtro === 2) p = v + b;
      else if (filtro === 3) p = v + ((a + b) >> 1);
      else { const q = a + b - cc, pa = Math.abs(q - a), pb = Math.abs(q - b), pc = Math.abs(q - cc); p = v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : cc); }
      linea[x] = p;
    }
    const d = y * ancho * 4;
    if (canales === 4) datos.set(linea, d);
    else for (let x = 0; x < ancho; x++) { datos[d + x * 4] = linea[x * 3]; datos[d + x * 4 + 1] = linea[x * 3 + 1]; datos[d + x * 4 + 2] = linea[x * 3 + 2]; datos[d + x * 4 + 3] = 255; }
    previa.set(linea);
  }
  return { ancho, alto, datos };
}

// toma(carpeta, { fps }) → { pinta(c, t, { x, y, escala, opacidad }), puntos(t) }. carpeta: una ruta o una URL
// (new URL("../blender/gancho", import.meta.url)). El fotograma del segundo t del vídeo; si la carpeta trae
// puntos.json ({ fps, desde, hasta, f: { "<fotograma>": {...} } }), puntos(t) da lo que apuntó Blender en ese fotograma.
export function toma(carpeta, { fps = 60 } = {}) {
  const dir = carpeta instanceof URL ? fileURLToPath(carpeta) : String(carpeta);
  const rutaInfo = join(dir, "puntos.json");
  const info = existsSync(rutaInfo) ? JSON.parse(readFileSync(rutaInfo, "utf8")) : { fps, desde: 0, hasta: 1e6, f: {} };
  const cuadro = (t) => Math.max(info.desde ?? 0, Math.min(info.hasta ?? 1e6, Math.round(t * (info.fps || fps))));
  const ruta = (f) => join(dir, String(f).padStart(5, "0") + ".png");
  let hoja = null;
  return {
    pinta(c, t, { x = 0, y = 0, escala = 1, opacidad = 1 } = {}) {
      let f = cuadro(t);
      while (!existsSync(ruta(f)) && f > (info.desde ?? 0)) f--;   // mientras se renderiza, el último que haya
      if (!existsSync(ruta(f)) || opacidad <= 0.01) return;
      const { ancho, alto, datos } = leePng(readFileSync(ruta(f)));
      if (!hoja || hoja.width !== ancho || hoja.height !== alto) hoja = createCanvas(ancho, alto);
      hoja.getContext("2d").putImageData(new ImageData(datos, ancho, alto), 0, 0);
      c.save(); c.globalAlpha *= opacidad; c.drawImage(hoja, x, y, ancho * escala, alto * escala); c.restore();
    },
    puntos(t) {
      const claves = Object.keys(info.f || {});
      if (!claves.length) return null;
      const f = cuadro(t);
      return info.f[String(f)] || info.f[claves.sort((a, b) => Math.abs(a - f) - Math.abs(b - f))[0]];
    },
  };
}
