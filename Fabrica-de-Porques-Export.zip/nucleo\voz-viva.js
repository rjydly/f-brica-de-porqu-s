// La línea de tiempo de la voz del vídeo que se está dibujando. El motor la rellena antes de cargar las escenas, así
// que cualquier archivo del vídeo puede usarla desde arriba del todo:
//
//   import { voz } from "#voz";
//   voz.en("sodio")          segundo en que empieza la primera «sodio»
//   voz.en("sodio", 2)       la segunda (también "sodio#2")
//   voz.fin("sodio")         segundo en que termina
//   voz.frase(4)             la cuarta frase: { n, dice, desde, hasta, resalta, gancho, palabras, en(), fin() }
//   voz.frase(4).en("sal")   una palabra buscada solo dentro de esa frase (lo más seguro)
//   voz.dura                 lo que dura el vídeo
// Cada palabra es { dice, desde, hasta, frase, resaltada }.
//
// Las palabras se comparan sin tildes, mayúsculas ni signos: «¿Qué» se busca como "que".

export const normal = (s) => String(s).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9ñ]/g, "");

function busca(lista, que, n, donde) {
  let palabra = String(que), cual = n ?? 1;
  const m = /^(.+)#(\d+)$/.exec(palabra);
  if (m) { palabra = m[1]; cual = Number(m[2]); }
  const objetivo = normal(palabra);
  const iguales = lista.filter((w) => normal(w.dice) === objetivo);
  if (iguales[cual - 1]) return iguales[cual - 1];
  const pistas = [...new Set(lista.map((w) => normal(w.dice)).filter((x) => x[0] === objetivo[0] && x.length > 2))].slice(0, 10);
  throw new Error(`«${que}» no está ${cual > 1 ? `${cual} veces ` : ""}en ${donde} (está ${iguales.length}).${pistas.length ? " ¿Quizá " + pistas.join(", ") + "?" : ""}`);
}

export const voz = {
  dura: 0,
  palabras: [],
  frases: [],
  en(p, n) { return busca(this.palabras, p, n, "la voz").desde; },
  fin(p, n) { return busca(this.palabras, p, n, "la voz").hasta; },
  palabra(p, n) { return busca(this.palabras, p, n, "la voz"); },
  frase(n) {
    const f = this.frases[n - 1];
    if (!f) throw new Error(`La voz tiene ${this.frases.length} frases; no hay frase ${n}.`);
    return f;
  },
  // la palabra que suena (o la última que sonó) en el segundo t
  suena(t) {
    let ultima = null;
    for (const w of this.palabras) { if (w.desde > t + 1e-3) break; ultima = w; }
    return ultima;
  },
};

export function rellenaVoz(linea) {
  voz.dura = linea.dura;
  voz.palabras = linea.palabras;
  voz.frases = linea.frases.map((f) => {
    const suyas = linea.palabras.filter((w) => w.frase === f.n);
    return {
      ...f,
      palabras: suyas,
      en: (p, n) => busca(suyas, p, n, `la frase ${f.n}`).desde,
      fin: (p, n) => busca(suyas, p, n, `la frase ${f.n}`).hasta,
    };
  });
  return voz;
}
