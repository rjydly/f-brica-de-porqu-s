// «Y salta porque le sale una patita de espuma que empuja contra la sartén.»
// La sartén de cerca, a cámara lenta: el grano ya se ha abierto un poco. En «patita» le sale por debajo una pata de
// espuma que lo levanta; en «empuja» la pata se aplasta contra la sartén y lo lanza dando una vuelta; cae abierto.
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
import { palomita, sarten } from "../comun.js";

export const empieza = "y@9";
const F = voz.frase(9), PATA = F.en("patita"), EMPUJA = F.en("empuja");
export const LANZA = EMPUJA + 0.35, CAE = LANZA + 0.85;
const SUELO = 1480, X = 540;

export function pinta(c, t) {
  e.fondo(c);
  const k = p.rango(t, LANZA, CAE), vuelo = 4 * k * (1 - k);
  const enc = { x: 540, y: 1330 - 300 * vuelo, zoom: p.recorrido([[F.desde, 2.3], [PATA, 2.3], [EMPUJA, 2.1], [LANZA, 1.8]])(t) };
  p.pantalla(c, enc, () => {
    sarten(c, SUELO, t);
    // la pata: sale, se aplasta, empuja y se recoge al despegar
    const sale = p.llega(p.rango(t, PATA - 0.05, PATA + 0.45));
    const aplasta = p.latido(t, EMPUJA + 0.15, 0.17);
    const recoge = p.rango(t, LANZA, LANZA + 0.25);
    const largo = 85 * sale * (1 - 0.55 * aplasta) * (1 - recoge);
    const yGrano = SUELO - 190 - largo - 480 * vuelo, giro = p.suaviza(k) * Math.PI * 2;
    const abre = p.mezcla(0.5, 1, p.rango(t, LANZA, CAE - 0.2));
    e.objeto(c, (c) => {
      c.save(); c.translate(X, yGrano); c.rotate(giro);
      if (largo > 2) e.pieza(c, (g) => p.rectRedondo(g, -36 - 22 * aplasta, 60, 72 + 44 * aplasta, largo + 40, 36), "claro");
      palomita(c, 0, 0, 330, { abre, semilla: 12 });
      c.restore();
    });
    // lo que empuja: hacia abajo contra la sartén, y la sartén lo devuelve hacia arriba
    const fuerza = p.visible(t, EMPUJA - 0.05, LANZA + 0.15, 0.1);
    if (fuerza > 0) e.flecha(c, X + 190, SUELO - 40, X + 190, SUELO - 300, { u: p.llega(p.rango(t, EMPUJA, LANZA)), grosor: 16, opacidad: fuerza });
  });
}
