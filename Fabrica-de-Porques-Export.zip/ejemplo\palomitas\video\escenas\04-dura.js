// «Pero la del maíz de palomitas es dura y no deja salir nada,»
// Vuelve el grano de palomitas lleno de vapor sobre el fuego. En «dura» su cáscara engorda; en «nada» las flechas
// llegan a la cáscara, chocan y vuelven: no sale nada.
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
import { porDentro } from "../comun.js";

export const empieza = "pero@6";
export const paso = "barrido";
const F = voz.frase(6);
export const DURA = F.en("dura"), CHOCA = F.en("nada");

export function pinta(c, t) {
  e.fondo(c, { disco: [540, 1100, 470] });
  const cascara = 0.05 + 0.035 * p.rebota(p.rango(t, DURA - 0.05, DURA + 0.3));
  const flechas = p.rango(t, F.en("deja") - 0.1, CHOCA) + p.rango(t, CHOCA, CHOCA + 0.35);
  porDentro(c, t, { y: 1100, s: 800, vapor: 1, llamas: 1, cascara, flechas, tiembla: 0.25 });
  e.rotulo(c, 640, 640, "dura", { apunta: [700, 760], opacidad: p.visible(t, DURA, F.en("como") - 0.1, 0.15) });
}
