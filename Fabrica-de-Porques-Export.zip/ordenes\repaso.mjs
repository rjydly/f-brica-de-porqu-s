// repaso: todo lo que hay que mirar antes de enseñar el vídeo, en un minuto y sin renderizarlo.
import { existsSync } from "node:fs";
import { join } from "node:path";
import { carpetaVideo, muestras } from "../nucleo/base.mjs";
import { cambios, cortesDe, pulso, subtitulosIlegibles } from "../nucleo/analisis.mjs";
import { leeEfectos, mezcla, silencios, tieneEfectos } from "../nucleo/efectos.mjs";
import { prepara } from "../nucleo/fotograma.mjs";
import { guarda, lamina, reparte } from "../nucleo/laminas.mjs";
import { abre } from "../nucleo/video.mjs";

export const ayuda = `
node fabrica.mjs repaso <video> [--hasta s]

Hace dos láminas (míralas enteras, siempre):
  revisar/frases.jpg    cada frase de su primera palabra a la última: ¿se ve lo que dice, grande y moviéndose?
  revisar/cambios.jpg   cada cambio de escena, de 0,6 s antes a 0,4 s después: ¿había acabado lo de antes?
y avisa de: cambios con lo de antes aún moviéndose, cambios entre dos escenas que se parecen, escenas de menos de
1,5 s, segundos casi quietos, subtítulos que no se leen, huecos sin efectos y efectos que caen en un cambio.
Son sitios donde mirar, no notas: arregla lo que veas mal, no el número.
--hasta: solo hasta ese segundo (para el gancho).
`;

export async function corre({ libres, marcas }) {
  const dir = carpetaVideo(libres[0]), inicio = Date.now();
  const v = await abre(dir);
  if (marcas.hasta) { v.dura = Math.min(v.dura, Number(marcas.hasta)); v.escenas = v.escenas.filter((s) => s.empieza < v.dura); }
  const est = prepara(v), voz = v.voz, avisos = [];

  const tf = [];
  for (const f of voz.frases.filter((f) => f.desde < v.dura)) reparte(f.palabras[0].desde, Math.min(v.dura - 0.01, f.palabras.at(-1).hasta), 6).forEach((t, i) => tf.push(i ? t : { t, nota: `${f.n}: ${t.toFixed(2)}` }));
  const hf = guarda(lamina(v, est, tf, { ancho: 150, columnas: 6, titulo: "Cada frase, de su primera palabra a la última" }), join(dir, "revisar", "frases.jpg"));
  const tc = [];
  for (const s of v.escenas.slice(1)) for (let k = -9; k <= 6; k++) { const t = s.empieza + k / 15; tc.push(k ? t : { t, nota: `→ ${s.paso}` }); }
  const hc = tc.length ? guarda(lamina(v, est, tc, { ancho: 118, columnas: 16, titulo: "Cada cambio de escena: 0,6 s antes y 0,4 s después (15 fps)" }), join(dir, "revisar", "cambios.jpg")) : null;

  console.log(`${v.escenas.length} escenas · ${v.dura.toFixed(2)} s · estilo ${v.estilo}`);
  for (const s of v.escenas) console.log(`  ${s.id.padEnd(24)} ${s.empieza.toFixed(2).padStart(6)}-${s.acaba.toFixed(2).padEnd(6)} ${(s.acaba - s.empieza).toFixed(1).padStart(4)} s  ${s.paso}${typeof s.pedido === "string" ? `  en «${s.pedido}»` : ""}`);

  for (const x of cambios(v, est)) {
    const donde = `cambio ${x.n} (${x.de} → ${x.a}, ${x.t.toFixed(2)} s)`;
    if (x.paso === "sigue") { if (x.salto.fuerza > 2.5) avisos.push(`${donde}: es «sigue» pero la imagen salta (${x.salto.fuerza.toFixed(1)}); no debería notarse nada. Míralo: mirar ${v.nombre} cambio ${x.n}`); continue; }
    if (x.alFinal.area > 0.05 && x.alFinal.fuerza > 3) avisos.push(`${donde}: lo de antes aún se mueve al cambiar (el ${(100 * x.alFinal.area).toFixed(0)} % de la pantalla en la última décima). Que acabe y repose un momento, o cambia más tarde, en otra palabra.`);
    if (x.salto.fuerza < 20 && x.paso === "corte") avisos.push(`${donde}: el último fotograma de antes y el primero de después se parecen (${x.salto.fuerza.toFixed(1)}). Si es el mismo sitio, no cortes: que la cámara vaya dentro de una sola escena. Si es otro sitio, que se note desde su primer fotograma.`);
    if (x.dura < 1.5) avisos.push(`${donde}: la escena nueva dura ${x.dura.toFixed(2)} s; no da tiempo a verla. Dale su frase o métela en la de antes.`);
  }

  const { marcas: linea } = pulso(v, est);
  console.log(`Segundo a segundo (· casi quieto, ~ poco, = algo, # mucho, | cambio):\n  ${linea}`);
  const quietos = [...linea.matchAll(/·{2,}/g)].map((m) => `${m.index}-${m.index + m[0].length} s`);
  if (quietos.length) avisos.push(`Casi quieto en ${quietos.join(", ")}. Si no es el respiro del final, ahí falta algo que pase con la voz.`);

  const malos = subtitulosIlegibles(v, est);
  if (malos.length) avisos.push(`Los subtítulos casi no contrastan con lo de detrás en ${malos.map(([a, b]) => `${a.toFixed(1)}-${b.toFixed(1)} s`).join(", ")}. Aparta lo de detrás de la franja de arriba o cambia su color.`);

  if (tieneEfectos(dir)) {
    const lista = await leeEfectos(dir, voz);
    if (!lista.length) avisos.push("efectos.js está vacío: si el vídeo lleva efectos, ponlos (guia/sonido.md).");
    else {
      const { pista, puestos } = mezcla(lista, muestras(join(dir, "voz", "voz.wav")));
      const h = silencios(pista, 2).filter(([a]) => a < v.dura);
      if (h.length) avisos.push(`Más de 2 s sin ningún efecto: ${h.map(([a, b]) => `${a.toFixed(1)}-${b.toFixed(1)} s`).join(", ")}. Si ahí se mueve algo, le falta su sonido.`);
      for (const e of puestos) for (const c of cortesDe(v)) if (Math.abs(e.t - c) < 0.08) avisos.push(`El efecto «${e.sonido}» de ${e.t.toFixed(2)} s cae en el cambio de ${c.toFixed(2)} s: un corte no suena.`);
      if (!existsSync(join(dir, "sonidos", "efectos.wav"))) avisos.push(`Falta hacer la pista: node fabrica.mjs efectos ${v.nombre}`);
    }
  }

  console.log(avisos.length ? "\nPara mirar:\n" + avisos.map((a) => "  - " + a).join("\n") : "\nNada que avisar. Aun así, mira las dos láminas enteras.");
  console.log(`\nLáminas:\n  ${hf}${hc ? "\n  " + hc : ""}\n(${((Date.now() - inicio) / 1000).toFixed(0)} s)`);
}
