// Lienzos auxiliares: capas para que algo complejo aparezca o se vaya entero, siluetas para sombras e imágenes.
import { createCanvas, loadImage } from "@napi-rs/canvas";

export const hoja = (w, h = w) => createCanvas(Math.max(1, Math.ceil(w)), Math.max(1, Math.ceil(h)));

// Una pila de capas del tamaño del fotograma: enCapa puede ir dentro de otra enCapa.
const pila = [];
let hondo = 0;
function capaLibre(w, h) {
  if (!pila[hondo] || pila[hondo].width !== w || pila[hondo].height !== h) pila[hondo] = createCanvas(w, h);
  return pila[hondo];
}

// enCapa(c, pinta, { opacidad, modo }): pinta(c2) dibuja en una capa aparte con la misma transformación que c; luego la
// capa entera se pone encima con esa opacidad. Así un dibujo de muchas piezas se transparenta como una sola cosa.
// Devuelve la capa (por si se quiere usar como silueta antes de soltarla).
export function enCapa(c, pinta, { opacidad = 1, modo = "source-over", despues } = {}) {
  if (opacidad <= 0.002) return null;
  const capa = capaLibre(c.canvas.width, c.canvas.height), g = capa.getContext("2d");
  hondo++;
  try {
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.globalAlpha = 1; g.globalCompositeOperation = "source-over"; g.filter = "none"; g.shadowBlur = 0; g.shadowColor = "transparent";
    g.clearRect(0, 0, capa.width, capa.height);
    g.setTransform(c.getTransform());
    g.save(); pinta(g); g.restore();
    g.setTransform(1, 0, 0, 1, 0, 0);
    if (despues) despues(g, capa);
  } finally { hondo--; }
  c.save();
  c.setTransform(1, 0, 0, 1, 0, 0);
  c.globalAlpha *= opacidad;
  c.globalCompositeOperation = modo;
  c.drawImage(capa, 0, 0);
  c.restore();
  return capa;
}

// Tiñe una capa entera de un color conservando su forma (para hacer una silueta de sombra o un brillo).
export function tine(g, capa, color) {
  g.save();
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.globalCompositeOperation = "source-in";
  g.fillStyle = color;
  g.fillRect(0, 0, capa.width, capa.height);
  g.restore();
}

// Imágenes: se cargan una vez, arriba del archivo (const foto = await imagen("ruta.jpg")).
const cache = new Map();
export async function imagen(ruta) {
  if (!cache.has(ruta)) cache.set(ruta, await loadImage(ruta));
  return cache.get(ruta);
}

// Una imagen encajada en una caja (como object-fit: cover) y recortada con esquinas redondas.
export function foto(c, img, x, y, w, h, radio = 24) {
  const s = Math.max(w / img.width, h / img.height), iw = img.width * s, ih = img.height * s;
  c.save();
  c.beginPath(); c.roundRect(x, y, w, h, radio); c.clip();
  c.drawImage(img, x + (w - iw) / 2, y + (h - ih) / 2, iw, ih);
  c.restore();
}
