// Lo que comparten los estilos. Cada estilo (estilos/<nombre>/estilo.js) llama a creaEstilo con su paleta, sus
// letras y cómo pinta una pieza; lo que no diga, sale de aquí. Las escenas solo usan esta forma común:
//
//   e.color.principal        un color por su papel (nunca un hex a mano en una escena)
//   e.fondo(c, { disco, suelo })
//   e.objeto(c, pinta, { opacidad })   una cosa entera con el tratamiento del estilo (su sombra, su brillo)
//   e.pieza(c, camino, papel)          una pieza rellena con su volumen y su borde
//   e.caja / e.bola                    atajos de pieza
//   e.trazo(c, camino, opciones)       una línea dibujada con el pincel del estilo
//   e.flecha / e.ondas                 lo invisible (fuerza, aire, calor, sonido)
//   e.rotulo / e.cifra                 texto dentro de la imagen
//   e.letra(peso, tam)                 la letra del estilo ("fuerte", "media", "normal")
//   e.cielo(c, { tiempo })             el cielo de lo que pasa al aire libre: "despejado", "nublado" o "noche"
//   e.lluvia(c, t, { tiempo, fuerza }) la lluvia, del color de su cielo
import { enCapa, tine } from "../pinceles/lienzo.js";
import { alfa, oscurece } from "../pinceles/color.js";
import { rectRedondo, circulo, nube } from "../pinceles/formas.js";
import { azar } from "../pinceles/azar.js";

export const PAPELES = ["principal", "secundario", "acento", "neutro", "metal", "piel", "claro", "oscuro", "invisible", "mal", "bien"];

// Los cielos de e.cielo, si el estilo no trae los suyos (def.cielos, con las mismas claves): colores lisos.
const CIELOS = {
  despejado: { cielo: "#bfe3f2", cielo2: "#d6eef7", nubes: ["#ffffff", "#eef7fb"], cuantas: 4, alto: 0.8, suelo: "#a9c98f", lluvia: "#5f7f93" },
  nublado: { cielo: "#a9b6bf", cielo2: "#b9c4cb", nubes: ["#8a98a3", "#c6cfd5", "#77858f"], cuantas: 9, suelo: "#8e999f", lluvia: "#4e5c66" },
  noche: { cielo: "#14202b", cielo2: "#18252f", nubes: ["#1d2d3b", "#22374a", "#1a2833"], cuantas: 9, suelo: "#1d2d3b", lluvia: "#f3ead8" },
};
const az = azar("cielo");
const NUBES = Array.from({ length: 9 }, (_, i) => ({ x: az.entre(-200, 1400), y: 120 + i * 95 + az.entre(-40, 40), w: az.entre(380, 700), v: az.entre(18, 40), tono: i }));
const GOTAS = Array.from({ length: 140 }, () => ({ x: az.entre(-300, 1380), y: az.entre(0, 2200), v: az.entre(0.85, 1.15), l: az.entre(40, 90), cerca: az() }));

export function creaEstilo(def) {
  const e = {
    nombre: def.nombre,
    descripcion: def.descripcion,
    color: def.color,
    letras: def.letras,                   // { fuerte: "archivo-sin-extension", media, normal }
    grosor: def.grosor ?? 7,              // el borde de las piezas, si el estilo lo lleva
    subtitulos: def.subtitulos,
  };

  // Un papel → [color, su sombra]. También vale un hex suelto ("#7a7f87"): su sombra se calcula.
  e.tono = (papel) => {
    if (Array.isArray(papel)) return papel;
    if (typeof papel === "string" && papel.startsWith("#")) return [papel, oscurece(papel, 0.22)];
    const base = e.color[papel];
    if (!base) throw new Error(`El estilo ${e.nombre} no tiene el color «${papel}». Hay: ${PAPELES.join(", ")}.`);
    return [base, e.color[papel + "Sombra"] || oscurece(base, 0.22)];
  };

  e.letra = (peso = "fuerte", tam = 60) => `${tam}px "${e.letras[peso] || e.letras.fuerte}"`;

  e.fondo = def.fondo ? (c, op = {}) => def.fondo(c, op, e) : ((c, { disco, suelo } = {}) => {
    c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
    c.fillStyle = e.color.fondo; c.fillRect(0, 0, c.canvas.width, c.canvas.height);
    c.restore();
    if (suelo !== undefined) { c.fillStyle = e.color.suelo || e.color.fondo2; c.fillRect(-2000, suelo, 6000, 4000); }
    if (disco) { circulo(c, disco[0], disco[1], disco[2]); c.fillStyle = e.color.fondo2; c.fill(); }
  });

  e.pieza = (c, camino, papel = "principal", op = {}) => def.pieza(c, camino, e.tono(papel), op, e);

  // La cosa entera en su capa; luego el estilo le pone debajo su sombra (dura, suave o un brillo) con su silueta.
  e.objeto = (c, pinta, { opacidad = 1, sinSombra = false } = {}) => {
    if (sinSombra || !def.sombra) return enCapa(c, pinta, { opacidad });
    return enCapa(c, pinta, { opacidad, despues: (g, capa) => def.sombra(g, capa, e) });
  };

  e.caja = (c, x, y, w, h, r, papel, op) => e.pieza(c, (g) => rectRedondo(g, x, y, w, h, r), papel, op);
  e.bola = (c, x, y, r, papel, op) => e.pieza(c, (g) => circulo(g, x, y, r), papel, op);

  e.trazo = def.trazo ? (c, camino, op = {}) => def.trazo(c, camino, op, e) : ((c, camino, { papel = "tinta", grosor = e.grosor, punta = "round", opacidad = 1 } = {}) => {
    c.save(); c.globalAlpha *= opacidad;
    camino(c);
    c.lineCap = punta; c.lineJoin = "round"; c.lineWidth = grosor;
    c.strokeStyle = e.color[papel] || papel; c.stroke();
    c.restore();
  });

  // Una flecha de (x0, y0) a (x1, y1). u: cuánto se ha dibujado (para que crezca con la voz).
  e.flecha = def.flecha ? (c, x0, y0, x1, y1, op = {}) => def.flecha(c, x0, y0, x1, y1, op, e) : ((c, x0, y0, x1, y1, { u = 1, papel = "invisible", grosor = 14, opacidad = 1 } = {}) => {
    if (u <= 0.002) return;
    const x = x0 + (x1 - x0) * u, y = y0 + (y1 - y0) * u, a = Math.atan2(y1 - y0, x1 - x0), p = grosor * 3;
    const camino = (g) => { g.beginPath(); g.moveTo(x0, y0); g.lineTo(x - Math.cos(a) * p * 0.5, y - Math.sin(a) * p * 0.5); };
    const punta = (g) => { g.beginPath(); g.moveTo(x + Math.cos(a) * 2, y + Math.sin(a) * 2); g.lineTo(x - Math.cos(a - 0.55) * p, y - Math.sin(a - 0.55) * p); g.lineTo(x - Math.cos(a + 0.55) * p, y - Math.sin(a + 0.55) * p); g.closePath(); };
    c.save(); c.globalAlpha *= opacidad;
    if (def.borde) { // contorno de tinta alrededor de la flecha
      e.trazo(c, camino, { papel: "tinta", grosor: grosor + e.grosor * 1.6 });
      c.save(); punta(c); c.lineJoin = "round"; c.lineWidth = e.grosor * 1.6; c.strokeStyle = e.color.tinta; c.stroke(); c.restore();
    }
    e.trazo(c, camino, { papel, grosor });
    punta(c); c.fillStyle = e.color[papel] || papel; c.fill();
    c.restore();
  });

  // Ondas que salen de (x, y): sonido, calor, señal. Se alejan con t.
  e.ondas = def.ondas ? (c, x, y, t, op = {}) => def.ondas(c, x, y, t, op, e) : ((c, x, y, t, { n = 3, r0 = 60, paso = 60, ang = 0, abre = 1.2, grosor = 12, papel = "invisible", velocidad = 1 } = {}) => {
    for (let i = 0; i < n; i++) {
      const f = (t * 0.8 * velocidad + i / n) % 1, r = r0 + f * paso * n;
      const camino = (g) => { g.beginPath(); g.arc(x, y, r, ang - abre / 2, ang + abre / 2); };
      e.trazo(c, camino, { papel, grosor, opacidad: Math.sin(Math.PI * f) });
    }
  });

  // El nombre de algo, con su línea hasta (px, py).
  e.rotulo = def.rotulo ? (c, x, y, texto, op = {}) => def.rotulo(c, x, y, texto, op, e) : ((c, x, y, texto, { apunta, opacidad = 1, tam = 56 } = {}) => {
    if (opacidad <= 0.002) return;
    c.save(); c.globalAlpha *= opacidad;
    c.font = e.letra("fuerte", tam); c.textBaseline = "middle";
    const w = c.measureText(texto).width, pad = tam * 0.45, h = tam * 1.5;
    if (apunta) {
      const [px, py] = apunta, desde = px < x ? x - pad : x + w + pad;
      e.trazo(c, (g) => { g.beginPath(); g.moveTo(desde, y); g.lineTo(px, py); }, { papel: "tinta", grosor: 5 });
      circulo(c, px, py, 9); c.fillStyle = e.color.tinta; c.fill();
    }
    e.pieza(c, (g) => rectRedondo(g, x - pad, y - h / 2, w + pad * 2, h, h / 2), "claro", { plano: true });
    c.fillStyle = e.color.oscuro; c.fillText(texto, x, y + tam * 0.04);
    c.restore();
    return w;
  });

  // Una cifra grande en su placa, centrada en (x, y).
  e.cifra = def.cifra ? (c, x, y, texto, op = {}) => def.cifra(c, x, y, texto, op, e) : ((c, x, y, texto, { opacidad = 1, tam = 100, papel = "acento" } = {}) => {
    if (opacidad <= 0.002) return;
    c.save(); c.globalAlpha *= opacidad;
    c.font = e.letra("fuerte", tam); c.textBaseline = "middle"; c.textAlign = "center";
    const w = c.measureText(texto).width + tam * 0.9, h = tam * 1.45;
    e.objeto(c, (g) => e.pieza(g, (q) => rectRedondo(q, x - w / 2, y - h / 2, w, h, h * 0.32), papel, { plano: true }));
    c.fillStyle = e.color.textoCifra || e.color.oscuro; c.fillText(texto, x, y + tam * 0.05);
    c.restore();
  });

  // El cielo de una escena al aire libre, en lugar del fondo: "despejado" (de día), "nublado" (día de tormenta,
  // tifón, lluvia) o "noche". Lo que pasa de día no va sobre el fondo oscuro del estilo. Las nubes corren con t;
  // viento: de 0 (quietas) a 1 (tifón). suelo: la y del horizonte, si se ve.
  e.cielos = { ...CIELOS, ...(def.cielos || {}) };
  e.cielo = (c, { tiempo = "despejado", t = 0, viento = 0.3, nubes = true, suelo } = {}) => {
    const k = e.cielos[tiempo] || e.cielos.despejado;
    c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
    c.fillStyle = k.cielo; c.fillRect(0, 0, c.canvas.width, c.canvas.height);
    if (k.cielo2) { c.fillStyle = k.cielo2; c.fillRect(0, c.canvas.height * 0.42, c.canvas.width, c.canvas.height); }
    c.restore();
    if (nubes) {
      for (const n of NUBES.slice(0, k.cuantas)) {
        const x = ((n.x - t * n.v * (0.3 + 1.6 * viento)) % 1800 + 1800) % 1800 - 360;
        nube(c, x, n.y * (k.alto || 1), n.w, n.w * 0.42); c.fillStyle = k.nubes[n.tono % k.nubes.length]; c.fill();
      }
    }
    if (suelo !== undefined) { c.fillStyle = k.suelo; c.fillRect(-2000, suelo, 6000, 4000); }
  };
  // La lluvia, inclinada por el viento, con el color de su cielo. fuerza: de 0 (llovizna) a 1 (tifón).
  e.lluvia = (c, t, { tiempo = "nublado", fuerza = 1, opacidad = 0.4 } = {}) => {
    const k = e.cielos[tiempo] || e.cielos.nublado;
    const n = Math.round(GOTAS.length * Math.min(1, 0.3 + 0.7 * fuerza)), inclina = 0.2 + 0.4 * fuerza;
    c.save(); c.strokeStyle = k.lluvia; c.lineCap = "round";
    for (let i = 0; i < n; i++) {
      const g = GOTAS[i], y = ((g.y + t * 2300 * g.v) % 2200) - 150, x = g.x - (y + 150) * inclina * 0.6;
      c.globalAlpha = opacidad * (0.5 + 0.5 * g.cerca); c.lineWidth = 2 + 2.5 * g.cerca;
      c.beginPath(); c.moveTo(x, y); c.lineTo(x + g.l * inclina, y - g.l); c.stroke();
    }
    c.restore();
  };

  return e;
}

// Ayudas para los estilos: la silueta de lo que hay en una capa, teñida de un color, y ponerla debajo.
import { createCanvas } from "@napi-rs/canvas";
let sil = null;
export function siluetaDe(capa, color, desenfoque = 0) {
  if (!sil || sil.width !== capa.width || sil.height !== capa.height) sil = createCanvas(capa.width, capa.height);
  const g = sil.getContext("2d");
  g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = "source-over"; g.globalAlpha = 1;
  g.clearRect(0, 0, sil.width, sil.height);
  g.filter = desenfoque ? `blur(${desenfoque}px)` : "none";
  g.drawImage(capa, 0, 0);
  g.filter = "none";
  tine(g, sil, color);
  return sil;
}

// Pone la silueta de la capa debajo de lo que ya tiene, desplazada (dx, dy).
export function debajo(g, capa, color, dx, dy, desenfoque = 0, opacidad = 1) {
  const s = siluetaDe(capa, color, desenfoque);
  g.save(); g.setTransform(1, 0, 0, 1, 0, 0);
  g.globalCompositeOperation = "destination-over"; g.globalAlpha = opacidad;
  g.drawImage(s, dx, dy);
  g.restore();
}

export { alfa };
