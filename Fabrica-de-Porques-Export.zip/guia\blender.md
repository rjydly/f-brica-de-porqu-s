# Blender: modelos 3D para una escena

La Fábrica ya dibuja en 3D por su cuenta (`p.camara`, `p.viaje`, `p.porProfundidad` en `guia/dibujo.md`): un cubo de
Rubik que gira, una bola que rueda, una ciudad vista desde arriba. Blender es para lo que pide más: una máquina con
cien piezas que encajan, un edificio real, algo que se ve desde muchos ángulos. Es gratis
(https://www.blender.org/download/).

**Solo si el creador lo pide o lo aprueba.** Si crees que un vídeo lo necesita, pregúntale antes con botones
(«¿Usamos Blender para la máquina?»: Sí · No, dibújala en plano). Lo que no pida 3D de verdad, en plano: es más
rápido y se lee mejor.

## Encontrar Blender

Búscalo tú: `blender --version`; si no está en el PATH, en Windows `C:\Program Files\Blender Foundation\Blender
<versión>\blender.exe` y en Mac `/Applications/Blender.app/Contents/MacOS/Blender`. Si no está instalado, dile al
creador en una línea que lo descargue de blender.org (es gratis) y que te avise. Apunta la ruta en `maquina.md`.

## Cómo se hace

Blender no se abre: se lanza en segundo plano con un script de Python que construye la escena y la renderiza.

```
<video>/blender/maquina.py          el script: la cosa, su aspecto, la cámara y cada toma
<video>/blender/<toma>/00000.png    los fotogramas de cada toma, con fondo transparente
<video>/blender/<toma>/puntos.json  (opcional) dónde cae en pantalla lo que haga falta, fotograma a fotograma
```

```
blender -b -P <video>/blender/maquina.py -- <toma> [--desde f] [--hasta f] [--paso n]
```

1. **La escena, desde cero en el script:** borra lo que haya y construye la cosa con sus proporciones de verdad.
2. **El aspecto del estilo del vídeo:** los colores de `estilos/<estilo>/estilo.js` (cada papel con su luz). Para que
   no parezca un render de otro mundo, cada material es plano en dos tonos: Diffuse → Shader to RGB → rampa de color
   constante (sombra, color, luz) → Emission. `view_transform = "Standard"`, sin brillos ni reflejos.
3. **El render:** EEVEE, 1080 × 1920, 60 fps, `film_transparent = True`, PNG en RGBA, 16 muestras. El fondo lo pone
   la escena de la Fábrica (`e.fondo` o `e.cielo`), no Blender.
4. **Los tiempos de la voz:** el script lee `voz/linea.json` y `voz/toma.json` y mueve la cámara y las piezas en las
   palabras, igual que una escena.
5. **Primero una prueba:** `--paso 10` renderiza uno de cada diez fotogramas. Míralos antes del render entero (que
   puede tardar varios minutos: lánzalo en segundo plano).
6. **Si algo de encima tiene que seguir a la pieza** (un rótulo, una flecha), apunta en `puntos.json` dónde cae en
   pantalla (`world_to_camera_view`) y léelo en la escena con `toma.puntos(t)`.

## En la escena

```js
import * as p from "#pincel";
import { estilo as e } from "#estilo";

const maquina = p.toma(new URL("../../blender/gancho", import.meta.url));

export function pinta(c, t) {
  e.fondo(c);
  maquina.pinta(c, t);                      // el fotograma de ese segundo; encima, lo de la Fábrica
  const q = maquina.puntos(t);              // lo que apuntó Blender, si hay puntos.json
}
```

`p.toma(carpeta).pinta(c, t, { x, y, escala, opacidad })` dibuja el fotograma del segundo `t` del vídeo. Mientras el
render no ha acabado, enseña el último que haya, así que se puede mirar la escena antes de tenerlo todo.

## Lo que suele fallar

- **La cámara demasiado cerca:** solo se ve una pared de piezas y no se entiende qué es. Aléjala hasta que se vea la
  cosa entera, y acércate luego con la voz.
- **Piezas que se tapan unas a otras** en los primeros planos: esos detalles, mejor en plano con la Fábrica.
- **Lo que gira muy rápido tiembla** de un fotograma al siguiente: más de unas 3 vueltas por segundo se enseña a 3.
- **La forma, mal desde el principio:** busca una foto de la cosa real y enséñale al creador la primera prueba antes
  de seguir.
