// Lo que comparten las escenas: los dos granos, la palomita, la sartén con su fuego, el grano cortado, la olla y el
// cuenco. Todo en píxeles de pantalla: (x, y) es el centro y s el tamaño (el alto de la cosa).
import * as p from "#pincel";
import { estilo as e } from "#estilo";

const MARRON = "#7a4a22";        // un tono fuera de la paleta: lo tostado
const METAL_OSCURO = "#3d4249";  // la sartén

// ---------------------------------------------------------------- el grano de palomitas (entero)
// Forma de lágrima con la punta abajo (por donde se unía a la mazorca). Unidades: alto 1.
function caminoGrano(c, x, y, s, rot) {
  c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s);
  c.beginPath();
  c.moveTo(0, 0.5);
  c.bezierCurveTo(0.2, 0.44, 0.4, 0.16, 0.39, -0.1);
  c.bezierCurveTo(0.38, -0.38, 0.2, -0.5, 0, -0.5);
  c.bezierCurveTo(-0.2, -0.5, -0.38, -0.38, -0.39, -0.1);
  c.bezierCurveTo(-0.4, 0.16, -0.2, 0.44, 0, 0.5);
  c.closePath();
  c.restore();
}

export function grano(c, x, y, s, { rot = 0, tostado = 0 } = {}) {
  const color = tostado ? p.mezclaColor(e.color.acento, MARRON, tostado) : e.color.acento;
  const sombra = tostado ? p.mezclaColor(e.color.acentoSombra, "#4a2a10", tostado) : e.color.acentoSombra;
  e.pieza(c, (g) => caminoGrano(g, x, y, s, rot), [color, sombra]);
  // la punta clara, donde se unía a la mazorca
  e.pieza(c, (g) => {
    g.save(); g.translate(x, y); g.rotate(rot); g.scale(s, s);
    g.beginPath(); g.moveTo(0, 0.5); g.quadraticCurveTo(0.13, 0.42, 0.12, 0.32); g.quadraticCurveTo(0, 0.27, -0.12, 0.32); g.quadraticCurveTo(-0.13, 0.42, 0, 0.5); g.closePath();
    g.restore();
  }, "claro", { plano: true });
  // el brillo de una cáscara dura
  c.save(); c.translate(x, y); c.rotate(rot);
  c.strokeStyle = p.alfa("#ffffff", 0.75 * (1 - tostado)); c.lineWidth = s * 0.045; c.lineCap = "round";
  c.beginPath(); c.arc(0, -0.1 * s, 0.27 * s, Math.PI * 1.08, Math.PI * 1.42); c.stroke();
  c.restore();
}

// ---------------------------------------------------------------- el grano de mazorca (entero)
// Más ancho y plano, con el hoyuelo arriba (maíz dentado).
function caminoMazorca(c, x, y, s, rot) {
  c.save(); c.translate(x, y); c.rotate(rot); c.scale(s, s);
  c.beginPath();
  c.moveTo(-0.16, 0.5);
  c.quadraticCurveTo(-0.46, 0.1, -0.46, -0.34);
  c.quadraticCurveTo(-0.46, -0.5, -0.3, -0.5);
  c.quadraticCurveTo(0, -0.4, 0.3, -0.5);
  c.quadraticCurveTo(0.46, -0.5, 0.46, -0.34);
  c.quadraticCurveTo(0.46, 0.1, 0.16, 0.5);
  c.quadraticCurveTo(0, 0.56, -0.16, 0.5);
  c.closePath();
  c.restore();
}
export function mazorca(c, x, y, s, { rot = 0, tostado = 0 } = {}) {
  const base = "#f7d46b", color = p.mezclaColor(base, MARRON, tostado);
  e.pieza(c, (g) => caminoMazorca(g, x, y, s, rot), [color, p.oscurece(color, 0.18)]);
  // la corona blanda y clara con su hoyuelo
  e.pieza(c, (g) => {
    g.save(); g.translate(x, y); g.rotate(rot); g.scale(s, s);
    g.beginPath(); g.moveTo(-0.38, -0.38); g.quadraticCurveTo(-0.38, -0.47, -0.28, -0.47); g.quadraticCurveTo(0, -0.37, 0.28, -0.47);
    g.quadraticCurveTo(0.38, -0.47, 0.38, -0.38); g.quadraticCurveTo(0, -0.2, -0.38, -0.38); g.closePath();
    g.restore();
  }, [p.mezclaColor("#fff3cf", MARRON, tostado * 0.8), "#efdca5"], { plano: true });
}

// ---------------------------------------------------------------- la palomita
// Bultos blancos de espuma con trozos de cáscara pegados. abre: de 0 (aún grano) a 1 (abierta del todo).
const bultos = (semilla) => {
  const r = p.azar(semilla), lista = [[0, 0, 0.34]];
  for (let i = 0; i < 7; i++) { const a = (i / 7) * Math.PI * 2 + r.entre(-0.3, 0.3), d = r.entre(0.2, 0.32); lista.push([Math.cos(a) * d, Math.sin(a) * d * 0.85, r.entre(0.17, 0.26)]); }
  return lista;
};
const BULTOS = new Map();
export function palomita(c, x, y, s, { rot = 0, abre = 1, semilla = 1, quemada = 0 } = {}) {
  if (!BULTOS.has(semilla)) BULTOS.set(semilla, bultos(semilla));
  const bs = BULTOS.get(semilla), k = p.mezcla(0.35, 1, abre);
  const blanco = p.mezclaColor(e.color.claro, "#2a1a10", quemada), sombra = p.mezclaColor(e.color.claroSombra, "#160c06", quemada);
  e.pieza(c, (g) => {
    g.save(); g.translate(x, y); g.rotate(rot); g.scale(s, s);
    g.beginPath();
    for (const [dx, dy, r] of bs) { g.moveTo(dx * k + r * k, dy * k); g.arc(dx * k, dy * k, r * k, 0, Math.PI * 2); }
    g.restore();
  }, [blanco, sombra], { grosor: Math.max(4, s * 0.012) });
  // los pliegues de la espuma
  c.save(); c.translate(x, y); c.rotate(rot);
  c.strokeStyle = p.mezclaColor(e.color.claroSombra, "#26221d", 0.25 + 0.5 * quemada); c.lineWidth = Math.max(3, s * 0.014); c.lineCap = "round";
  for (const [dx, dy, r] of bs.slice(1, 6)) { c.beginPath(); c.arc(dx * k * s * 0.7, dy * k * s * 0.7, r * k * s * 0.55, 0.4, 1.5); c.stroke(); }
  c.restore();
  // trozos de cáscara abiertos debajo
  for (const [i, a] of [[0, 2.2], [1, 1.25], [2, 0.6]]) {
    const d = 0.36 * k, px = x + Math.cos(a + rot) * d * s, py = y + Math.sin(a + rot) * d * s;
    e.pieza(c, (g) => { g.save(); g.translate(px, py); g.rotate(a + rot + Math.PI / 2); g.beginPath(); g.ellipse(0, 0, 0.13 * s, 0.06 * s, 0, 0, Math.PI * 2); g.closePath(); g.restore(); },
      [p.mezclaColor(e.color.acento, "#2a1a10", quemada), e.color.acentoSombra], { plano: i !== 0 });
  }
}

// ---------------------------------------------------------------- la sartén, de lado, sobre su fuego
// y: la altura del fondo de dentro (donde se apoyan los granos). t: para que el fuego se mueva.
export function sarten(c, y, t, { x0 = -200, x1 = 1280, mango = true, fuego = 1 } = {}) {
  // el fuego debajo
  if (fuego > 0) for (let i = 0; i < 9; i++) llama(c, x0 + 160 + ((x1 - x0 - 320) * i) / 8, y + 150, 110 * fuego, t, i);
  e.objeto(c, (c) => {
    e.pieza(c, (g) => { g.beginPath(); g.moveTo(x0, y - 70); g.lineTo(x1, y - 70); g.lineTo(x1 - 60, y + 70); g.lineTo(x0 + 60, y + 70); g.closePath(); }, [METAL_OSCURO, "#2a2e33"]);
    e.caja(c, x0 - 20, y - 92, x1 - x0 + 40, 30, 15, "metal");
    if (mango) e.caja(c, x1 - 10, y - 70, 420, 56, 28, [METAL_OSCURO, "#2a2e33"]);
  });
}

// Una llama que se mueve sola (con su semilla): de la base (x, y) hacia arriba, alto h.
export function llama(c, x, y, h, t, semilla = 0) {
  const w = h * 0.42, baila = p.ondula(t * 3.2, semilla) * 0.12, alto = h * (0.9 + 0.12 * p.ondula(t * 4.1, semilla + 7));
  const forma = (k) => (g) => {
    g.beginPath(); g.moveTo(x, y);
    g.bezierCurveTo(x - w * k, y - alto * 0.1 * k, x - w * 0.8 * k, y - alto * 0.6 * k, x + baila * h, y - alto * k);
    g.bezierCurveTo(x + w * 0.7 * k, y - alto * 0.55 * k, x + w * k, y - alto * 0.1 * k, x, y);
    g.closePath();
  };
  e.pieza(c, forma(1), "secundario", { plano: true });
  e.pieza(c, forma(0.58), "acento", { plano: true, sinBorde: true });
}

// ---------------------------------------------------------------- el grano cortado por la mitad
// forma: "palomitas" o "mazorca". cascara: grosor de la cáscara (en partes del alto). poros: agujeros en la cáscara.
const MOTAS = (() => { const r = p.azar("almidon"), m = []; for (let i = 0; i < 46; i++) m.push([r.entre(-0.3, 0.3), r.entre(-0.4, 0.38), r.entre(0.012, 0.03)]); return m; })();
export function corte(c, x, y, s, { forma = "palomitas", cascara = 0.05, poros = 0, hincha = 1, tiembla = 0, t = 0 } = {}) {
  const dx = tiembla * 9 * p.ondula(t * 30, 3), dy = tiembla * 9 * p.ondula(t * 30, 9), S = s * hincha;
  const camino = forma === "palomitas" ? caminoGrano : caminoMazorca;
  const cx = x + dx, cy = y + dy;
  // la cáscara entera y, dentro, el almidón (la misma forma, un poco más pequeña)
  e.pieza(c, (g) => camino(g, cx, cy, S, 0), forma === "palomitas" ? "acento" : ["#f7d46b", "#dcb54a"]);
  const dentro = 1 - cascara * 2.4;
  e.pieza(c, (g) => camino(g, cx, cy + S * cascara * 0.2, S * dentro, 0), ["#fff6e2", "#f1e2c2"], { plano: true, grosor: 4 });
  // motas de almidón
  c.save(); c.fillStyle = "#efdfbd";
  for (const [mx, my, mr] of MOTAS) { if (forma === "mazorca" && Math.abs(mx) > 0.34) continue; c.beginPath(); c.arc(cx + mx * S * dentro, cy + my * S * dentro, mr * S, 0, Math.PI * 2); c.fill(); }
  c.restore();
  // los poros: agujeritos que atraviesan la cáscara (se devuelven, para sacar el vapor por ellos)
  const agujeros = [];
  for (let i = 0, n = 9; i < n; i++) {
    const a = -Math.PI * 0.95 + (i / (n - 1)) * Math.PI * 0.9, px = cx + Math.cos(a) * S * 0.45, py = cy - S * 0.05 + Math.sin(a) * S * 0.47;
    agujeros.push([px, py, a]);
    if (poros > 0) {
      c.save(); c.globalAlpha *= poros; c.beginPath(); c.arc(px, py, S * 0.028, 0, Math.PI * 2); c.fillStyle = e.color.fondo; c.fill();
      c.lineWidth = 4; c.strokeStyle = e.color.tinta; c.stroke(); c.restore();
    }
  }
  return agujeros;
}

// ---------------------------------------------------------------- una bolita de vapor
export function vapor(c, x, y, r, opacidad = 1) {
  if (opacidad <= 0.01 || r <= 0.5) return;
  e.objeto(c, (c) => e.bola(c, x, y, r, ["#ffffff", "#dfe7ef"], { grosor: Math.max(3, r * 0.12) }), { opacidad, sinSombra: true });
}

// ---------------------------------------------------------------- la olla a presión
export function olla(c, x, y, s, t, { tiembla = 0 } = {}) {
  const sx = tiembla * 6 * p.ondula(t * 40, 1), ly = -tiembla * 10 * Math.abs(p.ondula(t * 25, 4));
  e.objeto(c, (c) => {
    c.save(); c.translate(x + sx, y);
    e.caja(c, -s * 0.5, -s * 0.18, s, s * 0.62, s * 0.08, "metal");                    // el cuerpo
    e.caja(c, -s * 0.72, -s * 0.06, s * 0.24, s * 0.08, s * 0.04, [METAL_OSCURO, "#25292e"]); // asa izquierda
    e.caja(c, s * 0.48, -s * 0.06, s * 0.24, s * 0.08, s * 0.04, [METAL_OSCURO, "#25292e"]);  // asa derecha
    c.translate(0, ly);
    e.pieza(c, (g) => { g.beginPath(); g.moveTo(-s * 0.54, -s * 0.18); g.quadraticCurveTo(0, -s * 0.42, s * 0.54, -s * 0.18); g.closePath(); }, "metal"); // la tapa
    e.caja(c, -s * 0.5, -s * 0.5, s * 1.0, s * 0.07, s * 0.035, [METAL_OSCURO, "#25292e"]);  // el mango de la tapa
    e.caja(c, -s * 0.05, -s * 0.46, s * 0.1, s * 0.16, s * 0.03, "secundario");                // la válvula
    c.restore();
  });
}

// ---------------------------------------------------------------- el cuenco de palomitas
export function cuenco(c, x, y, s, t) {
  // las palomitas, montón encima del cuenco (de atrás adelante)
  const r = p.azar("monton"), montones = [];
  for (let i = 0; i < 16; i++) montones.push([r.entre(-0.38, 0.38) * s, -r.entre(0.02, 0.26) * s - (0.38 - Math.abs(r.entre(-0.38, 0.38))) * 0.25 * s, r.entre(0.18, 0.24) * s, r.entre(-1, 1), i + 3]);
  montones.sort((a, b) => a[1] - b[1]);
  e.objeto(c, (c) => {
    for (const [dx, dy, ps, rot, sem] of montones) palomita(c, x + dx, y + dy, ps, { rot, semilla: sem });
    e.pieza(c, (g) => { g.beginPath(); g.moveTo(x - s * 0.55, y - s * 0.04); g.lineTo(x + s * 0.55, y - s * 0.04); g.quadraticCurveTo(x + s * 0.5, y + s * 0.48, x, y + s * 0.5); g.quadraticCurveTo(x - s * 0.5, y + s * 0.48, x - s * 0.55, y - s * 0.04); g.closePath(); }, "secundario");
    // las rayas blancas del cuenco
    c.save();
    c.beginPath(); c.moveTo(x - s * 0.55, y - s * 0.04); c.lineTo(x + s * 0.55, y - s * 0.04); c.quadraticCurveTo(x + s * 0.5, y + s * 0.48, x, y + s * 0.5); c.quadraticCurveTo(x - s * 0.5, y + s * 0.48, x - s * 0.55, y - s * 0.04); c.closePath(); c.clip();
    for (let i = -3; i <= 3; i++) { c.fillStyle = e.color.claro; c.beginPath(); c.moveTo(x + i * s * 0.16 - s * 0.035, y - s * 0.1); c.lineTo(x + i * s * 0.16 + s * 0.035, y - s * 0.1); c.lineTo(x + i * s * 0.1 + s * 0.025, y + s * 0.6); c.lineTo(x + i * s * 0.1 - s * 0.025, y + s * 0.6); c.closePath(); c.fill(); }
    c.restore();
  });
}

// ---------------------------------------------------------------- humo gris que sube (de lo tostado o quemado)
export function humo(c, x, y, t, t0, { n = 5, alto = 260, color = "#a39b90", r = 26 } = {}) {
  for (let i = 0; i < n; i++) {
    const u = (t - t0 - i * 0.22) / 1.3;
    if (u <= 0 || u >= 1) continue;
    const px = x + Math.sin(u * 5 + i) * 26, py = y - u * alto;
    e.objeto(c, (c) => e.bola(c, px, py, r * (0.5 + u), [color, p.oscurece(color, 0.15)], { grosor: 3 }), { opacidad: Math.sin(Math.PI * u) * 0.9, sinSombra: true });
  }
}

// Exportado para otras escenas: el camino del grano de palomitas.
export { caminoGrano };

// ---------------------------------------------------------------- el grano de palomitas por dentro, con su fuego
// gota: 0-1 (la gota de agua); vapor: 0-1 (las bolitas de vapor que llenan el grano); flechas: 0-1 (empujan la
// cáscara desde dentro; más de 1 = chocan y vuelven); llamas: 0-1.
const BURBUJAS = (() => { const r = p.azar("vapor"), b = []; for (let i = 0; i < 15; i++) { const a = r.entre(0, Math.PI * 2), d = Math.sqrt(r()) * 0.26; b.push([Math.cos(a) * d, Math.sin(a) * d * 1.25 - 0.03, r.entre(0.035, 0.06), i]); } return b; })();
const DIRECCIONES = [-Math.PI / 2, -Math.PI / 2 - 1.0, -Math.PI / 2 + 1.0, Math.PI, 0, Math.PI / 2 - 0.4, Math.PI / 2 + 0.4];
export function porDentro(c, t, { x = 540, y = 1080, s = 820, gota = 0, vapor: vp = 0, flechas = 0, llamas = 0, cascara = 0.05, hincha = 1, tiembla = 0, forma = "palomitas", poros = 0 } = {}) {
  if (llamas > 0) for (let i = 0; i < 6; i++) llama(c, x - s * 0.36 + (s * 0.72 * i) / 5, y + s * 0.5 * hincha + 190, 150 * llamas, t, i + 20);
  let agujeros = [];
  e.objeto(c, (c) => { agujeros = corte(c, x, y, s, { forma, cascara, hincha, tiembla, t, poros }); });
  const S = s * hincha;
  if (gota > 0.01) {
    const r = 92 * (s / 820) * gota * (1 + 0.04 * Math.sin(t * 9));
    e.objeto(c, (c) => e.pieza(c, (g) => p.gota(g, x, y + r * 0.6, r), "principal"));
  }
  if (vp > 0.01) for (const [bx, by, br, i] of BURBUJAS) {
    const u = p.rango(vp, i / 30, i / 30 + 0.5);
    if (u <= 0) continue;
    const ox = bx * u * S + p.ondula(t * 2 + i, i) * 10, oy = by * u * S + p.ondula(t * 2.3 + i, i + 5) * 10;
    bolitaVapor(c, x + ox, y + oy, br * S * p.rebota(u, 1.2));
  }
  if (flechas > 0.01) {
    const ida = Math.min(1, flechas), vuelta = flechas > 1 ? p.rebota(Math.min(1, flechas - 1)) : 0;
    for (const a of DIRECCIONES) {
      const largo = S * 0.34 * (ida - 0.25 * vuelta);
      const x0 = x + Math.cos(a) * S * 0.07, y0 = y + Math.sin(a) * S * 0.08;
      e.flecha(c, x0, y0, x0 + Math.cos(a) * largo, y0 + Math.sin(a) * largo * 1.15, { u: 1, grosor: 13 * (s / 820) });
    }
  }
  return agujeros;
}

export function bolitaVapor(c, x, y, r, opacidad = 1) {
  if (r < 1 || opacidad <= 0.01) return;
  e.objeto(c, (c) => e.bola(c, x, y, r, ["#ffffff", "#d9e4ee"], { grosor: 4 }), { opacidad, sinSombra: true });
}
