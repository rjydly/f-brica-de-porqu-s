// Arcilla: 3D suave, como figuras de plastilina o juguetes de vinilo. Fondo cálido con degradado, piezas con volumen
// redondeado (luz arriba a la izquierda), sin contornos y con una sombra suave debajo.
import { creaEstilo, debajo } from "../comun.js";
import { aclara, oscurece } from "../../pinceles/color.js";

export default creaEstilo({
  nombre: "arcilla",
  descripcion: "3D suave, como plastilina: volumen redondeado, sin contornos, sombras suaves, fondo cálido.",
  color: {
    fondo: "#f6e3d4", fondo2: "#f0d3bf", fondoAbajo: "#eccab3", suelo: "#e9c2a8",
    tinta: "#5a3b2e",
    principal: "#5b8def", principalSombra: "#3e68c4",
    secundario: "#ff7a59", secundarioSombra: "#d9573a",
    acento: "#ffc94d", acentoSombra: "#e0a624",
    neutro: "#4cc9a6", neutroSombra: "#2fa283",
    metal: "#c7ccd6", metalSombra: "#9aa1b0",
    piel: "#f2b48f", pielSombra: "#d48f69",
    claro: "#fffaf5", claroSombra: "#eadfd5",
    oscuro: "#5a3b2e",
    invisible: "#9b6bff",
    mal: "#f0483e", bien: "#33b36b",
    sombraObjeto: "rgba(110,60,35,0.32)",
  },
  letras: { fuerte: "fredoka-700", media: "fredoka-600", normal: "fredoka-500" },
  grosor: 0,
  fondo(c, { disco, suelo } = {}, e) {
    c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
    const d = c.createLinearGradient(0, 0, 0, c.canvas.height);
    d.addColorStop(0, e.color.fondo); d.addColorStop(1, e.color.fondoAbajo);
    c.fillStyle = d; c.fillRect(0, 0, c.canvas.width, c.canvas.height);
    c.restore();
    if (suelo !== undefined) { c.fillStyle = e.color.suelo; c.fillRect(-2000, suelo, 6000, 4000); }
    if (disco) {
      const r = c.createRadialGradient(disco[0], disco[1], 0, disco[0], disco[1], disco[2]);
      r.addColorStop(0, aclara(e.color.fondo2, 0.25)); r.addColorStop(1, e.color.fondo2);
      c.beginPath(); c.arc(disco[0], disco[1], disco[2], 0, Math.PI * 2); c.fillStyle = r; c.fill();
    }
  },
  // volumen: degradado de la luz a la sombra dentro de la caja de la pieza (caja: [x, y, w, h]; si no se da, se mide)
  pieza(c, camino, [color, sombra], { plano = false, caja } = {}) {
    c.save();
    camino(c);
    if (plano) { c.fillStyle = color; c.fill(); c.restore(); return; }
    const [x, y, w, h] = caja || cajaDe(c, camino);
    const cx = x + w * 0.32, cy = y + h * 0.28, r = Math.hypot(w, h) * 0.8;
    const g = c.createRadialGradient(cx, cy, 0, cx, cy, r);
    g.addColorStop(0, aclara(color, 0.35)); g.addColorStop(0.45, color); g.addColorStop(1, oscurece(sombra, 0.12));
    c.fillStyle = g; c.fill();
    // un brillo pequeño y suave arriba a la izquierda
    c.clip();
    const b = c.createRadialGradient(cx, cy, 0, cx, cy, Math.min(w, h) * 0.3);
    b.addColorStop(0, "rgba(255,255,255,0.45)"); b.addColorStop(1, "rgba(255,255,255,0)");
    c.fillStyle = b; c.fillRect(x, y, w, h);
    c.restore();
  },
  trazo(c, camino, { papel = "tinta", grosor = 10, opacidad = 1 } = {}, e) {
    c.save(); c.globalAlpha *= opacidad; camino(c);
    c.lineCap = "round"; c.lineJoin = "round"; c.lineWidth = grosor; c.strokeStyle = e.color[papel] || papel; c.stroke();
    c.restore();
  },
  sombra(g, capa, e) { debajo(g, capa, e.color.sombraObjeto, 6, 28, 26); },
  subtitulos: {
    tam: 78, linea: 88, letra: "fredoka-700", letraDicha: "fredoka-600",
    color: "#ffffff", dicho: "#f3d9c8", contorno: "#5a3b2e", grosorContorno: 12,
    resalte: "pastilla", colorResalte: "#ff7a59",
  },
});

// La caja de un camino: se mide pintándolo en un lienzo pequeño (una vez por camino y transformación).
import { createCanvas } from "@napi-rs/canvas";
const medida = createCanvas(270, 480), gm = medida.getContext("2d");
function cajaDe(c, camino) {
  const m = c.getTransform();
  gm.setTransform(1, 0, 0, 1, 0, 0); gm.clearRect(0, 0, 270, 480);
  gm.setTransform(m.a / 4, m.b / 4, m.c / 4, m.d / 4, m.e / 4, m.f / 4);
  camino(gm); gm.fillStyle = "#000"; gm.fill();
  const d = gm.getImageData(0, 0, 270, 480).data;
  let x0 = 270, y0 = 480, x1 = -1, y1 = -1;
  for (let y = 0; y < 480; y++) for (let x = 0; x < 270; x++) if (d[(y * 270 + x) * 4 + 3] > 0) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  if (x1 < 0) return [0, 0, 1, 1];
  // de píxeles de pantalla (a 1/4) a coordenadas de c
  const inv = m.inverse(), p = (px, py) => ({ x: inv.a * px + inv.c * py + inv.e, y: inv.b * px + inv.d * py + inv.f });
  const a = p(x0 * 4, y0 * 4), b = p((x1 + 1) * 4, (y1 + 1) * 4);
  return [Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y)];
}
