// Láminas: muchos momentos del vídeo en pequeño y en orden, cada uno con su segundo y la palabra que suena. Así se ve
// el movimiento en segundos, sin esperar a un render.
import { createCanvas, GlobalFonts } from "@napi-rs/canvas";
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";
import { W, H } from "./base.mjs";
import { pinta } from "./fotograma.mjs";

const letraLamina = () => (GlobalFonts.families.some((f) => f.family === "nunito-800") ? '"nunito-800"' : "sans-serif");

// momentos: segundos o { t, nota }. Devuelve el lienzo de la lámina.
export function lamina(v, est, momentos, { ancho = 160, columnas = 8, subtitulos = true, titulo = "" } = {}) {
  const alto = Math.round((ancho * H) / W), cabeza = titulo ? 40 : 0, pie = 24, sep = 5;
  const filas = Math.ceil(momentos.length / columnas);
  const L = createCanvas(columnas * ancho + (columnas + 1) * sep, cabeza + filas * (alto + pie + sep) + sep), g = L.getContext("2d");
  g.fillStyle = "#fbfaf7"; g.fillRect(0, 0, L.width, L.height);
  const fuente = letraLamina();
  if (titulo) { g.fillStyle = "#1b1a17"; g.font = `22px ${fuente}`; g.textBaseline = "middle"; g.fillText(titulo, sep + 6, cabeza / 2); }
  momentos.forEach((m, i) => {
    const t = typeof m === "number" ? m : m.t, nota = typeof m === "number" ? "" : m.nota || "";
    const x = sep + (i % columnas) * (ancho + sep), y = cabeza + sep + Math.floor(i / columnas) * (alto + pie + sep);
    g.drawImage(pinta(v, est, Math.max(0, Math.min(v.dura - 1 / 120, t)), { subtitulos }), x, y, ancho, alto);
    const w = v.voz.suena(t);
    g.fillStyle = nota ? "#d2361f" : "#1b1a17"; g.font = `15px ${fuente}`; g.textBaseline = "top";
    g.fillText(`${t.toFixed(2)} ${nota || (w ? "«" + w.dice.replace(/[.,:;!?¿¡«»"]/g, "") + "»" : "")}`.slice(0, 28), x + 2, y + alto + 4);
  });
  return L;
}

export function guarda(L, ruta) {
  mkdirSync(dirname(ruta), { recursive: true });
  writeFileSync(ruta, L.toBuffer("image/jpeg", 86));
  return ruta;
}

// n momentos repartidos de a a b, con los dos extremos.
export const reparte = (a, b, n) => Array.from({ length: n }, (_, i) => a + ((b - a) * i) / Math.max(1, n - 1));
