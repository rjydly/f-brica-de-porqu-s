// render: el vídeo con su voz y sus efectos. Borrador rápido para mirarlo en movimiento, o el final para publicar.
import { execFileSync, spawnSync } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import { availableParallelism } from "node:os";
import { join } from "node:path";
import { Worker } from "node:worker_threads";
import { CASA, MUESTREO, carpetaVideo, ff, guardaWav, muestras, para } from "../nucleo/base.mjs";
import { abre } from "../nucleo/video.mjs";

export const ayuda = `
node fabrica.mjs render <video> [--borrador] [--desde s] [--hasta s] [--alternativa 01-x] [--hilos N]

Sin nada: el vídeo final a 60 fps en salida/<video>/, con portada.jpg y texto-del-post.txt (de pie.txt).
Al acabar avisa de los saltos sueltos de imagen: míralos con «mirar».
--borrador: a 30 fps y rápido, en <video>/revisar/borrador.mp4, para verlo en movimiento.
--desde / --hasta: solo ese tramo (para enseñar el gancho: --borrador --hasta 10).
--alternativa 01-tunel: con --borrador, el gancho con la otra versión, en revisar/borrador-01-tunel.mp4.
El sonido se deja a -14 LUFS, el volumen al que suenan bien los reels.
`;

const LUFS = -17; // medido en mono: al pasar la misma pista a los dos lados del estéreo queda en -14, el volumen de los reels

export async function corre({ libres, marcas }) {
  const dir = carpetaVideo(libres[0]);
  const alternativa = marcas.alternativa ? String(marcas.alternativa) : null;
  const borrador = !!marcas.borrador;
  if (alternativa && !borrador) para("--alternativa es para enseñar el gancho: úsalo con --borrador.");
  const v = await abre(dir, { alternativa });
  const fps = Number(marcas.fps || (borrador ? 30 : 60));
  const desde = Math.max(0, Number(marcas.desde || 0)), hasta = Math.min(v.dura, Number(marcas.hasta || v.dura));
  const f0 = Math.round(desde * fps), f1 = Math.round(hasta * fps), total = f1 - f0;
  const salida = borrador ? join(dir, "revisar", alternativa ? `borrador-${alternativa}.mp4` : "borrador.mp4") : join(CASA, "salida", v.nombre, `${v.nombre}.mp4`);
  const tmp = join(dir, "revisar", ".trozos");
  rmSync(tmp, { recursive: true, force: true }); mkdirSync(tmp, { recursive: true }); mkdirSync(join(salida, ".."), { recursive: true });
  const inicio = Date.now();

  // la imagen: un hilo por trozo
  const hilos = Math.max(1, Math.min(Number(marcas.hilos || Math.max(1, availableParallelism() - 1)), 10, Math.ceil(total / 45)));
  const hechos = new Array(hilos).fill(0), trozos = [];
  let dicho = 0;
  for (let i = 0; i < hilos; i++) {
    const a = f0 + Math.floor((total * i) / hilos), b = f0 + Math.floor((total * (i + 1)) / hilos), mp4 = join(tmp, `t${String(i).padStart(2, "0")}.mp4`);
    trozos.push({ mp4, listo: new Promise((ok, mal) => {
      const w = new Worker(new URL("../nucleo/obrero.mjs", import.meta.url), { workerData: { dir, desde: a, hasta: b, fps, salida: mp4, rapido: borrador, alternativa } });
      w.on("message", (m) => {
        hechos[i] = m.hechos;
        const pct = Math.floor((100 * hechos.reduce((s, x) => s + x, 0)) / total);
        if (pct >= dicho + 25 && pct < 100) { dicho = pct - (pct % 25); console.log(`  ${dicho} %`); }
      });
      w.on("error", mal);
      w.on("exit", (c) => (c ? mal(new Error(`el hilo ${i} acabó con error ${c}`)) : ok()));
    }) });
  }
  await Promise.all(trozos.map((x) => x.listo));
  const lista = join(tmp, "lista.txt");
  writeFileSync(lista, trozos.map((x) => `file '${x.mp4.replace(/\\/g, "/")}'`).join("\n") + "\n");
  const imagen = join(tmp, "imagen.mp4");
  ff(["-f", "concat", "-safe", "0", "-i", lista, "-c", "copy", imagen]);

  // el sonido: voz y efectos sumados, y todo llevado a su volumen
  const voz = muestras(join(dir, "voz", "voz.wav")), fx = join(dir, "sonidos", "efectos.wav");
  const efectos = existsSync(fx) && !alternativa ? muestras(fx) : null;
  const a0 = Math.round(desde * MUESTREO), a1 = Math.min(voz.length, Math.round(hasta * MUESTREO)), suma = new Float32Array(Math.max(0, a1 - a0));
  for (let i = 0; i < suma.length; i++) suma[i] = voz[a0 + i] + (efectos ? efectos[a0 + i] || 0 : 0);
  const crudo = join(tmp, "suma.wav");
  guardaWav(crudo, suma);
  const medida = spawnSync("ffmpeg", ["-hide_banner", "-nostats", "-i", crudo, "-af", `loudnorm=I=${LUFS}:TP=-1.5:LRA=11:print_format=json`, "-f", "null", "-"], { encoding: "utf8" });
  const m = /\{[^{}]*"input_i"[^{}]*\}/s.exec(medida.stderr || "");
  let filtro = `loudnorm=I=${LUFS}:TP=-1.5:LRA=11`;
  if (m) { const j = JSON.parse(m[0]); filtro += `:measured_I=${j.input_i}:measured_TP=${j.input_tp}:measured_LRA=${j.input_lra}:measured_thresh=${j.input_thresh}:offset=${j.target_offset}:linear=true`; }
  ff(["-i", imagen, "-i", crudo, "-filter_complex", `[1:a]${filtro},aresample=48000,pan=stereo|c0=c0|c1=c0[a]`, "-map", "0:v", "-map", "[a]",
    "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", salida]);
  rmSync(tmp, { recursive: true, force: true });
  console.log(`${salida}\n  ${(hasta - desde).toFixed(2)} s · ${fps} fps · ${total} fotogramas · ${hilos} hilos · ${((Date.now() - inicio) / 1000).toFixed(0)} s`);

  if (!borrador && !marcas.desde && !marcas.hasta) {
    const portada = join(salida, "..", "portada.jpg");
    ff(["-ss", String(Math.min(1.2, v.dura / 2)), "-i", salida, "-frames:v", "1", "-q:v", "2", portada]);
    console.log(`  ${portada}`);
    if (existsSync(join(dir, "pie.txt"))) { copyFileSync(join(dir, "pie.txt"), join(salida, "..", "texto-del-post.txt")); console.log(`  ${join(salida, "..", "texto-del-post.txt")}`); }
    const cortes = v.escenas.slice(1).map((s) => s.empieza);
    const { sueltos, tirones } = saltos(salida, fps);
    const fuera = sueltos.filter((t) => !cortes.some((c) => Math.abs(c - t) < 2 / fps));
    if (fuera.length) console.log(`Saltos de imagen fuera de los cambios de escena (míralos con mirar; si no son un golpe buscado, arréglalos): ${fuera.map((t) => t.toFixed(2)).join(", ")} s`);
    if (tirones.length) console.log(`Fotogramas repetidos en pleno movimiento (un tirón): ${tirones.map((t) => t.toFixed(2)).join(", ")} s`);
  }
}

// Un fotograma que cambia mucho más que los de alrededor (un salto) o que no cambia entre dos que sí (un tirón).
function saltos(mp4, fps) {
  const w = 64, h = 114, n = w * h;
  const raw = execFileSync("ffmpeg", ["-v", "error", "-i", mp4, "-vf", `scale=${w}:${h},format=gray`, "-f", "rawvideo", "-"], { maxBuffer: 1 << 30 });
  const k = raw.length / n, d = [0];
  for (let f = 1; f < k; f++) { let s = 0; for (let i = 0; i < n; i++) s += Math.abs(raw[f * n + i] - raw[(f - 1) * n + i]); d.push(s / n); }
  const sueltos = [], tirones = [];
  for (let f = 3; f < d.length - 3; f++) {
    const vecinos = [d[f - 3], d[f - 2], d[f - 1], d[f + 1], d[f + 2], d[f + 3]].sort((a, b) => a - b), med = (vecinos[2] + vecinos[3]) / 2;
    if (d[f] > 4 && d[f] > 3.5 * med + 1) sueltos.push(f / fps);
    if (d[f] < 0.05 && d[f - 1] > 1.5 && d[f + 1] > 1.5) tirones.push(f / fps);
  }
  return { sueltos, tirones };
}
