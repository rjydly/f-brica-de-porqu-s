# Por qué explotan las palomitas

## En una frase
El maíz de palomitas revienta porque su cáscara es dura e impermeable y aguanta la presión del vapor hasta que estalla; el maíz normal deja escapar el vapor.

## Lo sorprendente
Los dos son maíz y llevan agua dentro, pero solo uno explota. El sonido no es la cáscara al romperse: es el vapor que sale. Y salta porque le sale una "pata" de almidón.

## La regla que rompe
Se cree que el grano de palomitas es especial por dentro; lo especial es la cáscara (pericarpio).

## El mecanismo
1. El grano lleva un 13,5-14 % de agua (Purdue; Popcorn Board).
2. Al calentarlo el agua se hace vapor.
3. En el maíz normal el pericarpio es poroso: el vapor se escapa (Purdue, 2020).
4. En el de palomitas el pericarpio es duro e impermeable: la presión sube.
5. A ~180 °C revienta: 96 % de los granos estallan a 180 °C frente al 34 % a 170 °C (Virot y Ponomarenko, 2015).
6. Presión de rotura ~9 atm / 135 psi (divulgación: Science Buddies / Scientific American).
7. El almidón se expande en espuma, unas 40 veces su volumen (Popcorn Board: 40-50 veces).
8. Salta: le sale una "pata" de almidón que se comprime contra la superficie y lo lanza (Virot y Ponomarenko, 2015).
9. El "pop" lo produce la liberación del vapor, no la rotura (Virot y Ponomarenko, 2015).

## Comparaciones de casa
Olla a presión. Espuma.

## Fuentes
- Virot, E. y Ponomarenko, A. (2015). Popcorn: critical temperature, jump and sound. J. R. Soc. Interface 12: 20141247. https://hal-polytechnique.archives-ouvertes.fr/hal-01178414
- Purdue University (2020), What's under the shell of this popular snack? https://ag.purdue.edu/news/2020/02/whats-under-the-shell-of-this-popular-snack.html
- Scientific American, Popcorn Physics 101. https://www.scientificamerican.com/article/popcorn-physics-101-how-a-kernel-pops
- Science Buddies, Explore the "pop" in popcorn. https://www.sciencebuddies.org/stem-activities/explore-the-pop-in-popcorn
