// catalogo: las láminas de referencia. guia/estilos.jpg (la misma escena en cada estilo) y guia/catalogo.jpg (lo que
// ya saben dibujar los pinceles, en el estilo que se pida).
import { createCanvas } from "@napi-rs/canvas";
import { basename, dirname, extname, join, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import * as p from "../pinceles/index.js";
import { CASA, config } from "../nucleo/base.mjs";
import { cargaEstilo, estilo as e, estilosQueHay } from "../nucleo/estilo-vivo.js";
import { guarda } from "../nucleo/laminas.mjs";

export const ayuda = `
node fabrica.mjs catalogo [--estilo papel]
node fabrica.mjs catalogo --muestra <dibujo.js> [--estilos casa,pegatina,tinta]

Rehace guia/estilos.jpg (una misma escena en cada estilo, para elegir) y guia/catalogo.jpg (cada forma y ayuda de
los pinceles con su nombre, en ese estilo). Si añades un estilo o una forma, vuelve a lanzarlo.

--muestra: para «muéstrame varios estilos, dibuja un auto». dibujo.js exporta por defecto una función
(c, e, p) que dibuja la cosa en un lienzo de 1080 × 1920 con el estilo e (sus colores por papel, nunca hex a mano) y
los pinceles p. Sale estilos-<nombre de dibujo.js>.jpg junto a dibujo.js, con la cosa en cada estilo (todos, o los de
--estilos) y su nombre encima. guia/ no se toca.
`;

// una escena de muestra: un bote con su tapa, una bola, una mano, lo invisible, un rótulo y una cifra
function muestra(c, nombre) {
  e.fondo(c, { disco: [540, 1020, 420] });
  e.objeto(c, (c) => { e.caja(c, 330, 800, 300, 520, 46, "principal"); e.caja(c, 350, 680, 260, 150, 20, "metal"); });
  e.objeto(c, (c) => e.bola(c, 800, 1220, 120, "acento"));
  e.objeto(c, (c) => e.pieza(c, (g) => p.mano(g, 250, 1500, 300, 0.25), "piel"));
  e.objeto(c, (c) => e.pieza(c, (g) => p.estrella(g, 820, 760, 5, 95, 42), "secundario"));
  e.flecha(c, 130, 1700, 520, 1540);
  e.ondas(c, 800, 1220, 0.3, { r0: 140 });
  e.rotulo(c, 600, 590, "la tapa", { apunta: [520, 720] });
  e.cifra(c, 540, 1750, "4.000 °C");
  c.font = e.letra("fuerte", 92); c.fillStyle = e.color.tinta; c.textAlign = "center"; c.fillText(nombre, 540, 380);
}

const FORMAS = [
  ["caja · bola", (c) => { e.objeto(c, (c) => { e.caja(c, 160, 300, 380, 460, 50, "principal"); e.bola(c, 760, 540, 170, "secundario"); }); }],
  ["pieza(p.rectRedondo) · objeto", (c) => e.objeto(c, (c) => e.pieza(c, (g) => p.rectRedondo(g, 150, 360, 780, 360, 120), "neutro"))],
  ["p.gota · p.nube", (c) => { e.objeto(c, (c) => e.pieza(c, (g) => p.gota(g, 300, 640, 150), "principal")); e.objeto(c, (c) => e.pieza(c, (g) => p.nube(g, 740, 480, 460, 300), "claro")); }],
  ["p.estrella · p.corazon · p.rayo", (c) => { e.objeto(c, (c) => e.pieza(c, (g) => p.estrella(g, 230, 540, 5, 170, 75), "acento")); e.objeto(c, (c) => e.pieza(c, (g) => p.corazon(g, 560, 540, 260), "secundario")); e.objeto(c, (c) => e.pieza(c, (g) => p.rayo(g, 870, 540, 360), "acento")); }],
  ["p.mano (dobla 0 · 0,6)", (c) => { e.objeto(c, (c) => e.pieza(c, (g) => p.mano(g, 330, 820, 560), "piel")); e.objeto(c, (c) => e.pieza(c, (g) => p.mano(g, 770, 820, 560, 0, { dobla: 0.6, izquierda: true }), "piel")); }],
  ["p.poligonoRedondo · p.ovalo", (c) => { e.objeto(c, (c) => e.pieza(c, (g) => p.poligonoRedondo(g, [[120, 760], [300, 300], [520, 760]], 30), "neutro")); e.objeto(c, (c) => e.pieza(c, (g) => p.ovalo(g, 780, 540, 200, 120, 0.3), "metal")); }],
  ["e.trazo(p.linea) · e.flecha", (c) => { e.trazo(c, (g) => p.linea(g, [[100, 300], [300, 700], [560, 360], [960, 700]])); e.flecha(c, 140, 900, 900, 820); }],
  ["e.ondas · e.rotulo", (c) => { e.objeto(c, (c) => e.bola(c, 300, 540, 90, "acento")); e.ondas(c, 300, 540, 0.25, { r0: 120 }); e.rotulo(c, 560, 360, "el altavoz", { apunta: [360, 500] }); }],
  ["e.cifra · colores", (c) => { e.cifra(c, 540, 300, "280 años luz"); ["principal", "secundario", "acento", "neutro", "metal", "piel", "claro", "invisible", "mal", "bien"].forEach((k, i) => { e.bola(c, 120 + (i % 5) * 210, 600 + Math.floor(i / 5) * 230, 80, k, { plano: true }); c.font = e.letra("normal", 30); c.fillStyle = e.color.tinta; c.textAlign = "center"; c.fillText(k, 120 + (i % 5) * 210, 720 + Math.floor(i / 5) * 230); }); }],
];

export async function corre({ marcas }) {
  if (marcas.muestra) return muestraPropia(String(marcas.muestra), marcas.estilos);
  // la misma escena en cada estilo
  const nombres = estilosQueHay(), L = createCanvas(nombres.length * 360 + (nombres.length + 1) * 8, 640 + 16), g = L.getContext("2d");
  g.fillStyle = "#ffffff"; g.fillRect(0, 0, L.width, L.height);
  const f = createCanvas(1080, 1920), c = f.getContext("2d");
  for (const [i, n] of nombres.entries()) {
    await cargaEstilo(n);
    c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = 1; c.textAlign = "left";
    muestra(c, n);
    g.drawImage(f, 8 + i * 368, 8, 360, 640);
  }
  console.log(guarda(L, join(CASA, "guia", "estilos.jpg")));

  // las formas, en un estilo
  await cargaEstilo(String(marcas.estilo || config().estilo));
  const T = 360, col = 3, filas = Math.ceil(FORMAS.length / col);
  const K = createCanvas(col * T + (col + 1) * 6, filas * (T + 36) + 6), gk = K.getContext("2d");
  gk.fillStyle = "#ffffff"; gk.fillRect(0, 0, K.width, K.height);
  const cuadro = createCanvas(1080, 1080), cc = cuadro.getContext("2d");
  FORMAS.forEach(([nombre, dibuja], i) => {
    cc.setTransform(1, 0, 0, 1, 0, 0); cc.globalAlpha = 1; cc.textAlign = "left";
    e.fondo(cc); dibuja(cc);
    const x = 6 + (i % col) * (T + 6), y = 6 + Math.floor(i / col) * (T + 36);
    gk.drawImage(cuadro, x, y, T, T);
    gk.fillStyle = "#111"; gk.font = '17px "nunito-800"'; gk.textBaseline = "top"; gk.fillText(nombre, x + 2, y + T + 8);
  });
  console.log(guarda(K, join(CASA, "guia", "catalogo.jpg")));
}

// la cosa que pida el creador, dibujada en cada estilo, para que elija
async function muestraPropia(archivo, cuales) {
  const ruta = resolve(archivo), dibuja = (await import(pathToFileURL(ruta).href)).default;
  const nombres = cuales ? String(cuales).split(",").map((x) => x.trim()).filter(Boolean) : estilosQueHay();
  const L = createCanvas(nombres.length * 360 + (nombres.length + 1) * 8, 640 + 16), g = L.getContext("2d");
  g.fillStyle = "#ffffff"; g.fillRect(0, 0, L.width, L.height);
  const f = createCanvas(1080, 1920), c = f.getContext("2d");
  for (const [i, n] of nombres.entries()) {
    await cargaEstilo(n);
    c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = 1; c.textAlign = "left";
    e.fondo(c);
    c.save(); dibuja(c, e, p); c.restore();
    c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = 1;
    c.font = e.letra("fuerte", 92); c.fillStyle = e.color.tinta; c.textAlign = "center"; c.textBaseline = "alphabetic"; c.fillText(n, 540, 380);
    g.drawImage(f, 8 + i * 368, 8, 360, 640);
  }
  const base = basename(ruta, extname(ruta));
  console.log(guarda(L, join(dirname(ruta), `estilos-${base}.jpg`)));
}
