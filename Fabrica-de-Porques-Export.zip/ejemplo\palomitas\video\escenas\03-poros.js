// «En el maíz normal, la cáscara tiene poros, y el vapor se escapa poco a poco.»
// El grano de mazorca cortado, con vapor dentro. En «poros» aparecen los agujeritos de la cáscara (rótulo); desde
// «vapor», sale vapor por cada poro a hilitos, toda la frase. Acaba antes del cambio.
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
import { bolitaVapor, porDentro } from "../comun.js";

export const empieza = "en@5";
export const paso = "barrido";
const F = voz.frase(5);
export const POROS = F.en("poros"), SALE = F.en("vapor"), PARA = voz.frase(6).desde - 0.75;
export const hilos = []; // cuándo sale cada bolita (para el sonido)
for (let k = 0, t = SALE; t < PARA - 0.6; k++, t += 0.24) hilos.push({ t, poro: (k * 4) % 9 });

export function pinta(c, t) {
  e.fondo(c, { disco: [540, 1100, 470] });
  const enc = { x: 540, y: p.recorrido([[F.desde, 1150], [POROS, 1110], [SALE, 1110], [SALE + 1.2, 1000]])(t), zoom: p.recorrido([[F.desde, 1.3], [POROS, 1.0], [SALE, 1.0], [SALE + 1.2, 1.12]])(t) };
  p.pantalla(c, enc, () => {
    const agujeros = porDentro(c, t, { forma: "mazorca", y: 1120, s: 800, vapor: 1, poros: p.llega(p.rango(t, POROS - 0.1, POROS + 0.3)), llamas: 1 });
    for (const h of hilos) {
      const u = (t - h.t) / 1.1;
      if (u <= 0 || u >= 1) continue;
      const [px, py, a] = agujeros[h.poro];
      bolitaVapor(c, px + Math.cos(a) * 200 * u, py + Math.sin(a) * 200 * u - 60 * u, 8 + 22 * u, 1 - u * u);
    }
    e.rotulo(c, 120, 660, "poros", { apunta: [agujeros[2][0], agujeros[2][1]], opacidad: p.visible(t, POROS, PARA, 0.15) });
  });
}
