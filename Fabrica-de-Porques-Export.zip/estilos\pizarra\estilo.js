// Pizarra: como explicado con tiza en una pizarra verde. Colores pastel de tiza, contornos blancos dibujados a mano
// (varias pasadas un poco movidas), letra manuscrita. Sin sombras.
import { creaEstilo } from "../comun.js";

// Pasadas de tiza: el mismo camino varias veces, un poco desplazado y con poca opacidad.
const PASADAS = [[0, 0, 0.75], [1.8, -1.2, 0.35], [-1.4, 1.6, 0.3]];

function tiza(c, camino, color, grosor) {
  c.save();
  c.lineJoin = "round"; c.lineCap = "round"; c.lineWidth = grosor; c.strokeStyle = color;
  for (const [dx, dy, a] of PASADAS) {
    c.save(); c.globalAlpha *= a; c.translate(dx, dy); camino(c); c.stroke(); c.restore();
  }
  c.restore();
}

export default creaEstilo({
  nombre: "pizarra",
  descripcion: "Pizarra verde, tiza blanca y de colores, letra a mano. Para que parezca una clase con gracia.",
  color: {
    fondo: "#24443b", fondo2: "#2c5047", suelo: "#1d3830",
    tinta: "#f1efe4",
    principal: "#8cc6ea", principalSombra: "#6aa7cf",
    secundario: "#f3a59c", secundarioSombra: "#d9837a",
    acento: "#f5e17a", acentoSombra: "#d8c35a",
    neutro: "#a6dcb2", neutroSombra: "#84bd91",
    metal: "#c9d0d3", metalSombra: "#a9b1b5",
    piel: "#f2c6a3", pielSombra: "#d6a682",
    claro: "#f1efe4", claroSombra: "#d7d4c6",
    oscuro: "#24443b",
    invisible: "#d6b8ff",
    mal: "#ff8a7a", bien: "#9ae6a8",
  },
  letras: { fuerte: "patrick-hand-400", media: "patrick-hand-400", normal: "patrick-hand-400" },
  grosor: 5,
  pieza(c, camino, [color, sombra], { plano = false, sinBorde = false, grosor } = {}, e) {
    if (!sinBorde) tiza(c, camino, e.color.tinta, 2 * (grosor ?? e.grosor));
    c.save();
    camino(c); c.fillStyle = color; c.fill();
    if (!plano) { // un rayado de sombra abajo a la derecha, como se sombrea con tiza
      c.save(); camino(c); c.clip(); c.translate(20, 20);
      c.globalAlpha = 0.5; camino(c); c.fillStyle = sombra; c.fill(); c.translate(-34, -34); camino(c); c.fillStyle = color; c.fill();
      c.restore();
    }
    c.restore();
  },
  trazo(c, camino, { papel = "tinta", grosor = 6, opacidad = 1 } = {}, e) {
    c.save(); c.globalAlpha *= opacidad; tiza(c, camino, e.color[papel] || papel, grosor); c.restore();
  },
  subtitulos: {
    tam: 92, linea: 92, letra: "patrick-hand-400", letraDicha: "patrick-hand-400",
    color: "#ffffff", dicho: "#a9c2b8", contorno: "#1b332c", grosorContorno: 10,
    resalte: "subraya", colorResalte: "#f5e17a",
  },
});
