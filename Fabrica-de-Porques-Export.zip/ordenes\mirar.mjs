// mirar: cualquier momento del vídeo en una lámina, en segundos y sin renderizar.
import { join } from "node:path";
import { carpetaVideo, para } from "../nucleo/base.mjs";
import { prepara } from "../nucleo/fotograma.mjs";
import { guarda, lamina, reparte } from "../nucleo/laminas.mjs";
import { abre } from "../nucleo/video.mjs";

export const ayuda = `
node fabrica.mjs mirar <video> <qué> [--fps N] [--ancho px] [--sin-subtitulos] [--alternativa 01-x]

Deja un .jpg en <video>/revisar/ y dice dónde. Ábrelo siempre: es como se ve.
  12.4              un fotograma grande
  9-11.5            de 9 a 11,5 s, a --fps (10 si no se dice)
  palabra sodio     de 0,5 s antes a 0,8 s después de esa palabra, a 30 fps ("sol#2" para la segunda)
  frase 5           la frase 5, de su primera palabra a la última, en 8 fotogramas
  frases            todas las frases, una fila cada una
  cambio 2          el cambio de escena 2: de 0,6 s antes a 0,4 s después, a 30 fps
  escenas           el principio, el medio y el final de cada escena
--alternativa 01-tunel: con la otra versión del gancho (video/alternativas/01-tunel.js).
`;

export async function corre({ libres, marcas }) {
  const dir = carpetaVideo(libres[0]), que = libres.slice(1);
  if (!que.length) para("Falta qué mirar: un segundo, un tramo (9-11.5), palabra <p>, frase <n>, frases, cambio <n> o escenas.");
  const alternativa = marcas.alternativa ? String(marcas.alternativa) : null;
  const v = await abre(dir, { alternativa }), est = prepara(v), voz = v.voz;
  const subtitulos = !marcas["sin-subtitulos"], ancho = Number(marcas.ancho || 0);
  const sale = (L, nombre) => console.log(guarda(L, join(dir, "revisar", (alternativa ? alternativa + "-" : "") + nombre)));
  const cada = (a, b, fps) => { const ts = []; for (let t = a; t <= b + 1e-6; t += 1 / fps) ts.push(t); return ts; };

  if (que[0] === "palabra") {
    const w = voz.palabra(que[1]), fps = Number(marcas.fps || 30);
    sale(lamina(v, est, cada(w.desde - 0.5, w.desde + 0.8, fps), { ancho: ancho || 150, columnas: 10, subtitulos, titulo: `«${w.dice}» en ${w.desde.toFixed(2)} s · ${fps} fps` }), `palabra-${que[1].replace(/[^a-z0-9#ñ]/gi, "")}.jpg`);
  } else if (que[0] === "frase") {
    const f = voz.frase(Number(que[1]));
    sale(lamina(v, est, reparte(f.palabras[0].desde, f.palabras.at(-1).hasta, Number(marcas.n || 8)), { ancho: ancho || 200, columnas: 8, subtitulos, titulo: `Frase ${f.n}: «${f.dice}»` }), `frase-${f.n}.jpg`);
  } else if (que[0] === "frases") {
    const ts = [];
    for (const f of voz.frases) reparte(f.palabras[0].desde, f.palabras.at(-1).hasta, 6).forEach((t, i) => ts.push(i ? t : { t, nota: `${f.n}: ${t.toFixed(2)}` }));
    sale(lamina(v, est, ts, { ancho: ancho || 150, columnas: 6, subtitulos, titulo: "Cada frase, de su primera palabra a la última" }), "frases.jpg");
  } else if (que[0] === "cambio") {
    const n = Number(que[1]), s = v.escenas[n];
    if (!s || n < 1) para(`No hay cambio ${que[1]}: hay ${v.escenas.length - 1} (del 1 al ${v.escenas.length - 1}).`);
    const fps = Number(marcas.fps || 30);
    const ts = cada(s.empieza - 0.6, s.empieza + 0.4, fps).map((t) => (Math.abs(t - s.empieza) < 0.5 / fps ? { t, nota: `${t.toFixed(2)} ${s.paso}` } : t));
    sale(lamina(v, est, ts, { ancho: ancho || 150, columnas: 10, subtitulos, titulo: `Cambio ${n}: ${v.escenas[n - 1].id} → ${s.id} (${s.paso}) en ${s.empieza.toFixed(2)} s` }), `cambio-${n}.jpg`);
  } else if (que[0] === "escenas") {
    const ts = [];
    for (const s of v.escenas) reparte(s.empieza + 0.02, s.acaba - 0.02, 4).forEach((t, i) => ts.push(i ? t : { t, nota: s.id.slice(0, 14) }));
    sale(lamina(v, est, ts, { ancho: ancho || 150, columnas: 8, subtitulos, titulo: "Cada escena: principio, medio y final" }), "escenas.jpg");
  } else if (/^\d+(\.\d+)?-\d+(\.\d+)?$/.test(que[0])) {
    const [a, b] = que[0].split("-").map(Number), fps = Number(marcas.fps || 10), ts = cada(a, b, fps);
    if (ts.length > 120) para(`Son ${ts.length} fotogramas: pide menos tiempo o menos fps (120 como mucho).`);
    sale(lamina(v, est, ts, { ancho: ancho || 150, columnas: 10, subtitulos, titulo: `De ${a} a ${b} s · ${fps} fps` }), `tramo-${a}-${b}.jpg`);
  } else if (/^\d+(\.\d+)?$/.test(que[0])) {
    const t = Number(que[0]);
    sale(lamina(v, est, [t], { ancho: ancho || 540, columnas: 1, subtitulos }), `en-${t}.jpg`);
  } else para(`No sé mirar «${que.join(" ")}». Mira: node fabrica.mjs mirar --ayuda`);
}
