// «¿Por qué el maíz de palomitas explota y el de la mazorca no?» «Los dos son maíz, pero solo uno salta.»
// Fotograma 0: los dos granos en la sartén caliente, cerca del de palomitas, que tiembla. A los 0,3 s revienta en una
// palomita enorme con trozos de cáscara volando. En «mazorca» la cámara va al otro grano, que solo se tuesta y
// humea. En la frase 2 se aleja para ver los dos y en «salta» la palomita da un bote con voltereta.
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
import { grano, humo, mazorca, palomita, sarten } from "../comun.js";

export const empieza = 0;

export const REVIENTA = 0.3;
const F1 = voz.frase(1), F2 = voz.frase(2);
const T_MAZ = F1.en("mazorca"), T_LEJOS = F2.desde, T_SALTA = F2.en("salta");
export const SALTO = { despega: T_SALTA - 0.08, cae: T_SALTA + 0.6 };

const SUELO = 1460, GX = 385, MX = 715, GY = SUELO - 120;

const camara = (t) => ({
  x: p.recorrido([[0, GX + 10], [T_MAZ - 0.35, GX + 10], [T_MAZ + 0.35, MX], [T_LEJOS, MX], [T_LEJOS + 0.9, 550]])(t),
  y: p.recorrido([[0, 1250], [T_LEJOS, 1250], [T_LEJOS + 0.9, 1290]])(t),
  zoom: p.recorrido([[0, 2.1], [T_LEJOS, 2.0], [T_LEJOS + 0.9, 1.4]])(t),
});

// trozos de cáscara que salen volando al reventar: [ángulo, velocidad, giro]
const TROZOS = [[-2.3, 900, 7], [-0.6, 820, -6], [-1.5, 1050, 9], [-2.8, 700, -8], [-0.2, 760, 5]];

export function pinta(c, t) {
  e.fondo(c);
  p.pantalla(c, camara(t), () => {
    sarten(c, SUELO, t);
    // el grano de mazorca: se tuesta y humea, nada más
    const tueste = p.entre(t, T_MAZ - 0.2, T_MAZ + 0.8, 0, 0.55);
    humo(c, MX, GY - 110, t, T_MAZ + 0.1, { n: 6 });
    e.objeto(c, (c) => mazorca(c, MX, GY, 230, { tostado: tueste }));

    // el de palomitas: tiembla, revienta y luego salta
    if (t < REVIENTA) {
      const tiembla = 10 * p.rango(t, 0, REVIENTA) * Math.sin(t * 90);
      e.objeto(c, (c) => grano(c, GX + tiembla, GY, 230, { rot: tiembla * 0.004 }));
    } else {
      const u = p.rango(t, REVIENTA, REVIENTA + 0.28), abre = p.rebota(u, 1.4);
      const latido = 0.05 * p.latido(t, F1.en("explota"), 0.12);
      const s = SALTO, k = p.rango(t, s.despega, s.cae);
      const alto = 330 * 4 * k * (1 - k), giro = p.suaviza(k) * Math.PI * 2;
      const aplasta = 1 - 0.12 * p.latido(t, s.cae + 0.02, 0.06);
      e.objeto(c, (c) => {
        c.save(); c.translate(GX, GY - 60 * abre - alto); c.scale(1 + latido, (1 + latido) * aplasta);
        palomita(c, 0, 0, p.mezcla(230, 330, abre), { abre, rot: giro, semilla: 4 });
        c.restore();
      });
      // el fogonazo y los trozos que vuelan
      if (t < REVIENTA + 0.5) {
        const f = p.rango(t, REVIENTA, REVIENTA + 0.35);
        e.objeto(c, (c) => e.pieza(c, (g) => p.estrella(g, GX, GY - 60, 10, 120 + 360 * p.llega(f), 60 + 200 * p.llega(f), f * 0.6), "acento", { plano: true }), { opacidad: 1 - f, sinSombra: true });
      }
      for (const [a, v, gi] of TROZOS) {
        const dt = t - REVIENTA;
        if (dt > 1.6) continue;
        const x = GX + Math.cos(a) * v * dt, y = GY - 60 + Math.sin(a) * v * dt + 0.5 * 2600 * dt * dt;
        if (y > SUELO + 200) continue;
        e.objeto(c, (c) => e.pieza(c, (g) => { g.save(); g.translate(x, y); g.rotate(gi * dt); g.beginPath(); g.ellipse(0, 0, 34, 16, 0, 0, Math.PI * 2); g.closePath(); g.restore(); }, "acento"));
      }
    }
  });
}
