// Caminos: solo trazan (beginPath ... closePath). Luego se rellenan con e.pieza(c, camino, rol) del estilo, o con
// fill/stroke a mano. Todos reciben el contexto c como primer argumento.

// nuevo = false añade el rectángulo al camino que ya hay (para juntar varias piezas en una sola forma).
export function rectRedondo(c, x, y, w, h, r = 20, nuevo = true) {
  const k = Math.max(0, Math.min(r, w / 2, h / 2));
  if (nuevo) c.beginPath();
  c.moveTo(x + k, y);
  c.arcTo(x + w, y, x + w, y + h, k);
  c.arcTo(x + w, y + h, x, y + h, k);
  c.arcTo(x, y + h, x, y, k);
  c.arcTo(x, y, x + w, y, k);
  c.closePath();
}

export function circulo(c, x, y, r) {
  c.beginPath(); c.arc(x, y, Math.max(0.1, r), 0, Math.PI * 2); c.closePath();
}

export function ovalo(c, x, y, rx, ry, ang = 0) {
  c.beginPath(); c.ellipse(x, y, Math.max(0.1, rx), Math.max(0.1, ry), ang, 0, Math.PI * 2); c.closePath();
}

export function poligono(c, puntos) {
  c.beginPath();
  puntos.forEach(([x, y], i) => (i ? c.lineTo(x, y) : c.moveTo(x, y)));
  c.closePath();
}

// Un polígono con las esquinas redondeadas (radio r en cada vértice).
export function poligonoRedondo(c, puntos, r = 16) {
  const n = puntos.length;
  c.beginPath();
  for (let i = 0; i <= n; i++) {
    const p = puntos[i % n], q = puntos[(i + 1) % n];
    const mx = (p[0] + q[0]) / 2, my = (p[1] + q[1]) / 2;
    if (i === 0) c.moveTo(mx, my);
    else c.arcTo(p[0], p[1], mx, my, r);
  }
  c.closePath();
}

export function estrella(c, x, y, puntas, rFuera, rDentro, giro = -Math.PI / 2) {
  const pts = [];
  for (let i = 0; i < puntas * 2; i++) {
    const r = i % 2 ? rDentro : rFuera, a = giro + (i * Math.PI) / puntas;
    pts.push([x + Math.cos(a) * r, y + Math.sin(a) * r]);
  }
  poligonoRedondo(c, pts, rFuera * 0.06);
}

// Una gota con la punta arriba: centro de la parte redonda (x, y) y radio r.
export function gota(c, x, y, r) {
  c.beginPath();
  c.moveTo(x, y - r * 2.1);
  c.bezierCurveTo(x + r * 0.55, y - r * 1.25, x + r, y - r * 0.6, x + r, y);
  c.arc(x, y, r, 0, Math.PI);
  c.bezierCurveTo(x - r, y - r * 0.6, x - r * 0.55, y - r * 1.25, x, y - r * 2.1);
  c.closePath();
}

// Una nube de bultos: ancho w y alto h, apoyada en (x, y) por su centro.
export function nube(c, x, y, w, h) {
  const bultos = [[-0.32, 0.12, 0.3], [-0.08, -0.12, 0.38], [0.22, -0.02, 0.32], [0.38, 0.16, 0.22], [-0.42, 0.24, 0.18]];
  c.beginPath();
  for (const [dx, dy, r] of bultos) { c.moveTo(x + dx * w + r * w, y + dy * h); c.arc(x + dx * w, y + dy * h, r * w, 0, Math.PI * 2); }
  rectRedondo(c, x - 0.45 * w, y, 0.9 * w, 0.32 * h, 0.16 * h, false);
}

// Un corazón de ancho w centrado en (x, y).
export function corazon(c, x, y, w) {
  const s = w / 2;
  c.beginPath();
  c.moveTo(x, y + s * 0.95);
  c.bezierCurveTo(x - s * 1.5, y - s * 0.05, x - s * 0.75, y - s * 1.15, x, y - s * 0.45);
  c.bezierCurveTo(x + s * 0.75, y - s * 1.15, x + s * 1.5, y - s * 0.05, x, y + s * 0.95);
  c.closePath();
}

// Un rayo en zigzag, de alto h, centrado en (x, y).
export function rayo(c, x, y, h) {
  const s = h / 10;
  poligono(c, [[x + s, y - 5 * s], [x - 2.6 * s, y + 0.6 * s], [x - 0.2 * s, y + 0.6 * s], [x - 1.2 * s, y + 5 * s], [x + 2.6 * s, y - 0.9 * s], [x + 0.3 * s, y - 0.9 * s]]);
}

// Un tubo o cable que sigue unos puntos (para trazarlo con stroke, no se rellena).
export function linea(c, puntos, curva = true) {
  c.beginPath();
  c.moveTo(puntos[0][0], puntos[0][1]);
  if (!curva || puntos.length < 3) { for (const p of puntos.slice(1)) c.lineTo(p[0], p[1]); return; }
  for (let i = 1; i < puntos.length - 1; i++) {
    const mx = (puntos[i][0] + puntos[i + 1][0]) / 2, my = (puntos[i][1] + puntos[i + 1][1]) / 2;
    c.quadraticCurveTo(puntos[i][0], puntos[i][1], mx, my);
  }
  const u = puntos[puntos.length - 1];
  c.lineTo(u[0], u[1]);
}

// Una mano abierta vista de frente (palma), de alto h, con la muñeca en (x, y), girada ang radianes. Cinco dedos:
// cuatro y el pulgar aparte; el corazón, el más largo; el meñique, el más corto. dobla (0 a 1) cierra los dedos.
export function mano(c, x, y, h, ang = 0, { dobla = 0, izquierda = false } = {}) {
  const s = h / 100, lado = izquierda ? -1 : 1;
  const dedos = [ // [x base, largo, ancho] de índice a meñique
    [-17, 40, 13], [-3, 45, 13.5], [11, 41, 13], [24, 32, 11.5],
  ];
  c.save();
  c.translate(x, y); c.rotate(ang); c.scale(s * lado, s);
  c.beginPath();
  rectRedondo(c, -24, -52, 58, 56, 18, false);          // la palma
  rectRedondo(c, -16, -6, 40, 16, 7, false);             // la muñeca
  for (const [dx, largo, ancho] of dedos) {
    const l = largo * (1 - 0.55 * dobla);
    rectRedondo(c, dx - ancho / 2, -52 - l + 6, ancho, l + 8, ancho / 2, false);
  }
  c.restore();
  // el pulgar, aparte y abierto hacia fuera
  c.save();
  c.translate(x, y); c.rotate(ang); c.scale(s * lado, s);
  c.translate(-26, -22); c.rotate(-0.55 + 0.5 * dobla);
  rectRedondo(c, -7, -38, 15, 42, 7.5, false);
  c.restore();
}
