# El vídeo terminado

Esta carpeta trae todas las piezas del ejemplo (escenas, voz, efectos, guion, plan y láminas de revisión), pero no el
vídeo final, para que la descarga pese poco. Para verlo, pídele a Claude: «Renderiza el ejemplo de las palomitas».
Lanzará `node fabrica.mjs render ejemplo/palomitas` y el vídeo saldrá en `salida/palomitas/`. No gasta créditos de
voz: la voz ya está hecha.

Para revisar cómo está construido no hace falta el vídeo: `node fabrica.mjs mirar ejemplo/palomitas frases` enseña
cualquier momento sin renderizar.
