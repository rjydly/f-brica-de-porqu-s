# Los sonidos de Fábrica de Porqués

Todos están generados con los efectos de sonido de ElevenLabs (con un plan de pago, así que se pueden usar en
cualquier vídeo, también comercial, sin citar a nadie) y suenan como grabaciones reales: cortos, suaves, en mono y
con el pico a -3 dB. Son los que el creador de Fábrica de Porqués escuchó y aprobó. En `efectos.js` se piden por su nombre, sin la
extensión.

| Nombre | Qué es | Para qué |
|---|---|---|
| `zas` | un aire corto y suave que pasa cerca | la cámara que se mueve, algo que entra o pasa cerca |
| `zas-largo` | un aire suave, lento y largo | un movimiento largo de cámara |
| `impulso` | un aire fuerte que se acerca y acaba en golpe | lanzarse hacia algo, apretarse, desplomarse |
| `boom` | una explosión con un retumbar corto | algo que explota o revienta |
| `crac` | una cáscara o una piedra pequeña que se parte | romperse una cáscara, una piedra, un hueso |
| `golpe` | algo que cae sobre una mesa, sordo y firme | algo que choca o se posa |
| `golpe-grave` | algo grande que cae al suelo, hondo | el choque más grande del vídeo |
| `clic` | un clic limpio, como un bolígrafo | algo aparece, se marca o se para en su sitio |
| `tic` | un toquecito de madera, muy corto y flojo | un número que corre, algo que traquetea |
| `pop` | una burbuja que estalla, redonda | algo blando o redondo que aparece |
| `sube` | un aire corto que sube | algo que sube o se va |
| `baja` | un aire corto que baja y se apaga | algo que baja o se apaga |
| `latido` | un latido de corazón, redondo y grave | el latido de la cosa principal (siempre el mismo) |
| `metal` | una herramienta de acero que choca con metal | metal que choca o encaja |
| `madera` | un nudillo en una mesa de madera | madera, una mesa, un nudillo |
| `cristal` | un cristal pequeño que se posa | cristal o hielo que choca |
| `campana` | una campanita clara | algo que se completa, un final bonito |
| `papel` | una hoja que se mueve y se pasa | papel, cartas, fotos |
| `muelle` | una pelota que bota dos veces | algo que bota o rebota |
| `error` | dos notas graves y suaves | lo que está mal, un fallo |
| `bien` | dos notas que suben, cálidas | lo que está bien, un acierto |
| `pitido` | el pitido corto de un termómetro de cocina | un aparato que mide o avisa |
| `aviso` | la notificación de un móvil | un mensaje que llega |
| `aplasta` | algo blando que se aprieta, como una esponja | apretar, aplastar, morder |
| `desliza` | algo que se desliza por una mesa | deslizar, arrastrar |
| `roce` | un roce suave de tela que pasa, grave y sin siseo | algo blando que entra o pasa; un cambio suave (el creador lo prefirió a `desliza`, que le suena a refresco abierto) |
| `chispazo` | un chasquido eléctrico seco y corto (0,3 s), grabación real | una chispa o señal eléctrica (el creador lo prefirió a `chispa`, que sisea). De «Electricity Game Sound Pack» (groundhit.wav), OpenGameArt, CC0: https://opengameart.org/node/150369 |
| `oleada` | un «whoom» grave y redondo que sube y se apaga | algo que crece o cambia despacio |
| `gota` | una gota que cae en un vaso de agua | agua, una gota que cae |
| `chispa` | un brillo mágico suave | brillo, magia, una idea |
| `confeti` | un soplido alegre que sube y acaba en destello, con papelitos (1,45 s), generado con ElevenLabs y elegido de oído por el creador | confeti, celebración, un fogonazo de alegría |
| `tecla` | una tecla que se pulsa | pulsar una tecla |
| `tecleo` | un segundo tecleando en un portátil | escribir en el ordenador |
| `enter` | la tecla Intro, algo más pesada | enviar, confirmar |

Para añadir uno nuevo: ponlo con su descripción y su duración en `herramientas/fabrica-sonidos.mjs` y lanza
`node herramientas/fabrica-sonidos.mjs <nombre>` (gasta muy pocos créditos de ElevenLabs). No rehagas los que ya
están: cada vez sale una versión distinta y estos son los aprobados. Nunca se fabrica un sonido por síntesis.
También puedes añadir sonidos tuyos (`.wav` o `.mp3`) en esta carpeta: se piden por su nombre de archivo.
