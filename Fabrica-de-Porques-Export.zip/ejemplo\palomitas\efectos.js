// Los efectos de sonido: cada uno en lo que se mueve, en su fotograma (guia/sonido.md).
import { voz } from "#voz";
import { REVIENTA as R1, SALTO } from "./video/escenas/01-sarten.js";
import { FUEGO, GOTA, SALIR, VAPOR } from "./video/escenas/02-agua.js";
import { POROS, hilos } from "./video/escenas/03-poros.js";
import { CHOCA, DURA } from "./video/escenas/04-dura.js";
import { silba } from "./video/escenas/05-olla.js";
import { REVIENTA as R6 } from "./video/escenas/06-revienta.js";
import { CAE as CAE7, LANZA } from "./video/escenas/07-patita.js";
import { CHORRO } from "./video/escenas/08-suena.js";
import { CAE as CAE10 } from "./video/escenas/10-cuenco.js";

const lista = [];
const suena = (sonido, t, op = {}) => lista.push({ sonido, t, ...op });
const f = (n) => voz.frase(n);

// 1-2 · la sartén
suena("pop", R1 + 0.02, { nivel: -6, que: "revienta la palomita" });
suena("crac", R1 + 0.01, { nivel: -12, tono: 1.2 });
suena("zas", R1 + 0.15, { nivel: -18, tono: 1.3, que: "vuelan los trozos" });
suena("tic", R1 + 0.75, { nivel: -17 });
suena("tic", R1 + 1.05, { nivel: -18, tono: 1.2, que: "caen los trozos" });
suena("zas", f(1).en("mazorca") - 0.3, { desde: "inicio", nivel: -18, tono: 0.8, que: "la cámara va a la mazorca" });
suena("aplasta", f(1).en("mazorca") + 0.25, { nivel: -16, tono: 0.7, que: "se tuesta y humea" });
suena("zas-largo", f(2).desde + 0.05, { desde: "inicio", nivel: -18, que: "la cámara se aleja" });
suena("latido", f(2).en("maiz") + 0.05, { nivel: -16, que: "los dos granos" });
suena("muelle", SALTO.despega + 0.05, { nivel: -11, que: "salta" });
suena("golpe", SALTO.cae, { nivel: -14, tono: 1.2, que: "cae" });

// 3-4 · dentro del grano
suena("zas", f(3).en("cada") - 0.1, { desde: "inicio", nivel: -18, tono: 0.8, que: "la cámara entra hacia el centro" });
suena("latido", f(3).en("grano") + 0.05, { nivel: -17 });
suena("gota", GOTA + 0.05, { nivel: -9, que: "aparece la gota" });
suena("clic", f(3).en("agua"), { nivel: -15, que: "rótulo agua" });
suena("zas", FUEGO, { desde: "inicio", nivel: -18, tono: 0.7, grave: 3000, que: "se encienden las llamas" });
suena("sube", VAPOR, { nivel: -12, que: "la gota se hace vapor" });
for (let i = 0; i < 4; i++) suena("pop", VAPOR + 0.12 + i * 0.13, { nivel: -18, tono: 1.1 + i * 0.12 });
suena("impulso", SALIR + 0.45, { nivel: -13, tono: 1.3, que: "empujan la cáscara" });

// 5 · el maíz normal: los poros
suena("zas", f(5).desde + 0.1, { nivel: -18, tono: 0.9, que: "el barrido al maíz normal" });
suena("latido", f(5).en("cascara"), { nivel: -16, que: "la cámara se aleja" });
suena("clic", POROS, { nivel: -13, que: "aparecen los poros" });
hilos.forEach((h, i) => { if (i % 2 === 0) suena("desliza", h.t + 0.2, { nivel: -20, tono: 1.6, que: i === 0 ? "el vapor se escapa" : undefined }); });

// 6 · la cáscara dura y la olla
suena("zas", f(6).desde + 0.1, { nivel: -18, tono: 0.9, que: "el barrido de vuelta" });
suena("latido", f(6).en("palomitas"), { nivel: -16, que: "las bolitas de vapor" });
suena("golpe", DURA + 0.08, { nivel: -11, que: "la cáscara engorda" });
suena("golpe", CHOCA, { nivel: -13, tono: 1.3, que: "las flechas chocan" });
suena("desliza", silba, { nivel: -10, tono: 0.75, que: "silba la olla" });
suena("desliza", silba + 0.5, { nivel: -12, tono: 0.8 });
suena("metal", silba + 0.1, { nivel: -16, tono: 1.4, que: "tiembla la tapa" });

// 7-8 · la presión, el reventón y la espuma
suena("clic", f(7).en("ochenta"), { nivel: -13, que: "180 °C" });
for (let i = 0; i < 11; i++) suena("tic", f(7).en("presion") + i * 0.22, { nivel: -19 + i, tono: 1 + i * 0.05 });
suena("clic", f(7).en("nueve"), { nivel: -13, que: "presión × 9" });
suena("boom", R6, { nivel: -6, que: "revienta la cáscara" });
suena("crac", R6 - 0.03, { nivel: -11 });
suena("zas", R6 + 0.2, { nivel: -18, que: "vuelan las mitades" });
suena("aplasta", f(8).en("hincha"), { nivel: -11, tono: 0.6, que: "la espuma se hincha" });
suena("sube", f(8).en("espuma"), { nivel: -15, tono: 0.8 });
suena("zas-largo", f(8).en("cuarenta") - 0.5, { desde: "inicio", nivel: -18, que: "la cámara se aleja" });
suena("pop", f(8).en("cuarenta") + 0.1, { nivel: -11, que: "× 40 y el grano pequeño" });

// 9 · la patita
suena("zas", f(8).en("tamano") + 0.4, { nivel: -18, tono: 0.7, que: "la cámara se para" });
suena("aplasta", f(9).desde + 0.3, { nivel: -16, tono: 0.8, que: "el grano se abre en la sartén" });
suena("sube", f(9).en("patita"), { nivel: -14, tono: 1.3, que: "sale la patita" });
suena("aplasta", f(9).en("empuja") + 0.15, { nivel: -10, que: "empuja" });
suena("muelle", LANZA, { nivel: -10, que: "despega" });
suena("zas", LANZA + 0.1, { nivel: -18, tono: 0.9 });
suena("golpe", CAE7, { nivel: -13, que: "cae abierta" });

// 10 · lo que suena
suena("error", f(10).en("cascara") + 0.02, { nivel: -13, que: "la cruz" });
suena("pop", CHORRO + 0.03, { nivel: -6, que: "el vapor sale de golpe" });
suena("sube", CHORRO + 0.05, { nivel: -12 });
suena("latido", CHORRO + 0.7, { nivel: -16 });

// 11 · el remate
suena("zas", f(11).en("grano") - 0.3, { desde: "inicio", nivel: -18, tono: 0.8, que: "la cámara entra" });
suena("desliza", f(11).en("cascara"), { nivel: -13, tono: 1.3, que: "se marca la cáscara" });
suena("clic", f(11).en("cascara") + 0.12, { nivel: -14 });
suena("latido", f(11).desde + 0.4, { nivel: -17 });

// 12 · el cuenco
suena("zas", CAE10 - 0.4, { nivel: -18, tono: 1.2, que: "cae la quemada" });
suena("golpe", CAE10, { nivel: -11, que: "aterriza" });
suena("crac", CAE10 + 0.02, { nivel: -17, tono: 0.7 });
suena("tic", CAE10 + 0.42, { nivel: -16, que: "bota" });
suena("aplasta", CAE10 + 0.8, { nivel: -18, tono: 0.6, que: "humea" });
suena("campana", CAE10 + 1.4, { nivel: -16, que: "final" });

export default lista;
