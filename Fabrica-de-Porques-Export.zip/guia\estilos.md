# Los estilos

El estilo decide cómo se ve todo: el fondo, los colores, si las cosas llevan contorno, cómo es su sombra, la letra y
los subtítulos. Las escenas no saben de colores ni de bordes: piden "una pieza principal" o "una cifra" y el estilo la
dibuja a su manera. Por eso un vídeo entero cambia de aspecto cambiando una palabra.

`guia/estilos.jpg` enseña la misma escena en cada estilo.

| Estilo | Cómo es | Para qué temas |
|---|---|---|
| `casa` (el de Fábrica de Porqués) | plano y minimalista sobre azul noche: colores lisos, cara de luz y sombra dura, sin contornos ni bordes | casi todo: el de los vídeos de Un minuto de porqués |
| `pegatina` | fondo ciruela oscuro, cada cosa como una pegatina con borde blanco, colores vivos | casi todo: se ve desde lejos en un móvil |
| `tinta` | cómic de noche: fondo carbón, contorno claro, colores planos | ciencia, curiosidades, historias |
| `medianoche` | índigo con halo, sin contornos, filo de luz en cada pieza | temas serios o elegantes, espacio, historia |
| `arcilla-noche` | 3D suave como plastilina sobre fondo oscuro y cálido | comida, cuerpo humano, temas amables |
| `grafito` | líneas de color sobre gris carbón, como un boceto técnico | máquinas, inventos, cómo funciona algo |
| `neon` | negro con rejilla, tubos de luz de colores | tecnología, internet, videojuegos, noche |
| `pizarra` | pizarra verde, tiza blanca y de colores, letra a mano | explicaciones tipo clase, matemáticas |
| `papel` | fondo crema, contorno de tinta, colores planos | el único claro: para quien quiera fondo claro |
| `arcilla` | 3D suave como plastilina, fondo claro y cálido | lo mismo que arcilla-noche, de día |

Una escena de día al aire libre (un edificio, una playa, una calle) no va sobre el fondo oscuro del estilo: pinta su
cielo con `e.cielo(c, { tiempo: "despejado" | "nublado" | "noche" })` y su lluvia con `e.lluvia`. Cada estilo puede
traer sus cielos (`cielos` en su `estilo.js`, como `casa`); si no, salen los de `estilos/comun.js`. Los estilos
`grafito` y `neon` están pensados para escenas oscuras y de día se ven apagados; para eso, mejor `pegatina`, `tinta`
o `medianoche`.

## Elegir

- Para todos los vídeos: `node fabrica.mjs estilo <nombre>` (se guarda en `fabrica.config.json`).
- Para un vídeo: `"estilo": "<nombre>"` en su `guion.json`, o `node fabrica.mjs estilo <nombre> --video <video>`.
- Si el creador describe un aspecto propio ("como un cómic de los 80", "con mis colores de marca"), se hace un
  estilo nuevo y se guarda para siempre en `preferencias.md`.

## Hacer un estilo nuevo

1. Copia `estilos/pegatina/` (o el que más se parezca) a `estilos/<nombre>/`.
2. En su `estilo.js` cambia:
   - `color`: el fondo, la tinta y cada papel con su sombra. Que `principal`, `secundario` y `acento` se distingan bien
     entre sí y del fondo.
   - `letras`: los archivos de `letra/` (sin extensión: `"nunito-900"`). Para otra letra, pon su `.woff2` o `.ttf` en
     `letra/` con su licencia (las de Google Fonts sirven).
   - `pieza`: cómo se rellena una pieza (con o sin contorno, con su sombra propia o con degradado).
   - `sombra`: lo que lleva debajo cada `e.objeto` (una sombra dura, una suave, un brillo, o nada).
   - `subtitulos`: tamaño, colores, contorno y cómo se marca la palabra que resalta (`rotulador`, `subraya`, `neon` o
     `pastilla`).
   - Si hace falta, `fondo`, `trazo`, `flecha`, `rotulo` o `cifra` propios (mira `estilos/neon/` y `estilos/arcilla/`).
3. `node fabrica.mjs catalogo --estilo <nombre>` y mira `guia/catalogo.jpg` y `guia/estilos.jpg`: todo tiene que
   leerse bien y los subtítulos tienen que contrastar con el fondo.
