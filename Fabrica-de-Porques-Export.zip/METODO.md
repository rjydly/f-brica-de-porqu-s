# El método de Fábrica de Porqués: de una idea a un reel terminado

**Qué sale de aquí:** un reel vertical de 30 a 60 segundos. Una voz cuenta algo que sorprende y, a la vez, en la
pantalla pasa lo que dice: dibujado, grande y en movimiento. No es una presentación con dibujos quietos ni un
esquema con flechas y etiquetas. Es la cosa de verdad haciendo lo que la voz cuenta, para alguien que va pasando
vídeos con el pulgar y decide en un segundo si se queda.

**Antes del primer vídeo de cada conversación** lee este archivo entero y también `guia/guion.md`, `guia/dibujo.md`
y `guia/sonido.md`. Abre `guia/estilos.jpg` y `guia/catalogo.jpg` (lo que ya saben dibujar los pinceles) y mira el
vídeo de ejemplo de `ejemplo/`: su `plan.md`, sus `notas.md`, sus escenas (`video/escenas/*.js`) y sus láminas
(`node fabrica.mjs mirar ejemplo/<nombre> frases` y `... escenas`). El ejemplo enseña el nivel y cómo se construye;
sus dibujos son de su tema y no se copian a otro.

**Sin prisa.** Un buen vídeo lleva un par de horas y muchas vueltas de mirar y arreglar. Lo que lo hace bueno no es
el primer intento: es revisarlo en movimiento hasta que no haya nada raro.

---

## Paso 1 · Investigar

Si el creador pide ideas en vez de traer una, `node fabrica.mjs tendencias --nicho "<su nicho>"` deja en
`tendencias/` los vídeos de su nicho que más vistas sacan por día, lo que la gente busca y lo que se comenta. Una tendencia da el
tema y el gancho; los datos salen de la fuente original, como siempre. Que elija con botones (`AskUserQuestion`).

1. `node fabrica.mjs nuevo "<la idea>"` crea la carpeta del vídeo en `videos/`.
2. Busca el tema en internet y llega a la fuente original: el estudio, el organismo oficial, el fabricante, el
   artículo del periódico que lo publicó primero. Un resumen de otro no basta.
3. Rellena `idea.md`. Cada dato lleva al lado su fuente. Busca estos cinco ingredientes:
   - **La sorpresa:** lo que choca con lo que casi todo el mundo cree o parece imposible.
   - **La creencia que rompe:** qué pensaría cualquiera, y por qué tendría sentido pensarlo.
   - **La cadena:** el mecanismo paso a paso, cada causa con su efecto y en su orden.
   - **Números que se sienten:** cifras que se puedan imaginar (tantos grados, tantos campos de fútbol).
   - **Dos o tres comparaciones de casa:** "del tamaño de una lenteja", "pesa como un coche", "lo mismo que hay en
     tu nevera". Son las imágenes que mejor se entienden.
4. Escribe en una sola frase lo que cuenta el vídeo. Lo que no ayude a esa frase, fuera.

## Paso 2 · El guion, pensado para verse

Lee `guia/guion.md`. El guion se escribe en **`guion.md`, dentro de la carpeta del vídeo**, con la forma de
`ejemplo/palomitas/guion.md`: los dos ganchos, la tabla frase a frase, los sitios y el texto para leer de corrido.
Después se convierte en `guion.json` con una orden; no se escribe a mano.

1. **Dos ganchos.** Escribe dos ganchos distintos (dos o tres frases cortas cada uno, unos 8 segundos) y, para cada
   uno, **qué se ve del fotograma 0 al segundo 1**: algo grande que llena la pantalla y pasa (vuela, se llena, choca,
   explota, se destapa). Los dos pasan las cinco pruebas del gancho y no caen en nada de la lista de «Nunca». Si el
   creador pidió el vídeo con una pregunta, esa pregunta suele ser uno de los dos.
2. **Enséñalos y pregunta.** En un mensaje corto, los dos ganchos con su primer segundo. Pregunta con botones
   (`AskUserQuestion`): «Gancho A» · «Gancho B» · «Ninguno, rehazlos». Si elige el B, cambia el gancho de `guion.md` y
   ajusta lo que haga falta para que enlace. Si no le convence ninguno, rehaz los dos.
3. **El resto, con el gancho elegido.** El cuerpo: cada frase es algo que pasa o una comparación con algo de casa.
   Si no se puede enseñar pasando, se reescribe. La imagen se piensa a la vez que la frase: al escribir "cabe en una
   cucharilla" ya sabes que va a salir una cucharilla. Un segundo «¡anda!» a mitad del vídeo. El giro final contesta
   del todo la pregunta y enlaza con el principio. El cierre es el del creador, tal cual está en `preferencias.md`.
4. **La tabla, frase a frase:** `| # | Frase | Resalta | Lo que se ve |`. Una fila por frase; en «Lo que se ve», de
   su primera palabra a la última, lo que pasa en pantalla. **Las primeras filas son el gancho elegido** (dos o tres;
   si son otras, `--gancho <n>`). Una palabra que resalta por frase (la que se marca en los subtítulos); leídas
   seguidas, cuentan el vídeo. Dale tiempo a lo que se ve: una lista de tres o cuatro cosas como mucho; una
   comparación que pasa en otro sitio, con su frase entera; nada que la voz diga más rápido de lo que se puede
   dibujar.
5. **Los sitios y el texto de corrido.** Apunta los sitios (uno por cada cosa de la que habla la voz), como en el
   ejemplo; sirven para el paso 4. Al final de `guion.md`, el texto para leer de corrido, sin la columna de lo que
   se ve.
6. **`pie.txt`**, al lado de `guion.md`: el texto del post, dos líneas, la primera engancha. Sin hashtags y sin
   rayas largas.
7. **Conviértelo:** `node fabrica.mjs guion <video>` lee `guion.md`, escribe `guion.json` y, si `plan.md` está
   vacío, copia ahí las frases y lo que se ve. Conserva el estilo, los subtítulos y la voz que ya tuviera el vídeo.
   `--idioma es-419` para español de América; `--gancho 3` si el gancho lleva tres frases. Si el creador solo quiere
   el guion, para aquí y entrégale `guion.md` y `pie.txt`.

Si el creador trae un `guion.md` hecho con Fábrica de Guiones, no se reescribe: `node fabrica.mjs guion
"..\fabrica-de-guiones\guiones\<nombre>\guion.md" --nombre <nombre>` crea el vídeo, copia el guion, el `pie.txt` y el
`idea.md`, y lo convierte. Todo ocurre en esta misma conversación: no hace falta abrir la otra carpeta.

## Paso 3 · La voz

`node fabrica.mjs voz <video>`
- Sale de **una sola toma**, como habla una persona. No se corta ni se le quitan pausas: recortar por los tiempos que
  da el proveedor se come trozos de palabras.
- Imprime cada frase con el segundo de cada palabra. Con eso se planea todo.
- Si una frase suena rara, rápida o atropellada, **se cambia la frase** (otras palabras, otra puntuación) y se pide
  la voz otra vez. Nunca se acelera ni se recorta el audio.
- La voz es la de `fabrica.config.json` (si el creador eligió una con `voz-id`) o la de Fábrica de Porqués. Por
  defecto la pone **Kokoro en este ordenador** (gratis, sin clave ni internet); ElevenLabs solo si se elige.

## Paso 4 · El plan

Escribe `plan.md` antes de dibujar nada.

`guion` ya habrá copiado las frases y la columna de lo que se ve si `plan.md` estaba vacío. Complétalo con el
momento fuerte, la cámara y el paso a la siguiente; no rehagas esa columna desde cero.

- **Los sitios.** Uno por cada cosa de la que habla la voz, y para cada uno, si es de día o de noche (`guia/dibujo.md`). Mientras la voz sigue hablando de la misma cosa, la
  cámara se mueve por su sitio. Cuando la voz pasa a otra cosa, se pasa a otro sitio.
- **Una escena es un sitio con su cámara.** Dentro de una escena no hay cortes: la cámara va de un detalle al
  siguiente siguiendo la voz, aunque eso dure 15 segundos.
- **Una fila por frase:** lo que se ve de su primera palabra a la última (qué hace la cosa grande todo el rato), la
  palabra donde pasa lo más fuerte, adónde va la cámara y cómo se pasa a la siguiente (sigue, o cambio en tal palabra).
- Leyendo solo la columna de lo que se ve, alguien debería poder contar el vídeo.

**Lo que se ve:**
1. Se ve exactamente lo que nombra la frase. Dice "cortas la cebolla": un cuchillo corta una cebolla.
2. Idea nueva, imagen nueva: llega algo, algo se transforma o se cambia de sitio. Nunca la misma imagen para tres ideas.
3. Cada idea es una escena entera y grande, no un fondo con iconos o dibujitos pegados encima.
4. Cada imagen se entiende sin saber nada. Si para entenderla hace falta algo que el vídeo no cuenta, es la imagen
   equivocada: se enseña lo que hace la cosa, no a qué se parece su nombre.
5. Con color, del estilo del vídeo. Si la cosa es gris, lo de alrededor pone el color. Cada cosa con su color de
   verdad (un edificio no es del color principal del estilo), y que un mismo color no lo llene todo.
6. **De día o de noche, según el sitio.** Lo que pasa al aire libre y de día va con su cielo (`e.cielo`): claro si
   hace bueno, nublado si hay tormenta o tifón. El fondo oscuro, para lo de noche o lo que no tiene sitio.

**Los cambios de escena:**
1. **Mismo sitio o misma cosa: no se corta, se mueve la cámara** (se acerca, se aleja, gira, baja con lo que cae).
   Un corte entre dos encuadres del mismo sitio se ve como un salto torpe.
2. **Se cambia solo para ir a otro sitio, en la palabra que lo trae** (puede ser en mitad de una frase).
3. **Otro momento de la misma cosa no es otro sitio.** Si la voz cuenta cómo era antes, la cosa cambia delante de la
   cámara (encoge, cambia de color, vuelve atrás). Si la voz no deja pausa, la imagen tampoco corta.
4. **Antes de un cambio, lo que pasaba ha terminado** y la imagen reposa un instante (0,15 a 0,3 s). Nada se corta a
   medio caer o a medio moverse la cámara. Si no da tiempo, la acción empieza antes, se acorta o el cambio va en una
   palabra más tarde.
5. **Una escena dura al menos 1,5 s** y su acción empieza y acaba dentro de ella.
6. **Lo que nombra la voz se ve entero y casi quieto al menos medio segundo.** En una lista, cada cosa llega, se para
   y se queda junto a las anteriores.
7. **El primer fotograma de cada escena ya enseña lo que es.**
8. **Lo que brilla, late o cae no cruza un cambio de escena:** acaba antes.

## Paso 5 · El gancho, primero y por duplicado

El gancho de palabras ya está elegido (paso 2). Ahora se elige cómo se ve el primer segundo. Hay un segundo para que
alguien no pase de largo, así que se hacen dos formas y se eligen con los vídeos delante.

1. **Dos ideas de primer segundo**, una línea cada una: qué se ve del fotograma 0 al segundo 1. En ese segundo pasa
   algo grande que llena la pantalla: la cámara vuela, algo se llena, choca, explota o se destapa. Si una línea dice
   "imagen quieta", "un número que sube" o "la cámara se acerca despacio", cambia la idea antes de dibujarla.
   - Si el tema es una pregunta, se ve la pregunta pasando, exagerada.
   - Si la sorpresa se puede comprobar, se comprueba ya, como una acción.
   - El gancho puede ser más exagerado que el resto o pasar en otro sitio, si luego enlaza.
   - Nada que parpadee o cambie de color a golpes: parece un error.
2. Haz `video/comun.js` y las escenas del gancho con la primera idea. La segunda va en `video/alternativas/`, con el
   número de la escena a la que sustituye (`alternativas/01-tunel.js` en lugar de `escenas/01-fiesta.js`).
3. Revísalas (paso 7) hasta que estén al nivel del gancho del ejemplo.
4. `node fabrica.mjs render <video> --borrador --hasta <fin del gancho + 1>` hace `revisar/borrador.mp4`; con
   `--alternativa 01-tunel`, `revisar/borrador-01-tunel.mp4`.
5. Enséñale al creador los dos vídeos y el guion entero, en un mensaje corto, y pregúntale cuál con botones
   (`AskUserQuestion`: «Gancho A» · «Gancho B» · «Ninguno, rehazlos», cada uno con su idea del primer segundo). La elegida se
   queda en `video/escenas/`; la otra se borra. Si no le convence ninguna, se rehacen juntas palabras e imagen.

## Paso 6 · Dibujar el resto

Una escena detrás de otra: se hace, se mira, se arregla y solo entonces se empieza la siguiente. Cómo se dibuja, en
`guia/dibujo.md`. Lo que no puede faltar:
- **Grande:** la cosa principal ocupa media pantalla o más.
- **En el estilo del vídeo:** siempre con las funciones del estilo (`e.pieza`, `e.objeto`...) y sus colores por su
  nombre. Así el vídeo cambia de estilo entero con una sola palabra.
- **Moviéndose todo el tiempo**, y siempre porque lo dice la voz.

## Paso 7 · Revisar en movimiento (lo que más importa)

- **Cada cambio, se mira:** `node fabrica.mjs mirar <video> frase 5`, `... palabra sal`, `... cambio 2`,
  `... 24-27 --fps 10`. Tarda segundos. Abre siempre la imagen. Lo que no has mirado, no está revisado.
- **Al acabar cada escena y al final:** `node fabrica.mjs repaso <video>`. Mira enteras `revisar/frases.jpg` y
  `revisar/cambios.jpg` y lee los avisos (cambios con algo aún moviéndose, escenas que se parecen, escenas demasiado
  cortas, segundos casi quietos, subtítulos que no se leen, huecos sin sonido). Son sitios donde mirar, no notas.
- **Lo que suele fallar, búscalo:**
  - una cosa que no parece lo que es (le falta una pieza, o el color engaña);
  - algo que salta de un fotograma al siguiente (al empezar o acabar un movimiento, al cambiar de escena);
  - algo importante cortado por el borde en su momento;
  - más de un segundo sin que cambie nada (salvo el respiro del final);
  - rayos o estelas tan largos que parecen láseres;
  - algo grande debajo de los subtítulos (la franja de y 330 a 510);
  - una escena vacía o gris, como una pared;
  - algo que aparece de golpe con otro aspecto (que llegue entero, con `e.objeto` y su opacidad);
  - un brillo o latido que sigue cuando cambia la escena;
  - texto que dura menos de medio segundo o que no se lee en un móvil;
  - manos con un número de dedos distinto de cinco.
- **Una pasada como alguien con prisa:** ¿en qué segundo me iría? Ahí falta algo que pase con la voz.
- **Antes de enseñarlo, cuatro preguntas** para que entretenga más:
  - ¿El final enlaza con el principio, para que se vea dos veces sin notarlo?
  - ¿Hay un segundo "¡anda!" a mitad del vídeo, justo cuando la gente empieza a irse?
  - ¿Alguna parte parece una clase (una cosa cortada por la mitad con rótulos)? Que pase algo en su lugar.
  - ¿Lo que se dice se comprueba en la imagen?

## Paso 8 · El sonido

Si el creador quiere efectos (se pregunta una vez y se apunta en `preferencias.md`): lee `guia/sonido.md`, escribe
`efectos.js` y lanza `node fabrica.mjs efectos <video>`.
- Cada sonido va en lo que se mueve, en su fotograma.
- Nunca más de 2 s sin ningún efecto, y ninguno justo en un cambio de escena.
- Los momentos se sacan de las escenas (que los exportan), no se copian a mano.

## Paso 9 · El render y la entrega

1. `node fabrica.mjs render <video>` deja en `salida/<video>/` el vídeo, `portada.jpg` y `texto-del-post.txt` (sale
   de `pie.txt`: dos líneas para el post, la primera engancha).
2. Mira los saltos que avise con `mirar`: o son un golpe buscado o se arreglan.
3. Mira la portada.
4. Al creador: el vídeo y una o dos líneas. Nada de cómo se hace por dentro.

En `notas.md` del vídeo, en pocas líneas: qué se hizo, qué se arregló y por qué.
