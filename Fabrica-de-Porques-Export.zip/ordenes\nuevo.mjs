// nuevo: la carpeta de un vídeo, con lo justo para empezar.
import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { CASA, config, hoy, json, para, sinTildes } from "../nucleo/base.mjs";

export const ayuda = `
node fabrica.mjs nuevo "<la idea>" [--nombre corto] [--estilo pegatina]

Crea videos/<fecha>-<nombre>/ y dice su ruta. Dentro:
  idea.md            la idea, lo que cuenta en una frase y cada dato con su fuente
  guion.json         las frases (METODO.md, paso 2)
  plan.md            frase a frase, lo que se ve (paso 4)
  video/comun.js     lo que comparten las escenas (la misma cosa, el mismo sitio)
  video/escenas/     una escena por archivo; empieza por 01-gancho.js
  efectos.js         los efectos de sonido, si el vídeo los lleva
  notas.md           lo que se hizo y por qué
--estilo: el estilo de este vídeo (si no, el de fabrica.config.json).
`;

// Crea la carpeta y su esqueleto. Devuelve la ruta. Lo usa también la orden «guion».
export function creaVideo(idea, { nombre, estilo } = {}) {
  const texto = String(idea || "").trim();
  if (!texto) para('Falta la idea: node fabrica.mjs nuevo "por qué el cielo es azul"');
  const corto = sinTildes(String(nombre || texto)).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 42) || "video";
  const dir = join(CASA, "videos", `${hoy()}-${corto}`);
  if (existsSync(dir)) para(`Ya existe ${dir}. Si es otro vídeo, ponle otro --nombre.`);
  mkdirSync(join(dir, "video", "escenas"), { recursive: true });
  const cfg = config();
  const est = estilo ? String(estilo) : cfg.estilo;

  writeFileSync(join(dir, "idea.md"), `# ${texto}\n\nPedido el ${hoy()}.\n\n## En una frase\n\n## Lo sorprendente\n\n## La regla que rompe\n\n## El mecanismo, paso a paso\n\n## Las cifras\n\n## Comparaciones con cosas de casa\n\n## Fuentes\n`);
  json.escribe(join(dir, "guion.json"), {
    titulo: texto, idioma: cfg.voz?.idioma || "es", estilo: est, subtitulos: "arriba",
    frases: [{ dice: "", resalta: "", gancho: true }, { dice: "", resalta: "" }],
  });
  writeFileSync(join(dir, "plan.md"), `# Plan: ${texto}\n\n## Los sitios\n\n## Frase a frase\n\n| # | Frase (palabra que resalta) | Lo que se ve, de la primera palabra a la última | Palabra del momento fuerte | Cámara | Paso a la siguiente |\n|---|---|---|---|---|---|\n`);
  writeFileSync(join(dir, "video", "comun.js"), `// Lo que comparten las escenas de este vídeo: la misma cosa, el mismo sitio, la misma cámara. Si algo sale en más
// de una escena, se dibuja aquí una vez, para que sea siempre igual y del mismo tamaño.
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
`);
  writeFileSync(join(dir, "video", "escenas", "01-gancho.js"), `// «(la primera frase)»
// Lo que se ve, de la primera palabra a la última (lo mismo que dice plan.md).
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";

export const empieza = 0; // la primera escena, en 0; las demás, en la palabra que trae lo nuevo: "palabra" o "palabra#2"
export const paso = "corte";

export function pinta(c, t) {
  // t es el segundo del vídeo. Todo sale de t: nada se guarda de un fotograma al siguiente.
  e.fondo(c);
}
`);
  writeFileSync(join(dir, "efectos.js"), `// Los efectos de sonido: cada uno en lo que se mueve, en su fotograma (guia/sonido.md).
import { voz } from "#voz";

const lista = [];
const suena = (sonido, t, op = {}) => lista.push({ sonido, t, ...op });

export default lista;
`);
  writeFileSync(join(dir, "notas.md"), `# ${texto}\n\nPedido el ${hoy()}. Estilo: ${est}.\n`);
  return dir;
}

export async function corre({ libres, marcas }) {
  const idea = libres.join(" ").trim();
  const dir = creaVideo(idea, { nombre: marcas.nombre, estilo: marcas.estilo });
  console.log(dir);
}
