﻿// guion: pasa un guion.md (el de Fábrica de Guiones) a guion.json y deja el vídeo listo para la voz.
import { copyFileSync, existsSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { basename, dirname, join, resolve } from "node:path";
import { CASA, carpetaVideo, config, json, para } from "../nucleo/base.mjs";
import { creaVideo } from "./nuevo.mjs";

export const ayuda = `
node fabrica.mjs guion <video|guion.md> [--nombre corto] [--idioma es|es-419|en] [--gancho 2] [--estilo casa]

Convierte el guion.md de un vídeo en su guion.json:
  - lee la tabla de «## Frase a frase» (Frase · Resalta · Lo que se ve)
  - las primeras filas son el gancho (2 por defecto; --gancho 3 si lleva tres)
  - conserva el estilo, los subtítulos y la voz que ya tuviera el vídeo
  - si plan.md está vacío, copia ahí las frases y lo que se ve

Con un .md de otra carpeta (por ejemplo, uno de Fábrica de Guiones):
  crea el vídeo, copia guion.md, pie.txt e idea.md, y lo convierte.
  node fabrica.mjs guion "..\\fabrica-de-guiones\\guiones\\palomitas\\guion.md" --nombre palomitas

El guion se escribe en guion.md, dentro de la carpeta del vídeo; no se escribe guion.json a mano.
Después: node fabrica.mjs voz <video>
`;

const leeMd = (ruta) => readFileSync(ruta, "utf8").replace(/^\uFEFF/, "");
const normal = (s) => String(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();

// Quita el markdown de una celda, pero deja el texto tal y como se lee.
function limpia(s) {
  return String(s || "")
    .replace(/<br\s*\/?>/gi, " ")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/(\*\*|__)(.*?)\1/g, "$2")
    .replace(/(\*|_)(.*?)\1/g, "$2")
    .replace(/`([^`]*)`/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
}

// Una fila de tabla, sin romper los «\|» que haya dentro de una celda.
const celdas = (linea) => String(linea).trim().replace(/^\|/, "").replace(/\|$/, "")
  .split(/(?<!\\)\|/).map((c) => c.replace(/\\\|/g, "|").trim());

const esSeparador = (linea) => {
  const c = celdas(linea);
  return c.length > 0 && c.every((x) => /^:?-{3,}:?$/.test(x));
};

function tituloDe(md) {
  for (const linea of md.split(/\r?\n/)) {
    const m = /^#\s+(.+?)\s*$/.exec(linea);
    if (m) return limpia(m[1]);
  }
  return "";
}

// El texto de una sección (## Los sitios, ## Frase a frase...), sin su encabezado.
function seccion(md, nombre) {
  const lineas = String(md).split(/\r?\n/);
  const fuera = [];
  let dentro = false, nivel = 0;
  for (const linea of lineas) {
    const m = /^(#{1,6})\s+(.*?)\s*$/.exec(linea);
    if (m) {
      if (dentro && m[1].length <= nivel) break;
      if (!dentro && normal(m[2]) === normal(nombre)) { dentro = true; nivel = m[1].length; continue; }
    }
    if (dentro) fuera.push(linea);
  }
  return fuera.join("\n").trim();
}

function frasesDe(md) {
  const sec = seccion(md, "Frase a frase");
  if (!sec) para("guion.md no tiene la sección «## Frase a frase».");
  const lineas = sec.split(/\r?\n/).filter((l) => /^\s*\|/.test(l));
  if (lineas.length < 2) {
    para("La tabla de «## Frase a frase» está vacía. Cada fila: | 1 | La frase. | palabra | Lo que se ve. |");
  }

  const hayCabecera = lineas.length > 1 && esSeparador(lineas[1]);
  const cabecera = hayCabecera ? celdas(lineas[0]).map(normal) : [];
  const datos = (hayCabecera ? lineas.slice(1) : lineas).filter((l) => !esSeparador(l));
  if (!datos.length) {
    para("La tabla de «## Frase a frase» no tiene filas. Cada fila: | 1 | La frase. | palabra | Lo que se ve. |");
  }

  let iFrase = cabecera.findIndex((c) => /^(frase|texto)\b/.test(c));
  let iResalta = cabecera.findIndex((c) => /resalta|palabra/.test(c));
  let iVe = cabecera.findIndex((c) => /\bse ve\b/.test(c) || /^lo que/.test(c));
  if (iFrase < 0) {
    const primera = celdas(datos[0]);
    iFrase = /^\d+$/.test(primera[0]) ? 1 : 0;
  }
  if (iResalta < 0 && iVe !== iFrase + 1) iResalta = iFrase + 1;
  if (iVe < 0) iVe = iResalta >= 0 ? iResalta + 1 : iFrase + 1;

  const frases = [];
  for (const linea of datos) {
    const c = celdas(linea);
    const dice = limpia(c[iFrase]);
    if (!dice) continue;
    frases.push({ dice, resalta: limpia(c[iResalta] || ""), ve: limpia(c[iVe] || "") });
  }
  if (!frases.length) para("No he encontrado ninguna frase con texto en la tabla de guion.md.");
  return frases;
}

const celda = (s) => String(s || "").replace(/\|/g, "\\|").replace(/\r?\n/g, " ").trim();

// Filas de verdad en la tabla de plan.md (sin contar cabecera ni separador).
function filasPlan(texto) {
  const lineas = String(texto).split(/\r?\n/).filter((l) => /^\s*\|/.test(l));
  const datos = lineas.filter((l) => !esSeparador(l));
  return Math.max(0, datos.length - 1);
}

function escribePlan(dir, titulo, sitios, frases) {
  const ruta = join(dir, "plan.md");
  const actual = existsSync(ruta) ? leeMd(ruta) : "";
  if (filasPlan(actual) > 0) return false;

  const tabla = [
    "## Frase a frase",
    "",
    "| # | Frase (resalta) | Lo que se ve, de la primera palabra a la última | Momento fuerte | Cámara | Paso |",
    "|---|---|---|---|---|---|",
    ...frases.map((f, i) => `| ${i + 1} | ${celda(f.dice)}${f.resalta ? ` (${celda(f.resalta)})` : ""} | ${celda(f.ve)} | | | |`),
  ].join("\n");

  const i = actual.search(/^##[ \t]+Frase a frase[ \t]*$/im);
  let antes = i >= 0
    ? actual.slice(0, i)
    : (actual.trim() ? `${actual.trimEnd()}\n\n` : `# Plan: ${titulo}\n\n## Los sitios\n\n${sitios || ""}\n\n`);
  if (!/^#[ \t]+/m.test(antes)) antes = `# Plan: ${titulo}\n\n${antes}`;
  if (!/^##[ \t]+Los sitios[ \t]*$/im.test(antes)) {
    antes = antes.replace(/^(#[ \t]+.*)$/m, `$1\n\n## Los sitios\n\n${sitios || ""}`);
  } else if (!seccion(antes, "Los sitios") && sitios) {
    antes = antes.replace(/(^##[ \t]+Los sitios[ \t]*$)([\s\S]*?)(?=^##[ \t]+|$)/im, `$1\n\n${sitios}\n\n`);
  }
  writeFileSync(ruta, `${antes.replace(/\s+$/, "")}\n\n${tabla}\n`);
  return true;
}

function escribeGuion(dir, md, marcas, { origen } = {}) {
  const frases = frasesDe(md);
  const rutaJson = join(dir, "guion.json");
  const previo = existsSync(rutaJson) ? json.lee(rutaJson) : null;

  const brutoGancho = marcas.gancho;
  let nGancho = brutoGancho === undefined || brutoGancho === true ? 2 : Number(brutoGancho);
  if (!Number.isInteger(nGancho) || nGancho < 0) para("--gancho quiere un número entero (por defecto 2).");
  nGancho = Math.min(nGancho, frases.length);

  const titulo = tituloDe(md) || previo?.titulo || basename(dir);
  const idioma = String(
    (typeof marcas.idioma === "string" ? marcas.idioma : "") || previo?.idioma || config().voz?.idioma || "es",
  );
  const estilo = String(
    (typeof marcas.estilo === "string" ? marcas.estilo : "") || previo?.estilo || config().estilo,
  );

  const anteriores = new Map((previo?.frases || []).map((f) => [normal(f.dice), f]));
  const salida = {
    ...(previo || {}),
    titulo,
    idioma,
    estilo,
    subtitulos: previo?.subtitulos || "arriba",
    frases: frases.map((f, i) => {
      // Si la frase ya estaba, se queda con lo suyo (por ejemplo, «pronuncia»).
      const frase = { ...(anteriores.get(normal(f.dice)) || {}), dice: f.dice, resalta: f.resalta || "" };
      if (i < nGancho) frase.gancho = true;
      else delete frase.gancho;
      return frase;
    }),
  };
  json.escribe(rutaJson, salida);

  const sitios = seccion(md, "Los sitios");
  const planHecho = escribePlan(dir, titulo, sitios, frases);
  const pie = existsSync(join(dir, "pie.txt"));

  console.log(`guion: ${rutaJson}`);
  console.log(`  ${frases.length} frases · gancho: ${nGancho}${nGancho ? ` («${frases[0].dice}»${nGancho > 1 ? "…" : ""})` : ""}`);
  console.log(`  idioma: ${idioma} · estilo: ${estilo}`);
  if (origen) console.log(`  guion.md: ${join(dir, "guion.md")} (copiado de ${origen})`);
  else console.log(`  guion.md: ${join(dir, "guion.md")}`);
  if (planHecho) console.log(`  plan.md: ${join(dir, "plan.md")} (frases y lo que se ve copiados)`);
  else console.log("  plan.md: ya tenía filas; no lo he tocado.");
  if (!pie) console.log("  aviso: falta pie.txt (el texto del post, dos líneas).");

  for (const f of salida.frases) {
    if (f.resalta && !normal(f.dice).includes(normal(f.resalta))) {
      console.log(`  aviso: «${f.resalta}» no está en la frase «${f.dice}».`);
    }
  }
  console.log(`\nSiguiente: node fabrica.mjs voz "${dir}"`);
}

function archivoMd(entrada) {
  const nombre = String(entrada);
  if (!/\.md$/i.test(nombre)) return null;
  for (const ruta of [resolve(nombre), join(CASA, nombre)]) {
    if (existsSync(ruta) && statSync(ruta).isFile()) return ruta;
  }
  para(`No encuentro el guion «${entrada}».`);
}

export async function corre({ libres, marcas }) {
  const entrada = libres[0];
  if (!entrada) para("Falta el vídeo o el guion.md: node fabrica.mjs guion <video|guion.md>");

  if (/\.md$/i.test(String(entrada))) {
    const origen = archivoMd(entrada);
    const md = leeMd(origen);
    const titulo = tituloDe(md) || basename(dirname(origen));
    const fuente = dirname(origen);
    const nombre = (typeof marcas.nombre === "string" ? marcas.nombre : "") || basename(fuente) || basename(origen, ".md");
    const estilo = typeof marcas.estilo === "string" ? marcas.estilo : undefined;
    const dir = creaVideo(titulo, { nombre, estilo });
    copyFileSync(origen, join(dir, "guion.md"));
    for (const f of ["pie.txt", "idea.md"]) {
      if (existsSync(join(fuente, f))) copyFileSync(join(fuente, f), join(dir, f));
    }
    return escribeGuion(dir, md, marcas, { origen });
  }

  const dir = carpetaVideo(entrada);
  const ruta = join(dir, "guion.md");
  if (!existsSync(ruta)) {
    para(`Falta ${ruta}. Escribe ahí el guion (METODO.md, paso 2) y vuelve a lanzar: node fabrica.mjs guion "${dir}"`);
  }
  return escribeGuion(dir, leeMd(ruta), marcas);
}
