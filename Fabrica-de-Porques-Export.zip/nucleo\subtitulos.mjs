// Los subtítulos, dibujados encima de cada fotograma con el aspecto del estilo: golpes cortos de pocas palabras, cada
// palabra salta a su sitio cuando se dice, las ya dichas se apagan un poco y la palabra que resalta la frase lleva su
// marca (rotulador, subrayado de tiza, caja de neón o pastilla, según el estilo). Las palabras no se mueven después de
// aparecer: cada una tiene su sitio desde que sale su golpe.
import { estilo } from "./estilo-vivo.js";
import { rango, rebota, llega } from "../pinceles/tiempo.js";
import { rectRedondo } from "../pinceles/formas.js";
import { alfa, luminancia } from "../pinceles/color.js";

export const ZONA = { izquierda: 150, ancho: 780, arriba: 330, abajo: 1170 };
const ADELANTO = 0.06; // la palabra sale un poco antes de oírse, para que dé tiempo a leerla

// Golpes de hasta 4 palabras y 22 letras, sin mezclar frases.
export function golpes(palabras, dura) {
  const lista = [];
  for (const w of palabras) {
    const g = lista[lista.length - 1];
    const letras = g ? g.palabras.reduce((s, p) => s + p.dice.length + 1, 0) + w.dice.length : 0;
    const corta = g && /[.,;:!?…]$/.test(g.palabras[g.palabras.length - 1].dice) && g.palabras.length >= 2;
    if (!g || g.frase !== w.frase || g.palabras.length >= 4 || letras > 22 || corta) lista.push({ frase: w.frase, palabras: [w] });
    else g.palabras.push(w);
  }
  lista.forEach((g, i) => {
    g.desde = Math.max(0, g.palabras[0].desde - ADELANTO);
    const sig = lista[i + 1];
    g.hasta = sig ? Math.min(sig.palabras[0].desde - ADELANTO, g.palabras[g.palabras.length - 1].hasta + 0.7) : dura;
  });
  return lista;
}

function coloca(c, g, modo, S) {
  if (g.sitios) return g.sitios;
  c.font = `${S.tam}px "${S.letra}"`;
  const anchos = g.palabras.map((w) => c.measureText(w.dice).width), hueco = S.tam * 0.27;
  const lineas = [[]];
  let usado = 0;
  anchos.forEach((a, i) => {
    const l = lineas[lineas.length - 1], extra = (l.length ? hueco : 0) + a;
    if (l.length && usado + extra > ZONA.ancho) { lineas.push([i]); usado = a; }
    else { l.push(i); usado += extra; }
  });
  const y0 = modo === "abajo" ? ZONA.abajo : ZONA.arriba, sitios = [];
  lineas.forEach((l, j) => {
    const total = l.reduce((s, i, k) => s + anchos[i] + (k ? hueco : 0), 0);
    let x = ZONA.izquierda + (ZONA.ancho - total) / 2;
    for (const i of l) { sitios[i] = { x, w: anchos[i], y: y0 + j * S.linea + S.linea / 2 }; x += anchos[i] + hueco; }
  });
  return (g.sitios = sitios);
}

// La marca de la palabra que resalta. u: de 0 a 1, cómo de hecha está.
function marca(c, s, u, S) {
  const pad = S.tam * 0.16, alto = S.tam * 1.08;
  const x = s.x - pad, y = s.y - alto / 2, w = s.w + pad * 2;
  c.save();
  if (S.resalte === "rotulador") {
    // un trazo de rotulador que se pinta de izquierda a derecha, un poco torcido
    c.translate(x, s.y); c.rotate(-0.025);
    c.fillStyle = alfa(S.colorResalte, 0.92);
    rectRedondo(c, 0, -alto * 0.42, w * llega(u), alto * 0.84, 10); c.fill();
  } else if (S.resalte === "subraya") {
    c.strokeStyle = S.colorResalte; c.lineWidth = 7; c.lineCap = "round";
    c.beginPath();
    const n = 24, yb = s.y + S.tam * 0.52;
    for (let i = 0; i <= n * llega(u); i++) { const px = x + (w * i) / n, py = yb + Math.sin(i * 0.9) * 3; i ? c.lineTo(px, py) : c.moveTo(px, py); }
    c.stroke();
  } else if (S.resalte === "neon") {
    const k = 0.85 + 0.15 * rebota(u);
    c.translate(s.x + s.w / 2, s.y); c.scale(k, k);
    c.globalAlpha = Math.min(1, u * 2);
    c.shadowColor = S.colorResalte; c.shadowBlur = 26; c.strokeStyle = S.colorResalte; c.lineWidth = 6;
    rectRedondo(c, -w / 2, -alto / 2, w, alto, 18); c.stroke();
  } else { // pastilla
    const k = 0.7 + 0.3 * rebota(u);
    c.translate(s.x + s.w / 2, s.y); c.scale(k, k);
    c.globalAlpha = Math.min(1, u * 2);
    c.fillStyle = S.colorResalte; rectRedondo(c, -w / 2, -alto / 2, w, alto, alto / 2); c.fill();
  }
  c.restore();
}

// Si lo que hay detrás del texto es claro (un cielo de día, una pantalla blanca), una franja oscura y suave debajo:
// más opaca cuanto más claro es el fondo, así no aparece de golpe. Sobre fondos oscuros no se dibuja.
function velo(c, sitios, S, dt) {
  if (luminancia(S.color) < 0.5) return; // letra oscura: ya se lee sobre lo claro
  const x0 = Math.min(...sitios.map((s) => s.x)) - S.tam * 0.55, x1 = Math.max(...sitios.map((s) => s.x + s.w)) + S.tam * 0.55;
  const y0 = Math.min(...sitios.map((s) => s.y)) - S.tam * 0.75, y1 = Math.max(...sitios.map((s) => s.y)) + S.tam * 0.75;
  const ancho = Math.max(1, Math.round(x1 - x0)), alto = Math.max(1, Math.round(y1 - y0));
  const d = c.getImageData(Math.round(x0), Math.round(y0), ancho, alto).data;
  let suma = 0, n = 0;
  for (let i = 0; i < d.length; i += 4 * 23) { suma += 0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2]; n++; }
  const luz = suma / n / 255, k = Math.max(0, Math.min(1, (luz - 0.42) / 0.25)) * Math.min(1, dt / 0.15);
  if (k <= 0.01) return;
  c.save();
  c.globalAlpha = 0.5 * k; c.fillStyle = S.velo || "#000000";
  rectRedondo(c, x0, y0, x1 - x0, y1 - y0, Math.min(40, alto / 2)); c.fill();
  c.restore();
}

export function pintaSubtitulos(c, t, lista, modo = "arriba") {
  if (modo === "no") return;
  const g = lista.find((x) => t >= x.desde && t < x.hasta);
  if (!g) return;
  const S = estilo.subtitulos, sitios = coloca(c, g, modo, S);
  c.save();
  c.setTransform(1, 0, 0, 1, 0, 0);
  c.globalAlpha = 1; c.globalCompositeOperation = "source-over"; c.filter = "none"; c.shadowBlur = 0;
  c.textBaseline = "middle"; c.textAlign = "left"; c.lineJoin = "round";
  velo(c, sitios, S, t - g.desde);
  g.palabras.forEach((w, i) => {
    const sale = w.desde - ADELANTO, u = rango(t, sale, sale + 0.14);
    if (u <= 0) return;
    const s = sitios[i], sig = g.palabras[i + 1];
    const dicha = !w.resaltada && sig && t >= sig.desde - ADELANTO;
    if (w.resaltada) marca(c, s, rango(t, sale + 0.04, sale + 0.26), S);
    const k = 0.72 + 0.28 * rebota(u);
    c.save();
    c.translate(s.x + s.w / 2, s.y + (1 - u) * 18); c.scale(k, k);
    c.globalAlpha = Math.min(1, u * 1.6);
    c.font = `${S.tam}px "${S.letra}"`;
    let color = dicha ? S.dicho : S.color;
    if (w.resaltada && (S.resalte === "subraya")) color = S.colorResalte;
    if (w.resaltada && S.resalte === "rotulador" && S.textoResalte) color = S.textoResalte; // la letra sobre el rotulador
    if (w.resaltada && (S.resalte === "neon" || S.resalte === "pastilla")) color = "#ffffff";
    const sobreMarca = w.resaltada && (S.resalte === "pastilla" || (S.resalte === "rotulador" && S.textoResalte));
    if (S.contorno && !sobreMarca) {
      c.strokeStyle = S.contorno; c.lineWidth = S.grosorContorno; c.strokeText(w.dice, -s.w / 2, 0);
    }
    if (S.brillo && !dicha) { c.shadowColor = S.brillo; c.shadowBlur = 18; }
    c.fillStyle = color; c.fillText(w.dice, -s.w / 2, 0);
    c.restore();
  });
  c.restore();
}
