// «Lo que suena no es la cáscara: es el vapor saliendo de golpe.»
// El grano enorme, de cerca, con su cáscara rajada. En «cáscara», una cruz roja sobre la raja. En «vapor», la cruz se
// va y por la raja sale de golpe un chorro de vapor con sus ondas de sonido.
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
import { bolitaVapor, grano } from "../comun.js";

export const empieza = "lo@10";
const F = voz.frase(10), CASCARA = F.en("cascara"), VAPOR = F.en("vapor");
export const CHORRO = VAPOR - 0.05;
const X = 540, Y = 1200, S = 880, RX = X + 20, RY = Y - S * 0.45;
const FIN = voz.frase(11).desde;

export function pinta(c, t) {
  e.fondo(c, { disco: [540, 1170, 480] });
  // la cámara se acerca despacio a la raja mientras la voz llega a «cáscara»
  const z = p.entre(t, F.desde, CASCARA, 0.9, 1.06);
  c.save(); c.translate(RX, RY); c.scale(z, z); c.translate(-RX, -RY);
  e.objeto(c, (c) => grano(c, X, Y, S, { rot: 0.04 * p.ondula(t * 1.5, 2) }));
  const raja = [[RX - 80, RY + 20], [RX - 25, RY - 18], [RX + 10, RY + 28], [RX + 70, RY - 10]];
  e.trazo(c, (g) => p.linea(g, raja, false), { grosor: 12 });
  c.restore();
  // la cruz roja: no es eso
  const cruz = p.rebota(p.rango(t, CASCARA - 0.05, CASCARA + 0.25)) * (1 - p.rango(t, VAPOR - 0.25, VAPOR));
  if (cruz > 0.01) {
    const r = 120 * cruz, cy = RY - 10;
    e.trazo(c, (g) => { g.beginPath(); g.moveTo(RX - r, cy - r); g.lineTo(RX + r, cy + r); g.moveTo(RX + r, cy - r); g.lineTo(RX - r, cy + r); }, { papel: "mal", grosor: 30 });
  }
  // el chorro de vapor y su sonido
  for (let i = 0; i < 14; i++) {
    const u = (t - CHORRO - i * 0.05) / 0.9;
    if (u <= 0 || u >= 1) continue;
    bolitaVapor(c, RX + p.ondula(i * 1.7, 4) * 90 * u, RY - 30 - 560 * p.llega(u), 20 + 55 * u, 1 - u * u);
  }
  const suena = p.rango(t, CHORRO, CHORRO + 0.2) * (1 - p.rango(t, FIN - 0.5, FIN - 0.15));
  if (suena > 0) {
    c.save(); c.globalAlpha *= suena;
    e.ondas(c, RX, RY - 60, t, { r0: 200, paso: 80, ang: -Math.PI / 2 - 1.0, abre: 1.0, grosor: 16 });
    e.ondas(c, RX, RY - 60, t + 0.4, { r0: 200, paso: 80, ang: -Math.PI / 2 + 1.0, abre: 1.0, grosor: 16 });
    c.restore();
  }
}
