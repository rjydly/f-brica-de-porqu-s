// La pista de efectos: cada sonido de sonidos/ colocado en su segundo, con su nivel medido frente a la voz que suena
// alrededor (así nunca la tapa), y los avisos de huecos y de sonidos que caen en un cambio de escena.
import { existsSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { CASA, MUESTREO as SR, muestras, para } from "./base.mjs";

export const SONIDOS = join(CASA, "sonidos");

export function biblioteca() {
  const b = {};
  for (const f of readdirSync(SONIDOS)) { const m = /^(.+)\.(wav|mp3|ogg|flac)$/.exec(f); if (m) b[m[1]] = join(SONIDOS, f); }
  return b;
}

// Nivel (dB) de la ventana más fuerte entre a y b segundos, y dónde está.
function pico(x, a, b, ventana = 0.02) {
  const n = Math.round(ventana * SR), i0 = Math.max(0, Math.floor(a * SR)), i1 = Math.min(x.length - n, Math.floor(b * SR));
  let mejor = 0, donde = i0;
  for (let i = i0; i <= i1; i += n >> 1) {
    let s = 0;
    for (let j = i; j < i + n; j++) s += x[j] * x[j];
    if (s > mejor) { mejor = s; donde = i; }
  }
  return { db: 10 * Math.log10(mejor / n + 1e-12), t: donde / SR };
}

// Quita agudos: un filtro de un polo pasado dos veces (ida y vuelta, sin desfase).
function grave(x, hz) {
  const a = Math.exp((-2 * Math.PI * hz) / SR);
  for (const dir of [1, -1]) {
    let y = 0;
    for (let k = 0; k < x.length; k++) { const i = dir > 0 ? k : x.length - 1 - k; y = (1 - a) * x[i] + a * y; x[i] = y; }
  }
}

// efectos: [{ sonido, t, nivel = -11, tono = 1, grave, alReves, apaga, desde = "pico" | "inicio", que }]
//   t        el segundo en que suena lo más fuerte del sonido (con desde: "inicio", en el que empieza)
//   nivel    dB frente a la voz de alrededor: -6 muy fuerte, -11 normal, -16 pequeño
//   tono     más de 1, más agudo y corto; menos de 1, más grave y largo
//   grave    quita los agudos por encima de esos Hz (suena más lejos o más sordo)
//   alReves  el sonido al revés (lo que vuelve atrás o se absorbe)
//   apaga    el segundo en que se corta del todo (si su escena se corta, el sonido con ella)
export function mezcla(efectos, voz) {
  const lib = biblioteca(), guardados = {}, pista = new Float32Array(voz.length), puestos = [];
  const vozTipica = pico(voz, 0, voz.length / SR, 0.25).db - 4;
  for (const ef of [...efectos].sort((a, b) => a.t - b.t)) {
    const e = { nivel: -11, tono: 1, desde: "pico", ...ef };
    if (!lib[e.sonido]) para(`No hay ningún sonido «${e.sonido}». Hay: ${Object.keys(lib).join(", ")}.`);
    const src = guardados[e.sonido] ||= muestras(lib[e.sonido]);
    let n = Math.floor(src.length / e.tono);
    const x = new Float32Array(n);
    for (let i = 0; i < n; i++) { const p = i * e.tono, k = p | 0, f = p - k; x[i] = (src[k] || 0) * (1 - f) + (src[k + 1] || 0) * f; }
    if (e.alReves) x.reverse();
    if (e.grave) grave(x, e.grave);
    const suyo = pico(x, 0, n / SR, 0.01), ancla = e.desde === "inicio" ? 0 : suyo.t;
    const alrededor = pico(voz, e.t - 0.45, e.t + 0.45, 0.05).db, ref = alrededor < -42 ? vozTipica : alrededor;
    const gan = 10 ** ((ref + e.nivel - suyo.db) / 20), ini = Math.round((e.t - ancla) * SR);
    if (e.apaga !== undefined) n = Math.max(0, Math.min(n, Math.round(e.apaga * SR) - ini));
    const cola = e.apaga !== undefined ? 0.06 : Math.min(0.05, n / SR / 4);
    for (let i = 0; i < n; i++) {
      const j = ini + i;
      if (j < 0 || j >= pista.length) continue;
      const desdeIni = i / SR, falta = (n - i) / SR;
      pista[j] += x[i] * gan * Math.min(1, desdeIni / 0.003) * Math.min(1, falta / cola);
    }
    puestos.push({ ...e, empieza: ini / SR, termina: (ini + n) / SR });
  }
  return { pista, puestos };
}

// Tramos de más de `largo` segundos en que no suena ningún efecto.
export function silencios(pista, largo = 2) {
  const n = Math.round(0.05 * SR), tramos = [];
  let desde = null;
  for (let i = 0; i + n <= pista.length; i += n) {
    let s = 0;
    for (let j = i; j < i + n; j++) s += pista[j] * pista[j];
    const suena = 10 * Math.log10(s / n + 1e-12) > -50, t = i / SR;
    if (!suena && desde === null) desde = t;
    if (suena && desde !== null) { if (t - desde > largo) tramos.push([desde, t]); desde = null; }
  }
  if (desde !== null && pista.length / SR - desde > largo) tramos.push([desde, pista.length / SR]);
  return tramos;
}

export const tieneEfectos = (dir) => existsSync(join(dir, "efectos.js"));

export async function leeEfectos(dir, voz) {
  const { pathToFileURL } = await import("node:url");
  let lista = (await import(pathToFileURL(join(dir, "efectos.js")).href + "?v=" + Date.now())).default;
  if (typeof lista === "function") lista = lista(voz);
  if (!Array.isArray(lista)) para("efectos.js tiene que exportar por defecto una lista de efectos (o una función que la devuelva).");
  lista.forEach((e, i) => { if (!Number.isFinite(e.t)) para(`El efecto ${i + 1} («${e.sonido}») no tiene un segundo t válido.`); });
  return lista;
}
