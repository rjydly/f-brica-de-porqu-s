// «Envíaselo a quien siempre quema las palomitas.»
// Un cuenco lleno de palomitas. En «quema» cae encima una palomita negra, quemada, que bota y humea.
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
import { cuenco, humo, palomita } from "../comun.js";

export const empieza = "enviaselo";
const F = voz.frase(12), QUEMA = F.en("quema");
export const CAE = QUEMA + 0.12;

export function pinta(c, t) {
  e.fondo(c, { disco: [540, 1150, 470] });
  cuenco(c, 540, 1250, 700, t);
  const k = p.rango(t, CAE - 0.55, CAE), bote = 110 * Math.sin(Math.PI * p.rango(t, CAE, CAE + 0.4));
  const y = p.mezcla(-200, 990, k * k) - bote;
  humo(c, 560, 900, t, CAE + 0.1, { n: 7, color: "#6d655c" });
  e.objeto(c, (c) => palomita(c, 560, y, 250, { semilla: 30, quemada: 0.85, rot: 0.3 + 2 * k }));
}
