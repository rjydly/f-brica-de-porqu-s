# Fábrica de Porqués

Esta carpeta hace reels explicativos dibujados, en el ordenador de quien la abre, con Claude Code o OpenCode. El
creador da una idea ("hazme un vídeo de por qué las palomitas explotan") y sale el vídeo listo para publicar, con su
portada y el texto del post. Nada se publica solo. El guion se escribe aquí mismo, con el método de Fábrica de
Guiones, y se convierte en vídeo sin abrir otra conversación.

El nivel es el del ejemplo (`ejemplo/`). El aspecto lo pone el estilo elegido (`casa` si no se ha elegido otro).

## Al abrir la carpeta

- **«Configúrame», «empezar», «set me up», o es la primera vez** (no hay `preferencias.md`):
  1. `node fabrica.mjs doctor`, e instala tú lo que falte (`npm install` en esta carpeta, ffmpeg, Node). Si la voz
     local dice que falta el motor ONNX: `node node_modules/onnxruntime-node/script/install`.
  2. **La voz es local** (Kokoro en su ordenador: gratis, sin clave y sin internet). No hay que pegar ninguna clave.
     Solo si pide ElevenLabs: `node fabrica.mjs clave`, que abre una página en su navegador para pegarla.
  3. **Las preguntas, siempre con botones** (la herramienta `AskUserQuestion`), nunca como una lista para que
     conteste escribiendo. Mientras se instala o se pega la clave, ya puedes hacerlas. Son dos tandas:
     - **Primera tanda (una sola llamada, 4 preguntas), si no hay `preferencias.md`:**
       - «¿En qué idioma son tus vídeos?»: Español de España · Español latinoamericano · Inglés.
       - «¿Para quién son?»: Curiosos en general · Jóvenes y adolescentes · Niños y familias · Gente de ciencia y
         tecnología.
       - «¿Cómo quieres cerrarlos?»: «Envíaselo a quien...» (adaptado a cada tema) · «Síguenos para un porqué
         cada día» · Sin frase de cierre.
       - «¿Quieres efectos de sonido?»: Sí (recomendado) · No.
     - **Segunda tanda (una sola llamada, 2 preguntas, las dos opcionales):**
       - «¿Qué estilo de ilustración quieres?»: Casa, el de los vídeos de Un minuto de porqués (recomendado) ·
         Pegatina · Tinta · Medianoche. Pon en la descripción de cada opción cómo es en una línea, y dile que con
         «Otro» puede pedir arcilla de noche, neón, grafito, pizarra, papel, arcilla o describir uno suyo.
       - «¿Qué voz quieres?»: em_alex, español de España, hombre (recomendado, el de Fábrica de Porqués) · ef_dora,
         español, mujer · em_santa, español, hombre más grave. Con «Otro» puede pedir otra voz de Kokoro (las dice
         `node fabrica.mjs voz-id`) o una de ElevenLabs, que entonces sí necesita su clave.
     Pon siempre la opción recomendada la primera. Si en alguna elige «Otro», usa lo que escriba.
  4. Guarda las respuestas de la primera tanda en `preferencias.md` con sus palabras. Del estilo: `node fabrica.mjs
     estilo <nombre>` (si describe uno propio, créalo siguiendo `guia/estilos.md`; si no elige, `casa`).
  5. De la voz: `node fabrica.mjs voz-id <voz>` (la comprueba y deja una muestra para que la oiga). Si quiere español
     de América: `node fabrica.mjs voz-id <voz> --idioma es-419`. Si no elige, em_alex. Si pide ElevenLabs y da un ID:
     `node fabrica.mjs clave` para la clave y `node fabrica.mjs voz-id <id> --motor elevenlabs`.
  6. Dile en una línea que ya puede pedir un vídeo.
- **Cualquier petición de vídeo, reel, guion o ideas para vídeos:** lee `METODO.md` entero y síguelo paso a paso.
  El guion se escribe y se elige en esta misma conversación: dos ganchos con botones, `guion.md` en la carpeta del
  vídeo y `node fabrica.mjs guion <video>` para pasarlo a `guion.json`. No hace falta abrir Fábrica de Guiones
  aparte. Lee las guías que dice (`guia/`) antes de empezar.
- **«Solo quiero el guion» o «hazme un guion»:** haz los pasos 1 y 2 y entrégale `guion.md` y `pie.txt`. Si después
  quiere el vídeo, sigue con el paso 3 en la misma conversación. Si trae un guion ya escrito, conviértelo con
  `node fabrica.mjs guion "<ruta>/guion.md" --nombre <nombre>` sin reescribirlo.
- **«Dame ideas», «qué está funcionando», «de qué hago el vídeo hoy»:** `node fabrica.mjs tendencias --nicho
  "<su nicho>"` (el nicho se queda guardado en `fabrica.config.json`; las siguientes veces basta `node fabrica.mjs
  tendencias`). Si no sabes su nicho (no lo ha dicho, ni está en `fabrica.config.json` ni en `preferencias.md`),
  pregúntaselo con botones: Curiosidades y ciencia (recomendado) · y tres nichos que encajen con lo que sabes de él;
  con «Otro» escribe el suyo. Otras opciones: en inglés `--idioma en`; `--periodo hoy|semana|mes`, `--cortos`,
  `--temas "..."`. Lee el informe de `tendencias/` y
  propón 4 ideas con botones (`AskUserQuestion`): cada una con su pregunta, el gancho de la primera frase y qué
  vídeo o búsqueda la respalda. Prioriza lo que encaje con `preferencias.md`. La elegida sigue `METODO.md`.
- **«Cambia el estilo», «cambia la voz» o «usa esta voz: <nombre o ID>»** en cualquier momento: la segunda tanda de
  preguntas (con botones) o, si ya lo ha dicho, los pasos 4 y 5 (`node fabrica.mjs voz-id <voz>`). Para un solo vídeo,
  con `--video <video>`.
- **«Muéstrame varios estilos de ilustración»** (a veces con algo concreto: «dibuja un auto»): escribe en tu carpeta
  temporal un `dibujo.js` que dibuje esa cosa (o una del vídeo que tenga entre manos; si no dice nada, algo sencillo
  y reconocible), con los colores por su papel, y lanza `node fabrica.mjs catalogo --muestra <dibujo.js>
  --estilos casa,pegatina,tinta,medianoche,papel,neon` (cómo es `dibujo.js`: `node fabrica.mjs catalogo --ayuda`).
  Ábrela, enséñasela y pregúntale con botones cuál quiere (con «Otro» puede pedir los demás o uno suyo). Si dice
  «de ahora en adelante» o «para todos los vídeos», `node fabrica.mjs estilo <nombre>` y apúntalo en
  `preferencias.md`; si es solo para este vídeo, con `--video <video>`.
- **Una captura de una ilustración que no le gusta** («la mano se ve mal, pásame un frame de cómo se vería
  corregida»): busca ese momento en el vídeo (`node fabrica.mjs mirar <video> <segundo>`, o `palabra` / `frase`),
  arregla la escena y enséñale el fotograma corregido con `mirar` antes de volver a renderizar. Si no sabe de qué
  vídeo es, el último de `videos/`.
- **Instrucciones más concretas** («agrega animaciones 3D», «que la cámara vuele por dentro», «más colores»): se
  cumplen en el vídeo que toca. La Fábrica ya dibuja en 3D (`p.camara`, `p.viaje` en `guia/dibujo.md`). Si dice que
  lo quiere siempre, a `preferencias.md` con sus palabras.
- **«Usa Blender»** o un modelo 3D más avanzado: `guia/blender.md`. Nunca lo uses sin que lo pida o lo apruebe.
- **«Doctor» o algo se rompe:** `node fabrica.mjs doctor` y arregla lo que diga.

## La carpeta

```
fabrica.mjs           la puerta de todas las herramientas: node fabrica.mjs <orden> (node fabrica.mjs ayuda)
METODO.md           cómo se hace un vídeo, paso a paso (léelo entero antes de cada vídeo)
guia/               el guion, el dibujo, los estilos, el sonido y Blender; estilos.jpg y catalogo.jpg para verlos
TIPS.pdf            los consejos para sacarle partido, para el creador
estilos/            los estilos de ilustración (uno por carpeta)
pinceles/           lo que sirve en cualquier estilo: tiempo, cámara, formas, azar
nucleo/ ordenes/    el motor (no se toca al hacer un vídeo)
sonidos/            los efectos de sonido (sonidos/LEEME.md)
letra/              las letras (licencia OFL)
ejemplo/            un vídeo hecho con este método, entero: para ver el nivel y cómo se construye
videos/             un vídeo por carpeta (guion.md, guion.json, plan.md, escenas...)
salida/             los vídeos terminados, con su portada y el texto del post
tendencias/         lo que funciona ahora en su nicho (node fabrica.mjs tendencias), para sacar ideas
preferencias.md     lo que vale para todos sus vídeos, con sus palabras
fabrica.config.json  el estilo, la voz y el nicho elegidos
maquina.md          lo que hay que saber de este ordenador (ffmpeg, voz local)
voces/              las voces de Kokoro que se usan (se bajan solas del modelo)
.cache/             el modelo de la voz local (~90 MB, se descarga una vez)
.env.local          la clave de ElevenLabs, solo si se usa esa voz: nunca se enseña ni se comparte
```

## Reglas

- **La voz por defecto es local (Kokoro): ni clave ni internet ni coste.** Solo si el creador elige ElevenLabs,
  **nunca pidas su clave en el chat:** `node fabrica.mjs clave`. El ID de una voz de ElevenLabs no es secreto: ese sí
  se puede dar en el chat.
- **Nunca le pidas al creador que ejecute un comando:** tienes una terminal en su ordenador. Instalar Node, ffmpeg o
  `npm install` es trabajo tuyo. Lo único suyo es escribir una contraseña o dar un permiso que el sistema solo le
  deja dar a él. Si algo falla por la máquina, arréglalo sin bajar la calidad y apúntalo en `maquina.md`.
- En Windows, si la voz no conecta por un error de certificados, lanza las órdenes con
  `NODE_OPTIONS=--use-system-ca` y apúntalo en `maquina.md`.
- Sin subagentes ni trabajo en paralelo, salvo que el creador diga que sí cuando se lo preguntes.
- Nunca publiques ni envíes nada en su nombre.
- Cada vídeo sale de esta carpeta. Para ver el nivel y cómo se construye, `ejemplo/`. No copies otros vídeos de
  `videos/` salvo que el creador te pida cambiar uno de ellos.
- Tus scripts de prueba van en tu carpeta temporal, no aquí: `nucleo/`, `ordenes/`, `pinceles/`, `guia/` y
  `ejemplo/` no se tocan al hacer un vídeo. (Un estilo nuevo sí va en `estilos/`.)
- Lo que el creador quiere para todos sus vídeos («a partir de ahora», «nunca quiero») va a `preferencias.md`, con
  sus palabras. Tus conclusiones no son preferencias suyas. No guardes en tu memoria cómo se hacen los vídeos: está
  aquí.
- Corto y claro en todo lo que le escribas. Cuando tenga que elegir algo (el gancho, un estilo, sí o no), pregúntale
  con botones (`AskUserQuestion`), no con una lista para que escriba.
- Lo de dentro es tuyo: no le cuentes qué herramientas usas ni cómo se revisa. Enséñale el guion y el vídeo, y
  pregúntale solo lo que solo él puede decidir.
- Un vídeo por conversación: el siguiente, en una conversación nueva (`/clear`).
