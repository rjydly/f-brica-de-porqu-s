// voz-id: elige la voz de los vídeos (local con Kokoro, o ElevenLabs). Sin nada, dice cuál se usa ahora.
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { CASA, config, guardaConfig, guardaWav, para, secretos } from "../nucleo/base.mjs";
import { VOZ_FABRICA } from "./voz.mjs";
import { VOCES, VOZ as VOZ_KOKORO, sintetiza } from "../nucleo/kokoro.mjs";

export const ayuda = `
node fabrica.mjs voz-id                       dice qué voz se usa ahora y cuáles hay
node fabrica.mjs voz-id <voz>                 usa esa voz en todos los vídeos y deja una muestra
node fabrica.mjs voz-id <voz> --video X       solo en ese vídeo
node fabrica.mjs voz-id --motor kokoro        la voz local, gratis y sin internet (por defecto)
node fabrica.mjs voz-id --motor elevenlabs    la voz de ElevenLabs (necesita su clave)
node fabrica.mjs voz-id --quitar              vuelve a la voz de fábrica del motor elegido

Con Kokoro, la voz es un nombre de su lista: em_alex (español, hombre), ef_dora (español, mujer), em_santa…
Se ven todos con «node fabrica.mjs voz-id». Deja la muestra en voz-muestra.wav.
Con ElevenLabs, el ID se copia en elevenlabs.io → Voices → la voz → «ID» (unas 20 letras y números).
--velocidad 0.95 · --pausa 0.3 · --idioma es|es-419|en · --estabilidad 0.4 · --modelo eleven_multilingual_v2 · --parecido 0.7 · --expresion 0:
ajustes de la voz, con la misma orden. (El idioma se deduce de la voz; --idioma es-419 para español de América.)
`;

const AJUSTES = { velocidad: "velocidad", pausa: "pausa", idioma: "idioma", estabilidad: "estabilidad", modelo: "modelo", parecido: "parecido", expresion: "expresion" };
const esKokoro = (id) => /^[a-z]{1,2}_[a-z0-9_]+$/.test(String(id));

export async function corre({ libres, marcas }) {
  const ajustes = {};
  for (const [k, campo] of Object.entries(AJUSTES)) if (marcas[k] !== undefined) ajustes[campo] = ["modelo", "idioma"].includes(k) ? String(marcas[k]) : Number(marcas[k]);

  if (marcas.motor) {
    const motor = String(marcas.motor).toLowerCase();
    if (!["kokoro", "elevenlabs"].includes(motor)) para(`«${marcas.motor}» no es un motor de voz. Es kokoro o elevenlabs.`);
    guardaConfig({ voz: { ...config().voz, motor } });
    console.log(motor === "kokoro"
      ? `Voz local (Kokoro) para los vídeos nuevos. Voces: node fabrica.mjs voz-id`
      : `ElevenLabs para los vídeos nuevos. Antes, su clave: node fabrica.mjs clave`);
    return;
  }

  if (marcas.quitar) {
    const nuevo = { ...config().voz, id: "", kokoro: "" };
    guardaConfig({ voz: nuevo });
    console.log(`Vuelve la voz de fábrica (${nuevo.motor === "elevenlabs" ? VOZ_FABRICA : VOZ_KOKORO}).`);
    return;
  }

  const id = libres[0];
  if (!id && !Object.keys(ajustes).length) {
    const v = config().voz, motor = String(v.motor || "kokoro");
    console.log(`Voz: ${motor === "elevenlabs" ? (v.id || VOZ_FABRICA + " (la de Fábrica de Porqués)") : (v.kokoro || VOZ_KOKORO + " (de Kokoro)")}`);
    console.log(`  motor ${motor} · velocidad ${v.velocidad} · pausa ${v.pausa ?? 0.3}${motor === "elevenlabs" ? ` · estabilidad ${v.estabilidad}` : ""}`);
    if (motor !== "elevenlabs") {
      console.log("  voces de Kokoro:");
      for (const [n, d] of Object.entries(VOCES)) console.log(`    ${n.padEnd(12)} ${d}`);
    }
    return;
  }

  let motor = String(config().voz.motor || "kokoro").toLowerCase();
  const cambio = {};
  if (id && esKokoro(id)) { motor = "kokoro"; cambio.kokoro = id; }
  else if (id && /^[A-Za-z0-9]{16,32}$/.test(id)) { motor = "elevenlabs"; cambio.id = id; }
  else if (id) para(`«${id}» no parece una voz de Kokoro (em_alex, ef_dora…) ni un ID de ElevenLabs (unas 20 letras y números).`);
  cambio.motor = motor;

  if (marcas.video) {
    const { carpetaVideo, json } = await import("../nucleo/base.mjs");
    const dir = carpetaVideo(String(marcas.video)), g = json.lee(join(dir, "guion.json"));
    g.voz = { ...(g.voz || {}), ...cambio, ...ajustes };
    json.escribe(join(dir, "guion.json"), g);
    console.log(`Voz puesta en ${dir}/guion.json. Rehaz su voz: node fabrica.mjs voz ${String(marcas.video)}`);
    return;
  }

  guardaConfig({ voz: { ...cambio, ...ajustes } });
  if (id && !ajustes.idioma) guardaConfig({ voz: { idioma: "" } }); // el idioma lo pone la voz (em_ → es, af_ → en…)
  if (id) await prueba(id, { ...config().voz, ...ajustes }, motor);
  console.log(`Guardado en fabrica.config.json: ${id ? `voz ${id}` : ""}${Object.keys(ajustes).length ? " " + JSON.stringify(ajustes) : ""}. Vale para los vídeos nuevos y para los que vuelvan a pedir su voz.`);
}

async function prueba(id, a, motor) {
  if (motor === "kokoro") {
    const { audio, sr } = await sintetiza(["Hola. Así suena la voz de tus vídeos."], { ...a, kokoro: id }, (m) => console.log(m));
    const ruta = join(CASA, "voz-muestra.wav");
    guardaWav(ruta, audio, sr);
    console.log(`La voz funciona. Muestra: ${ruta}`);
    return;
  }
  secretos();
  const clave = process.env.ELEVENLABS_API_KEY;
  if (!clave) para("Antes, la clave de ElevenLabs: node fabrica.mjs clave");
  const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${id}?output_format=mp3_44100_128`, {
    method: "POST", headers: { "xi-api-key": clave, "content-type": "application/json" },
    body: JSON.stringify({ text: "Hola. Así suena la voz de tus vídeos.", model_id: a.modelo, voice_settings: { stability: a.estabilidad, similarity_boost: a.parecido, style: a.expresion, speed: a.velocidad } }),
  }).catch((err) => para(`No se pudo llegar a ElevenLabs (${err.cause?.code || err.message}).`));
  if (!r.ok) para(`ElevenLabs no puede usar la voz ${id} (${r.status}): ${(await r.text()).slice(0, 200)}`);
  const ruta = join(CASA, "voz-muestra.mp3");
  writeFileSync(ruta, Buffer.from(await r.arrayBuffer()));
  console.log(`La voz funciona. Muestra: ${ruta}`);
}
