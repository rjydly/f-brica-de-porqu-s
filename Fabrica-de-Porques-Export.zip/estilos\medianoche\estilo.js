// Medianoche: fondo índigo muy oscuro con un halo suave detrás de la cosa. Sin contornos: cada pieza tiene su
// filo de luz arriba a la izquierda (como iluminada por una lámpara) y su sombra propia abajo. Colores intensos.
import { creaEstilo, debajo } from "../comun.js";
import { aclara } from "../../pinceles/color.js";

export default creaEstilo({
  nombre: "medianoche",
  descripcion: "Índigo oscuro con halo, sin contornos, cada pieza con su filo de luz. Elegante y cinematográfico.",
  color: {
    fondo: "#0f1022", fondo2: "#1c1d3d", suelo: "#15162e",
    tinta: "#eef0ff",
    principal: "#4cc9f0", principalSombra: "#2a95bf",
    secundario: "#ff6b6b", secundarioSombra: "#d1484f",
    acento: "#ffd23f", acentoSombra: "#e0aa16",
    neutro: "#3ddc97", neutroSombra: "#25ab72",
    metal: "#b8bdd6", metalSombra: "#8a90ad",
    piel: "#ffb38a", pielSombra: "#de8e66",
    claro: "#f4f5ff", claroSombra: "#d4d7ee",
    oscuro: "#0f1022",
    invisible: "#b388ff",
    mal: "#ff5c5c", bien: "#3ddc97",
  },
  letras: { fuerte: "nunito-900", media: "nunito-800", normal: "nunito-700" },
  grosor: 0,
  fondo(c, { disco, suelo } = {}, e) {
    c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
    c.fillStyle = e.color.fondo; c.fillRect(0, 0, c.canvas.width, c.canvas.height);
    c.restore();
    if (suelo !== undefined) { c.fillStyle = e.color.suelo; c.fillRect(-2000, suelo, 6000, 4000); }
    if (disco) {
      const g = c.createRadialGradient(disco[0], disco[1], 0, disco[0], disco[1], disco[2] * 1.25);
      g.addColorStop(0, "rgba(90,96,200,0.42)"); g.addColorStop(1, "rgba(90,96,200,0)");
      c.fillStyle = g; c.fillRect(disco[0] - disco[2] * 1.3, disco[1] - disco[2] * 1.3, disco[2] * 2.6, disco[2] * 2.6);
    }
  },
  pieza(c, camino, [color, sombra], { plano = false } = {}) {
    c.save();
    camino(c);
    if (plano) { c.fillStyle = color; c.fill(); c.restore(); return; }
    c.clip();
    camino(c); c.fillStyle = aclara(color, 0.55); c.fill();          // el filo de luz
    c.translate(7, 7); camino(c); c.fillStyle = color; c.fill();      // la pieza, un poco desplazada
    c.translate(22, 22); camino(c); c.fillStyle = sombra; c.fill();   // la sombra propia, abajo a la derecha
    c.translate(-26, -26); camino(c); c.fillStyle = color; c.fill();
    c.restore();
  },
  sombra(g, capa) { debajo(g, capa, "rgba(0,0,0,0.6)", 0, 26, 24); },
  subtitulos: {
    tam: 76, linea: 86, letra: "nunito-900", letraDicha: "nunito-800",
    color: "#ffffff", dicho: "#8d90b8", contorno: "#0f1022", grosorContorno: 12,
    resalte: "rotulador", colorResalte: "#ffd23f", textoResalte: "#0f1022",
  },
});
