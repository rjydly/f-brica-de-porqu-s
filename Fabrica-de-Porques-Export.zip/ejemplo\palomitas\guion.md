# Por qué explotan las palomitas

**En una frase:** el maíz de palomitas revienta porque su cáscara es dura y no deja salir el vapor; el de la mazorca
lo deja escapar.
**Duración:** unos 55 segundos (154 palabras).

## Los dos ganchos

**A (el elegido)**
> ¿Por qué el maíz de palomitas explota y el de la mazorca no? Los dos son maíz, pero solo uno salta.

Primer segundo: en el fotograma 0, un grano tiembla en la sartén y a los 0,3 s revienta en una palomita enorme con
trozos de cáscara volando.

**B**
> ¿Sabías que una palomita salta porque le crece una pata? Y no es lo único raro que pasa en tu sartén.

Primer segundo: a cámara lenta, a un grano le sale una pata de espuma que se aplasta contra la sartén y lo lanza
dando la vuelta hacia la cámara.

## Frase a frase

| # | Frase | Resalta | Lo que se ve |
|---|---|---|---|
| 1 | ¿Por qué el maíz de palomitas explota y el de la mazorca no? | explota | Los dos granos en la sartén, que tiembla de calor. El de palomitas revienta en una palomita enorme; en «mazorca», el otro solo se tuesta y echa un hilo de humo. |
| 2 | Los dos son maíz, pero solo uno salta. | salta | Los dos juntos. En «salta», la palomita da un bote con voltereta y cae. |
| 3 | Dentro de cada grano hay una gotita de agua. | agua | El grano de palomitas cortado, enorme: cáscara y almidón. En «gotita» aparece una gota azul en el centro. |
| 4 | Al calentarlo, esa agua se convierte en vapor y quiere salir. | vapor | Llamas debajo; la gota tiembla y se deshace en bolitas de vapor que empujan la cáscara desde dentro. |
| 5 | En el maíz normal, la cáscara tiene poros, y el vapor se escapa poco a poco. | escapa | El grano de mazorca cortado, con la cáscara llena de agujeritos; el vapor sale por ellos a hilitos. |
| 6 | Pero la del maíz de palomitas es dura y no deja salir nada, como una olla a presión. | olla | La cáscara de palomitas engorda; el vapor choca y rebota. En «como», una olla a presión con la válvula silbando. |
| 7 | A unos ciento ochenta grados, la presión dentro es nueve veces la del aire, y la cáscara revienta. | revienta | El grano con un termómetro: «180 °C»; se hincha y tiembla; «×9»; en «revienta», la cáscara se raja y estalla. |
| 8 | El almidón de dentro se hincha como una espuma, hasta cuarenta veces su tamaño. | espuma | La espuma blanca sale y crece hasta llenar la pantalla; al lado, el grano de antes, pequeñito. «×40». |
| 9 | Y salta porque le sale una patita de espuma que empuja contra la sartén. | patita | La sartén a cámara lenta: le sale una patita, se aplasta contra la sartén y lo lanza dando la vuelta. *(el segundo «¡anda!»)* |
| 10 | Lo que suena no es la cáscara: es el vapor saliendo de golpe. | vapor | Primer plano de la raja: una cruz roja en «cáscara»; en «vapor», un chorro sale con ondas de sonido. |
| 11 | Así que el secreto no está dentro del grano: está en su cáscara. | cáscara | Los dos granos en la sartén, como al principio. Se marca la cáscara del de palomitas. *(enlaza con el gancho)* |
| 12 | Envíaselo a quien siempre quema las palomitas. | quema | Un cuenco lleno de palomitas; cae encima una negra que humea. |

Leídas seguidas, las palabras resaltadas cuentan el vídeo: explota, salta, agua, vapor, escapa, olla, revienta,
espuma, patita, vapor, cáscara, quema.

## Los sitios

- **La sartén** (de lado, caliente): frases 1-2, 9 y 11.
- **Dentro del grano de palomitas** (cortado, enorme): frases 3-4, 6-8.
- **Dentro del grano de mazorca** (cortado): frase 5.
- **La olla a presión**: la comparación de la frase 6.
- **El primer plano de la raja**: frase 10.
- **El cuenco**: el cierre.

## Para leer de corrido

¿Por qué el maíz de palomitas explota y el de la mazorca no? Los dos son maíz, pero solo uno salta.

Dentro de cada grano hay una gotita de agua. Al calentarlo, esa agua se convierte en vapor y quiere salir. En el maíz
normal, la cáscara tiene poros, y el vapor se escapa poco a poco. Pero la del maíz de palomitas es dura y no deja
salir nada, como una olla a presión.

A unos ciento ochenta grados, la presión dentro es nueve veces la del aire, y la cáscara revienta. El almidón de
dentro se hincha como una espuma, hasta cuarenta veces su tamaño. Y salta porque le sale una patita de espuma que
empuja contra la sartén.

Lo que suena no es la cáscara: es el vapor saliendo de golpe. Así que el secreto no está dentro del grano: está en su
cáscara.

Envíaselo a quien siempre quema las palomitas.
