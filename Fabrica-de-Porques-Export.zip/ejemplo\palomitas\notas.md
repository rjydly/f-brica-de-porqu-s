# Por qué explotan las palomitas

Pedido el 2026-10-23. Estilo: papel. 51,8 s, 10 escenas, 68 efectos.

- Gancho: dos versiones. Se eligió la de la sartén (un grano revienta en el fotograma 0,3 y el de mazorca solo se
  tuesta): se entiende a la primera. La de la reacción en cadena (`video/alternativas/01-cadena.js`) era más
  espectacular pero tapaba los subtítulos con palomitas volando y escondía el grano de mazorca.
- La primera versión del gancho dejaba los granos pequeños y abajo: se acercó la cámara (zoom 2,1 → 1,4).
- Escenas que entraban en una palabra repetida («en», «pero») entraban en la primera vez que se decía: se usa
  `palabra@frase`.
- Los cambios entre el grano de palomitas y el de mazorca cortados se parecían demasiado: pasan con barrido.
- Huecos sin sonido en 14-17 s, 18-21 s y 34-37 s: se añadieron el zas del barrido, latidos y el grano que se abre.
- La patita parecía una columna: se acortó y se agrandó la palomita.
