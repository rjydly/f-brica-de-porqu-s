// La otra versión del gancho. «¿Por qué el maíz de palomitas explota y el de la mazorca no?»
// Fotograma 0: la sartén llena de granos, muy cerca. Revientan uno detrás de otro en cadena desde el primer
// fotograma, la cámara se aleja entre palomitas que saltan, y en el centro queda el grano de mazorca, intacto, que en
// «mazorca» solo humea. En la frase 2, todas quietas; en «salta» la palomita de su lado da un bote.
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
import { grano, humo, mazorca, palomita, sarten } from "../comun.js";

export const empieza = 0;
const F1 = voz.frase(1), F2 = voz.frase(2), T_MAZ = F1.en("mazorca"), T_SALTA = F2.en("salta");
const SUELO = 1460, MX = 560, MY = SUELO - 120;

// los granos de palomitas: dónde están y cuándo revientan (en cadena, del primero a los de los lados)
const r = p.azar("cadena");
export const granos = [-480, -350, -220, 220, 350, 480].map((dx, i) => ({
  x: MX + dx, y: SUELO - 110 - r.entre(0, 14), s: r.entre(180, 205), semilla: 40 + i,
  revienta: 0.08 + (dx + 480) * 0.0011 + r.entre(0, 0.06), salto: r.entre(260, 420), gira: r.signo() * r.entre(3, 7),
}));
const SALTA = granos.reduce((a, b) => (Math.abs(b.x - MX) < Math.abs(a.x - MX) ? b : a)); // la de al lado

export function pinta(c, t) {
  e.fondo(c);
  const enc = {
    x: p.recorrido([[0, MX - 470], [0.9, MX - 120], [T_MAZ - 0.3, MX], [F2.desde, MX]])(t),
    y: p.recorrido([[0, 1300], [T_MAZ, 1280], [F2.desde + 0.6, 1290]])(t),
    zoom: p.recorrido([[0, 2.6], [0.9, 1.6], [T_MAZ - 0.3, 1.5], [T_MAZ + 0.4, 1.9], [F2.desde, 1.9], [F2.desde + 0.8, 1.25]])(t),
  };
  p.pantalla(c, enc, () => {
    sarten(c, SUELO, t, { x0: -300, x1: 1400, mango: false });
    humo(c, MX, MY - 110, t, T_MAZ + 0.05, { n: 6 });
    e.objeto(c, (c) => mazorca(c, MX, MY, 230, { tostado: p.entre(t, T_MAZ - 0.2, T_MAZ + 0.8, 0, 0.55) }));
    for (const g of granos) {
      const dt = t - g.revienta;
      if (dt < 0) { const tiembla = 7 * Math.sin(t * 80 + g.x); e.objeto(c, (c) => grano(c, g.x + tiembla, g.y, g.s)); continue; }
      const abre = p.rebota(p.rango(dt, 0, 0.25), 1.4), vuela = p.rango(dt, 0, 0.7), alto = g.salto * 4 * vuela * (1 - vuela);
      const bote = g === SALTA ? 330 * 4 * p.rango(t, T_SALTA - 0.08, T_SALTA + 0.55) * (1 - p.rango(t, T_SALTA - 0.08, T_SALTA + 0.55)) : 0;
      const giro = g.gira * p.suaviza(vuela) * 0.5 + (g === SALTA ? Math.PI * 2 * p.suaviza(p.rango(t, T_SALTA - 0.08, T_SALTA + 0.55)) : 0);
      e.objeto(c, (c) => palomita(c, g.x, g.y - 50 * abre - alto - bote, p.mezcla(g.s, g.s * 1.35, abre), { abre, rot: giro, semilla: g.semilla }));
      const f = p.rango(dt, 0, 0.3);
      if (f < 1) e.objeto(c, (c) => e.pieza(c, (q) => p.estrella(q, g.x, g.y - 50, 9, 80 + 220 * p.llega(f), 40 + 120 * p.llega(f), f), "acento", { plano: true }), { opacidad: 1 - f, sinSombra: true });
    }
  });
}
