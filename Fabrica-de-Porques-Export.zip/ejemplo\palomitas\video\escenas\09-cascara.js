// «Así que el secreto no está dentro del grano: está en su cáscara.»
// Los dos granos enteros en la sartén, como al principio. En «grano» la cámara entra hacia el de palomitas; en
// «cáscara» su contorno se marca con un trazo grueso que lo rodea, con su rótulo.
import * as p from "#pincel";
import { estilo as e } from "#estilo";
import { voz } from "#voz";
import { caminoGrano, grano, mazorca, sarten } from "../comun.js";

export const empieza = "asi@11";
const F = voz.frase(11), GRANO = F.en("grano"), CASCARA = F.en("cascara");
const SUELO = 1460, GX = 385, MX = 715, GY = SUELO - 120;

export function pinta(c, t) {
  e.fondo(c);
  const enc = {
    x: p.recorrido([[F.desde, 550], [GRANO - 0.3, 550], [CASCARA - 0.1, GX + 40]])(t),
    y: p.recorrido([[F.desde, 1290], [GRANO - 0.3, 1290], [CASCARA - 0.1, 1250]])(t),
    zoom: p.recorrido([[F.desde, 1.4], [GRANO - 0.3, 1.4], [CASCARA - 0.1, 2.3]])(t),
  };
  p.pantalla(c, enc, () => {
    sarten(c, SUELO, t);
    e.objeto(c, (c) => { grano(c, GX, GY, 230); mazorca(c, MX, GY, 230); });
    // el contorno que se dibuja alrededor de la cáscara
    const u = p.llega(p.rango(t, CASCARA - 0.1, CASCARA + 0.4));
    if (u > 0) {
      c.save(); c.setLineDash([800 * u, 4000]);
      e.trazo(c, (g) => caminoGrano(g, GX, GY, 230 * 1.2, 0), { papel: "secundario", grosor: 10 });
      c.restore();
    }
    e.rotulo(c, GX + 110, GY - 200, "la cáscara", { apunta: [GX + 80, GY - 90], opacidad: p.rango(t, CASCARA, CASCARA + 0.2), tam: 30 });
  });
}
