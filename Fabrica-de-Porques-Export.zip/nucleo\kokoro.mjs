// La voz local: Kokoro-82M corriendo en este ordenador. Gratis, sin clave y sin internet (solo la primera descarga).
// Devuelve lo mismo que la toma de ElevenLabs: las muestras de audio y el segundo de cada palabra.
//
// El modelo no sabe leer texto: hay que darle fonemas. Los saca espeak-ng (el mismo que usa Kokoro en Python), que va
// dentro de este proyecto y habla español de España (es) y de América (es-419).
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { CASA, guardaWav, para } from "./base.mjs";

export const MODELO = "onnx-community/Kokoro-82M-v1.0-ONNX";
export const VOZ = "em_alex"; // español, hombre, voz neutra (la de los vídeos si no se elige otra)

// Las voces de Kokoro que sirven para los vídeos. Cualquier otra de su lista también vale: se baja sola.
export const VOCES = {
  em_alex: "Español · hombre, neutro",
  em_santa: "Español · hombre, más grave",
  ef_dora: "Español · mujer",
  af_heart: "Inglés (EE. UU.) · mujer",
  am_michael: "Inglés (EE. UU.) · hombre",
  bf_emma: "Inglés (Reino Unido) · mujer",
  bm_george: "Inglés (Reino Unido) · hombre",
  ff_siwis: "Francés · mujer",
  if_sara: "Italiano · mujer",
  im_nicola: "Italiano · hombre",
  pf_dora: "Portugués (Brasil) · mujer",
  pm_alex: "Portugués (Brasil) · hombre",
  zf_xiaobei: "Chino (mandarín) · mujer",
};

// De la primera letra de la voz sale el idioma de espeak-ng que hay que usar.
const IDIOMAS = { a: "en-us", b: "en-gb", e: "es", f: "fr-fr", h: "hi", i: "it", j: "ja", p: "pt-br", z: "cmn" };
const CARPETA_VOCES = join(CASA, "voces");
const CARPETA_CACHE = join(CASA, ".cache");

let motor = null, espeak = null;
const estilos = new Map();

// Carga el modelo una sola vez por proceso. La primera vez se lo baja (~90 MB) y lo guarda en .cache/.
export async function carga(aviso = () => {}) {
  if (motor) return motor;
  let mod;
  try {
    mod = await import("@huggingface/transformers");
  } catch {
    para("Falta el motor de la voz local: npm install (en esta carpeta).");
  }
  mod.env.cacheDir = CARPETA_CACHE;
  aviso("cargando Kokoro (la primera vez descarga el modelo, unos 90 MB)…");
  const modelo = mod.StyleTextToSpeech2Model.from_pretrained(MODELO, {
    dtype: "q8", device: "cpu",
    progress_callback: (p) => {
      if (p.status === "progress" && p.progress != null && p.file && /\.onnx$/.test(p.file)) {
        aviso(`descargando ${p.file}: ${Math.round(p.progress)} %`);
      }
    },
  });
  let mod2, tokenizer;
  try {
    [mod2, tokenizer] = await Promise.all([modelo, mod.AutoTokenizer.from_pretrained(MODELO)]);
  } catch (err) {
    if (/onnxruntime|binding|\.node/i.test(String(err.message))) {
      para("Falta el motor de ONNX que usa la voz local. Arréglalo con: node node_modules/onnxruntime-node/script/install");
    }
    para(`No se pudo cargar la voz local: ${err.message}`);
  }
  motor = { modelo: mod2, tokenizer, Tensor: mod.Tensor };
  return motor;
}

// Los fonemas de una frase, con espeak-ng. `idioma` puede ser es, es-419 (América), en-us…
async function fonemas(texto, idioma) {
  if (!espeak) {
    let ESpeakNg;
    try {
      ({ default: ESpeakNg } = await import("espeak-ng"));
    } catch {
      para("Falta espeak-ng para pasar el texto a fonemas: npm install espeak-ng (en esta carpeta).");
    }
    espeak = ESpeakNg;
  }
  let salida;
  try {
    const e = await espeak({ arguments: ["--phonout", "salida", "--sep=", "-q", "--ipa=3", "-v", idioma, texto] });
    salida = e.FS.readFile("salida", { encoding: "utf8" });
  } catch (err) {
    para(`espeak-ng no pudo leer «${texto.slice(0, 60)}…» (${err.message}).`);
  }
  const ipa = salida.replace(/[\n\r]/g, " ").replace(/\u200d/g, "").replace(/\s+/g, " ").trim();
  if (!ipa) para(`espeak-ng no sacó fonemas de «${texto.slice(0, 60)}…».`);
  return ipa;
}

// El archivo de la voz (un .bin con sus estilos). Si no está, se baja del modelo (medio megabyte).
async function vozBin(nombre) {
  if (estilos.has(nombre)) return estilos.get(nombre);
  const ruta = join(CARPETA_VOCES, `${nombre}.bin`);
  if (!existsSync(ruta)) {
    mkdirSync(CARPETA_VOCES, { recursive: true });
    const url = `https://huggingface.co/${MODELO}/resolve/main/voices/${nombre}.bin`;
    let r;
    try {
      r = await fetch(url);
    } catch (err) {
      para(`No se pudo bajar la voz ${nombre} (${err.cause?.code || err.message}). ¿Hay internet?`);
    }
    if (!r.ok) para(`La voz «${nombre}» no está en Kokoro (${r.status}). Voces: node fabrica.mjs voz-id`);
    writeFileSync(ruta, Buffer.from(await r.arrayBuffer()));
  }
  const buf = readFileSync(ruta);
  const floats = new Float32Array(buf.buffer, buf.byteOffset, buf.length / 4);
  estilos.set(nombre, floats);
  return floats;
}

// Síntesis del guion entero: una frase detrás de otra, con su pausa, y el tiempo de cada palabra.
export async function sintetiza(dichos, a = {}, log = () => {}) {
  const { modelo, tokenizer, Tensor } = await carga(log);
  const voz = String(a.kokoro || VOZ);
  const idioma = String(a.idioma || IDIOMAS[voz[0]] || "es");
  const velocidad = Number(a.velocidad) > 0 ? Number(a.velocidad) : 1;
  const pausaFrase = Number(a.pausa) >= 0 ? Number(a.pausa) : 0.3;
  const estilo = await vozBin(voz);
  const sr = 24000;

  const trozos = [], palabras = [];
  let t = 0;
  for (let i = 0; i < dichos.length; i++) {
    const texto = String(dichos[i]).trim();
    if (!texto) continue;
    log(`voz ${i + 1}/${dichos.length}: «${texto.slice(0, 60)}${texto.length > 60 ? "…" : ""}»`);
    const ipa = await fonemas(texto, idioma);
    const { input_ids } = tokenizer(ipa, { truncation: true });
    const n = input_ids.dims.at(-1);
    if (n > 511) para(`La frase ${i + 1} es demasiado larga para la voz local (${n} fonemas; el máximo son 511). Pártela con un punto y vuelve a hacer la voz: node fabrica.mjs voz <video> --otra-vez`);
    const off = 256 * Math.min(Math.max(n - 2, 0), 509);
    const style = new Tensor("float32", estilo.slice(off, off + 256), [1, 256]);
    let salida;
    try {
      salida = await modelo({ input_ids, style, speed: new Tensor("float32", [velocidad], [1]) });
    } catch (err) {
      para(`Kokoro no pudo con la frase ${i + 1}: ${err.message}`);
    }
    const muestras = recorta(salida.waveform.data, sr);
    const dura = muestras.length / sr;
    const dichas = palabrasDe(texto);
    const tiempos = reparte(dichas, t, t + dura);
    dichas.forEach((w, j) => palabras.push({ dice: w, desde: redondea(tiempos[j][0]), hasta: redondea(tiempos[j][1]) }));
    trozos.push(muestras);
    const pausa = i === dichos.length - 1 ? 0 : pausaFrase;
    trozos.push(new Float32Array(Math.round(pausa * sr)));
    t += dura + pausa;
  }

  const audio = new Float32Array(Math.round(t * sr));
  let k = 0;
  for (const trozo of trozos) { audio.set(trozo, k); k += trozo.length; }
  sube(audio);
  return { audio, palabras, sr };
}

// Escribe la toma en <video>/voz/ y devuelve su toma.json (misma forma que la de ElevenLabs).
export async function toma(dir, dichos, a, firma, log = () => {}) {
  const { audio, palabras, sr } = await sintetiza(dichos, a, log);
  guardaWav(join(dir, "voz", "toma.wav"), audio, sr);
  return { firma, motor: "kokoro", ajustes: a, palabras };
}

export const palabrasDe = (s) => String(s).trim().split(/\s+/).filter((w) => /[\p{L}\p{N}]/u.test(w));

const redondea = (x, d = 3) => Math.round(x * 10 ** d) / 10 ** d;

// Cuántas sílabas suena una palabra (para repartir el tiempo de la frase; en español acierta de sobra).
function silabas(palabra) {
  const w = String(palabra).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zñ]/g, "");
  const grupos = w.match(/[aeiou]+/g);
  return Math.max(1, grupos ? grupos.length : 1);
}

// El tiempo de cada palabra dentro de una frase: por sílabas y con la pausa de la coma donde toca.
function reparte(dichas, desde, hasta) {
  const pesos = dichas.map((w) => silabas(w) + 0.45 + 0.04 * String(w).length);
  const pausas = dichas.map((w) => {
    if (/[,;:]$/.test(w)) return 0.12;
    if (/…$/.test(w)) return 0.22;
    if (/[-–—]$/.test(w)) return 0.14;
    return 0;
  });
  let totalPausas = pausas.reduce((s, x) => s + x, 0);
  const cabe = (hasta - desde) * 0.45;
  if (totalPausas > cabe && totalPausas > 0) {
    const f = cabe / totalPausas;
    for (let i = 0; i < pausas.length; i++) pausas[i] *= f;
    totalPausas = cabe;
  }
  const totalPesos = pesos.reduce((s, x) => s + x, 0);
  const habla = Math.max(0.05, hasta - desde - totalPausas);
  const out = [];
  let t = desde;
  dichas.forEach((_, i) => {
    const d = (habla * pesos[i]) / totalPesos;
    out.push([t, t + d]);
    t += d + pausas[i];
  });
  return out;
}

// Quita el silencio de los extremos (con 12 ms de margen y un desvanecido corto, para que no chasquee).
function recorta(audio, sr) {
  const a = audio instanceof Float32Array ? audio : new Float32Array(audio);
  let pico = 0;
  for (let i = 0; i < a.length; i++) pico = Math.max(pico, Math.abs(a[i]));
  const lim = Math.max(0.004, pico * 0.02);
  let i0 = 0, i1 = a.length - 1;
  while (i0 < i1 && Math.abs(a[i0]) < lim) i0++;
  while (i1 > i0 && Math.abs(a[i1]) < lim) i1--;
  const margen = Math.round(0.012 * sr);
  i0 = Math.max(0, i0 - margen);
  i1 = Math.min(a.length - 1, i1 + margen);
  const out = a.slice(i0, i1 + 1);
  const fade = Math.min(Math.round(0.006 * sr), Math.floor(out.length / 2));
  for (let i = 0; i < fade; i++) { out[i] *= i / fade; out[out.length - 1 - i] *= i / fade; }
  return out;
}

// Si la voz sale muy baja o se pasa, la deja en un nivel cómodo (el render acaba de ajustar el volumen).
function sube(audio) {
  let pico = 0;
  for (let i = 0; i < audio.length; i++) pico = Math.max(pico, Math.abs(audio[i]));
  if (pico > 0.98) { const g = 0.9 / pico; for (let i = 0; i < audio.length; i++) audio[i] *= g; }
  else if (pico > 0 && pico < 0.35) { const g = Math.min(0.7 / pico, 8); for (let i = 0; i < audio.length; i++) audio[i] *= g; }
}
