// Pegatina: cada cosa es una pegatina con su borde blanco grueso, sobre un fondo ciruela oscuro. Colores vivos con
// volumen suave y una sombra que la despega del fondo. Muy de redes: se ve desde lejos.
import { creaEstilo, siluetaDe } from "../comun.js";

const BORDE = 11;
const VUELTAS = Array.from({ length: 16 }, (_, i) => [Math.cos((i / 16) * Math.PI * 2) * BORDE, Math.sin((i / 16) * Math.PI * 2) * BORDE]);

export default creaEstilo({
  nombre: "pegatina",
  descripcion: "Pegatinas con borde blanco sobre fondo ciruela oscuro. Colores vivos, se ven desde lejos.",
  color: {
    fondo: "#1d1526", fondo2: "#2a1f36", suelo: "#251b30",
    tinta: "#ffffff",
    principal: "#3d8bff", principalSombra: "#2763c9",
    secundario: "#ff5d73", secundarioSombra: "#d63c55",
    acento: "#ffc93d", acentoSombra: "#e0a114",
    neutro: "#2fd39a", neutroSombra: "#1fa877",
    metal: "#c5cad6", metalSombra: "#9aa1b2",
    piel: "#ffbb93", pielSombra: "#e0946b",
    claro: "#ffffff", claroSombra: "#e9e4f0",
    oscuro: "#1d1526",
    invisible: "#b48cff",
    mal: "#ff4757", bien: "#2ed573",
  },
  letras: { fuerte: "fredoka-700", media: "fredoka-600", normal: "fredoka-500" },
  grosor: 0,
  pieza(c, camino, [color, sombra], { plano = false } = {}) {
    c.save();
    camino(c); c.fillStyle = color; c.fill();
    if (!plano) { c.save(); camino(c); c.clip(); c.fillStyle = sombra; c.fill(); c.translate(-18, -22); camino(c); c.fillStyle = color; c.fill(); c.restore(); }
    c.restore();
  },
  // el borde blanco de la pegatina (la silueta repetida alrededor) y, debajo, su sombra
  sombra(g, capa) {
    const blanca = siluetaDe(capa, "#ffffff");
    g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = "destination-over";
    for (const [dx, dy] of VUELTAS) g.drawImage(blanca, dx, dy);
    g.restore();
    const sombra = siluetaDe(g.canvas, "rgba(0,0,0,0.45)", 18);
    g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = "destination-over"; g.drawImage(sombra, 8, 20); g.restore();
  },
  subtitulos: {
    tam: 78, linea: 88, letra: "fredoka-700", letraDicha: "fredoka-600",
    color: "#ffffff", dicho: "#a597b3", contorno: "#1d1526", grosorContorno: 14,
    resalte: "pastilla", colorResalte: "#ff5d73",
  },
});
