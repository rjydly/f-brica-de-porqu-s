# Fàbrica de Porqués + Fàbrica de Guiones — transferència a un altre ordinador

Aquesta carpeta està **neta de preferències**: no conté `fabrica.config.json`, `preferencias.md`, `.env.local`, `videos/`, `salida/` ni la veu descarregada. És a posta per fer-la servir en un altre ordinador i que cada vídeo o projecte trii els seus propis estil, idioma, veu i tanca.

## Què hi ha
- Motor de vídeo: `fabrica.mjs`, `nucleo/`, `ordenes/`, `pinceles/`, `guia/`, `estilos/`, `letra/`, `sonidos/`, `herramientas/`.
- Exemple de nivell: `ejemplo/` (inclòs `ejemplo/palomitas/guion.md`).
- Instruccions per l'assistent: `CLAUDE.md`, `AGENTS.md`, `METODO.md`.
- Configuració d'OpenCode: `opencode.jsonc` (carrega `CLAUDE.md` automàticament).

## Què NO s'ha portat (a posta)
- `fabrica.config.json` — estil, veu, idioma i nicho del creador (s'omit a posta).
- `preferencias.md` — respostes de "Configúrame" (s'omit a posta).
- `.env.local` — clau d'ElevenLabs, si s'utilitzava (s'omit a posta).
- `videos/`, `salida/`, `tendencias/` — projectes, vídeos i tendències d'aquest ordinador.
- `.cache/`, `voces/`, `voz-muestra.wav` — model de Kokoro i veus descarregades (s'han de tornar a descarregar, és gratis i s'fa sol).

## Pas a pas en l'ordinador nou

1. Copia aquesta carpeta a l'ordinador nou i descomprimeix-la si la vess en .zip.
2. Instala **Node.js** (es recomana la versió instal·lada en aquest ordinador: 26.x).
3. Obrir una terminal dins d'aquesta carpeta i executar:
   ```powershell
   npm install
   ```
4. Si la veu local (Kokoro) no conecta per falta del motor ONNX, executar:
   ```powershell
   node node_modules/onnxruntime-node/script/install
   ```
5. Instala **ffmpeg** (per exemple amb WinGet):
   ```powershell
   winget install Gyan.FFmpeg
   ```
   Després **tanca i torna a obrir** OpenCode (o l'editor) perquè agafi el `ffmpeg` al PATH.
6. Obrir OpenCode **dins d'aquesta carpeta**.
7. Escriure:
   ```
   Configúrame
   ```
   Respon les preguntes amb botons: idioma, a qui són els vídeos, tanca, efectes, estil (recomanat: Casa) i veu (recomanat: `em_alex`, espanya, home). Això crea `preferencias.md` i `fabrica.config.json` amb **les teues** eleccions d'aquest ordinador.
8. Verifica-ho amb:
   ```powershell
   node fabrica.mjs doctor
   ```
   Has de veure tot en "ok" (ffmpeg pot faltar fins que reiniciïs OpenCode per PATH).

9. Ja pots demanar el vídeo, tot en el mateix xat:
   ```
   Hazme un vídeo de por qué ...
   ```
   O només el guió:
   ```
   Hazme un guion de por qué ...
   ```

## Guió ja escrit (Fàbrica de Guiones)
Si ja tens un `guion.md` fet amb Fàbrica de Guiones, importa'l sense reescriure'l:
```powershell
node fabrica.mjs guion "ruta\al\guion.md" --nombre <nom-del-video>
```
Després:
```powershell
node fabrica.mjs voz <video>
```

## Recordes
- Un vídeo per conversa. El següent, en un xat nou.
- Mai demani la clau d'ElevenLabs al xat; si s'utilitza, es dala a la pàgina que obre `node fabrica.mjs clave`.
- La veu per defecte és Kokoro, gratuïta, local i sense clau.
